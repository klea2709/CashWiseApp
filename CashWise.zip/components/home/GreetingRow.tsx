"use client"

import { useState } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { Bell } from "lucide-react"
import { useUserStore } from "@/lib/stores/userStore"

export default function GreetingRow() {
  const { user } = useUserStore()
  const [showNotifications, setShowNotifications] = useState(false)

  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="relative">
          <Image
            src={user.avatar || "/placeholder.svg?height=40&width=40"}
            alt="Avatar"
            width={40}
            height={40}
            className="rounded-full border-2 border-[#84DCCF]"
          />
          <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-[#CBA135] rounded-full flex items-center justify-center text-white text-xs font-bold">
            {user.level}
          </div>
        </div>
        <div>
          <h1 className="font-bold text-lg">Hey, {user.name} 👋</h1>
          <div className="flex items-center gap-1 text-xs">
            <span className="bg-[#EF626C] text-white px-2 py-0.5 rounded-full">
              Level {user.level}: {user.levelTitle}
            </span>
            <span className="flex items-center gap-0.5">
              <span className="text-sm">🔥</span> {user.streak}-day
            </span>
          </div>
        </div>
      </div>

      <div className="relative">
        <button className="p-2 bg-white rounded-full shadow" onClick={() => setShowNotifications(!showNotifications)}>
          <Bell size={20} />
          <span className="absolute top-0 right-0 w-3 h-3 bg-[#EF626C] rounded-full"></span>
        </button>

        {showNotifications && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-lg p-3 z-10"
          >
            <h3 className="font-bold mb-2">Notifications</h3>
            <div className="space-y-2">
              <div className="p-2 bg-gray-50 rounded-xl text-sm">
                <p className="font-medium">New mission available!</p>
                <p className="text-xs text-gray-500">Just now</p>
              </div>
              <div className="p-2 bg-gray-50 rounded-xl text-sm">
                <p className="font-medium">You earned 50 FinPoints!</p>
                <p className="text-xs text-gray-500">2 hours ago</p>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}
