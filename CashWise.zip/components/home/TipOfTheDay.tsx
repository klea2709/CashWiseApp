"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Lightbulb, ArrowRight } from "lucide-react"

const tips = [
  {
    id: 1,
    text: "Save 20% of your allowance each week to build an emergency fund.",
    category: "Saving",
  },
  {
    id: 2,
    text: "Track your spending for a month to see where your money actually goes.",
    category: "Budgeting",
  },
  {
    id: 3,
    text: "Compound interest means your money makes more money over time.",
    category: "Investing",
  },
  {
    id: 4,
    text: "Before buying something, wait 24 hours to decide if you really need it.",
    category: "Smart Spending",
  },
  {
    id: 5,
    text: "Set specific financial goals with deadlines to stay motivated.",
    category: "Goal Setting",
  },
]

export default function TipOfTheDay() {
  const [currentTip, setCurrentTip] = useState(0)

  const nextTip = () => {
    setCurrentTip((prev) => (prev + 1) % tips.length)
  }

  return (
    <div className="space-y-2">
      <h2 className="font-bold">Tip of the Day</h2>

      <motion.div
        key={tips[currentTip].id}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="bg-white p-4 rounded-2xl shadow"
      >
        <div className="flex gap-3">
          <div className="p-2 bg-[#EF626C] rounded-xl">
            <Lightbulb size={20} className="text-white" />
          </div>
          <div>
            <div className="text-xs font-medium text-[#EF626C] mb-1">{tips[currentTip].category}</div>
            <p className="text-sm">{tips[currentTip].text}</p>
          </div>
        </div>
        <button
          onClick={nextTip}
          className="w-full mt-3 py-2 bg-gray-100 rounded-xl text-sm font-medium flex items-center justify-center gap-1"
        >
          More Tips <ArrowRight size={14} />
        </button>
      </motion.div>
    </div>
  )
}
