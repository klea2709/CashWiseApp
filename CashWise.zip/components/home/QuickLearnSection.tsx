"use client" 

import { motion } from "framer-motion"
import Link from "next/link"
import { BookOpen, ArrowRight, Brain, Calculator, CreditCard } from "lucide-react"

export default function QuickLearnSection() {
  const learnModules = [
    {
      id: "bank-quiz",
      title: "Bank Quiz",
      description: "Test your banking knowledge",
      icon: Brain,
      color: "#84DCCF",
      href: "/learn/bank-quiz",
    },
    {
      id: "budget-basics",
      title: "Budget Basics",
      description: "Learn to manage your money",
      icon: Calculator,
      color: "#EF626C",
      href: "/learn/budget-basics",
    },
    {
      id: "card-safety",
      title: "Card Safety",
      description: "Keep your bank card secure",
      icon: CreditCard,
      color: "#CBA135",
      href: "/learn/card-safety",
    },
  ]

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <h2 className="font-bold flex items-center gap-1">
          <BookOpen size={18} className="text-[#84DCCF]" />
          Learn
        </h2>
        <Link href="/learn" className="text-sm text-[#EF626C] font-medium flex items-center gap-1">
          All Lessons <ArrowRight size={14} />
        </Link>
      </div>

      <div className="space-y-3">
        {learnModules.map((module) => (
          <Link key={module.id} href={module.href}>
            <motion.div
              className="bg-white p-3 rounded-2xl shadow flex items-center justify-between"
              whileHover={{ y: -2 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl" style={{ backgroundColor: `${module.color}20` }}>
                  <module.icon size={20} style={{ color: module.color }} />
                </div>
                <div>
                  <h3 className="font-medium">{module.title}</h3>
                  <p className="text-xs text-gray-500">{module.description}</p>
                </div>
              </div>
              <ArrowRight size={16} className="text-gray-400" />
            </motion.div>
          </Link>
        ))}
      </div>
    </div>
  )
}
