"use client"

import { motion } from "framer-motion"
import { Bike, ArrowRight } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function FeaturedMission() {
  const router = useRouter()

  const handleContinueMission = () => {
    router.push("/missions/save-for-bike")
  }

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <h2 className="font-bold">Featured Mission</h2>
        <Link href="/missions" className="text-sm text-[#EF626C] font-medium flex items-center gap-1">
          All Missions <ArrowRight size={14} />
        </Link>
      </div>

      <motion.div
        className="bg-white p-4 rounded-2xl shadow"
        whileHover={{ y: -5 }}
        transition={{ type: "spring", stiffness: 300 }}
      >
        <div className="flex gap-3">
          <div className="p-3 bg-[#84DCCF] rounded-xl">
            <Bike size={24} className="text-white" />
          </div>
          <div className="flex-1">
            <h3 className="font-bold">Save for Your Dream Bike</h3>
            <p className="text-sm text-gray-600 mb-2">Learn how to set a savings goal and track your progress</p>
            <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
              <div className="bg-[#84DCCF] h-2 rounded-full" style={{ width: "40%" }}></div>
            </div>
            <div className="flex justify-between text-xs">
              <span>Progress: 40%</span>
              <span>Reward: 200 TeenCoins</span>
            </div>
          </div>
        </div>
        <button
          onClick={handleContinueMission}
          className="w-full mt-3 py-2 bg-[#84DCCF] rounded-xl text-sm font-medium"
        >
          Continue Mission
        </button>
      </motion.div>
    </div>
  )
}
