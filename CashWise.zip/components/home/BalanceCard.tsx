"use client"

import { motion } from "framer-motion"
import { Coins, PiggyBank } from "lucide-react"
import { useUserStore } from "@/lib/stores/userStore"

export default function BalanceCard() {
  const { user } = useUserStore()

  const coinAnimation = {
    initial: { rotate: 0 },
    hover: { rotate: 20, transition: { duration: 0.3 } },
  }

  return (
    <motion.div
      className="bg-gradient-to-r from-[#CBA135] to-[#EF626C] p-4 rounded-2xl text-white shadow-lg"
      whileHover="hover"
      initial="initial"
    >
      <div className="flex justify-between mb-4">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <motion.div variants={coinAnimation}>
              <Coins size={24} />
            </motion.div>
            <span className="text-lg font-medium">TeenCoins</span>
          </div>
          <div className="text-3xl font-bold">{user.teenCoins}</div>
          <div className="text-sm opacity-80">Keep learning to earn more!</div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <motion.div variants={coinAnimation}>
              <PiggyBank size={24} />
            </motion.div>
            <span className="text-lg font-medium">Savings</span>
          </div>
          <div className="text-3xl font-bold">${user.savings.toFixed(2)}</div>
          <div className="text-sm opacity-80">Goal: ${user.savingsGoal.toFixed(2)}</div>
        </div>
      </div>

      <div className="w-full bg-white/20 rounded-full h-2 mb-1">
        <div
          className="bg-white h-2 rounded-full"
          style={{ width: `${Math.min(100, (user.savings / user.savingsGoal) * 100)}%` }}
        ></div>
      </div>
      <div className="text-xs text-right">
        {Math.min(100, Math.round((user.savings / user.savingsGoal) * 100))}% of goal
      </div>
    </motion.div>
  )
}
