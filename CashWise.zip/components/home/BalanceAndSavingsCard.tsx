"use client"

import { motion } from "framer-motion"
import { Coins, PiggyBank } from "lucide-react"
import { useUserStore } from "@/lib/stores/userStore"

export default function BalanceAndSavingsCard() {
  const { user } = useUserStore()

  const coinAnimation = {
    initial: { rotate: 0 },
    hover: { rotate: 20, transition: { duration: 0.3 } },
  }

  return (
    <motion.div
      className="bg-gradient-to-r from-[#CBA135] to-[#EF626C] p-4 rounded-2xl text-white shadow-lg"
      whileHover="hover"
      initial="initial"
    >
      <div className="flex justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <motion.div variants={coinAnimation}>
              <Coins size={20} />
            </motion.div>
            <span className="text-sm font-medium">TeenCoins</span>
          </div>
          <div className="text-2xl font-bold">{user.teenCoins}</div>
          <div className="text-xs opacity-80">Keep learning to earn more!</div>
        </div>

        <div className="w-px bg-white/30 mx-2"></div>

        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <PiggyBank size={20} />
            <span className="text-sm font-medium">Savings</span>
          </div>
          <div className="text-2xl font-bold">$85.50</div>
          <div className="text-xs opacity-80">Goal: $120.00</div>
        </div>
      </div>
    </motion.div>
  )
}
