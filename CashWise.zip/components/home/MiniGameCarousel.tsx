"use client"

import { useRef } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import { ChevronRight, ChevronLeft, Lock } from "lucide-react"

const games = [
  {
    id: "budget-battle",
    title: "Budget Battle",
    icon: "💰",
    progress: 60,
    unlocked: true,
  },
  {
    id: "spend-smart-quiz",
    title: "Spend Smart Quiz",
    icon: "🎮",
    progress: 40,
    unlocked: true,
  },
  {
    id: "loan-lab",
    title: "Loan Lab",
    icon: "🧪",
    progress: 20,
    unlocked: true,
  },
  {
    id: "finance-tycoon",
    title: "Finance Tycoon Jr.",
    icon: "🏢",
    progress: 0,
    unlocked: true,
  },
  {
    id: "interest-island",
    title: "Interest Island",
    icon: "🏝️",
    progress: 0,
    unlocked: true,
  },
  {
    id: "crypto-caution",
    title: "Crypto Caution",
    icon: "⚠️",
    progress: 0,
    unlocked: false,
  },
  {
    id: "stockstar-simulator",
    title: "StockStar Simulator",
    icon: "📈",
    progress: 0,
    unlocked: false,
  },
]

export default function MiniGameCarousel() {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const { current } = scrollRef
      const scrollAmount = direction === "left" ? -200 : 200
      current.scrollBy({ left: scrollAmount, behavior: "smooth" })
    }
  }

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <h2 className="font-bold">Mini-Games</h2>
        <div className="flex gap-1">
          <button onClick={() => scroll("left")} className="p-1 bg-gray-100 rounded-full">
            <ChevronLeft size={16} />
          </button>
          <button onClick={() => scroll("right")} className="p-1 bg-gray-100 rounded-full">
            <ChevronRight size={16} />
          </button>
        </div>
      </div>

      <div ref={scrollRef} className="flex gap-3 overflow-x-auto pb-2 no-scrollbar">
        {games.map((game) => (
          <Link key={game.id} href={game.unlocked ? `/games/${game.id}` : "#"} className="flex-shrink-0 w-36">
            <motion.div
              className="bg-white p-3 rounded-2xl shadow h-full"
              whileHover={{ y: -5 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <div className="flex justify-between items-start mb-2">
                <div className="text-2xl">{game.icon}</div>
                {!game.unlocked && (
                  <div className="p-1 bg-gray-100 rounded-full">
                    <Lock size={14} />
                  </div>
                )}
              </div>
              <h3 className="font-bold text-sm mb-2">{game.title}</h3>
              {game.progress > 0 && (
                <>
                  <div className="w-full bg-gray-200 rounded-full h-1.5 mb-1">
                    <div className="bg-[#84DCCF] h-1.5 rounded-full" style={{ width: `${game.progress}%` }}></div>
                  </div>
                  <div className="text-xs text-gray-500">{game.progress}% complete</div>
                </>
              )}
              {game.progress === 0 && game.unlocked && <div className="text-xs text-gray-500">Start playing!</div>}
              {!game.unlocked && <div className="text-xs text-gray-500">Unlock at Level 5</div>}
            </motion.div>
          </Link>
        ))}
      </div>
    </div>
  )
}
