"use client"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, BookOpen, Wallet, CreditCard, User } from "lucide-react"

const BottomNavigation = () => {
  const pathname = usePathname()

  const navItems = [
    {
      name: "Home",
      href: "/",
      icon: Home,
    },
    {
      name: "Missions",
      href: "/missions",
      icon: BookOpen,
    },
    {
      name: "Card",
      href: "/bank-card",
      icon: CreditCard,
    },
    {
      name: "Learn",
      href: "/learn",
      icon: Wallet,
    },
    {
      name: "Profile",
      href: "/profile",
      icon: User,
    },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-2 px-4 flex justify-between items-center z-50">
      {navItems.map((item) => {
        const isActive = pathname === item.href
        return (
          <Link
            key={item.name}
            href={item.href}
            className={`flex flex-col items-center justify-center ${isActive ? "text-blue-500" : "text-gray-500"}`}
          >
            <item.icon size={24} />
            <span className="text-xs mt-1">{item.name}</span>
          </Link>
        )
      })}
    </div>
  )
}

export default BottomNavigation
