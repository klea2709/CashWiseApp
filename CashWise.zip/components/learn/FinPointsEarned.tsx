"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import confetti from "canvas-confetti"
import { Award } from "lucide-react"
import Link from "next/link"

interface FinPointsEarnedProps {
  points: number
}

export default function FinPointsEarned({ points }: FinPointsEarnedProps) {
  const [showModal, setShowModal] = useState(false)

  useEffect(() => {
    // Show modal after a delay to simulate completion
    const timer = setTimeout(() => {
      setShowModal(true)

      // Trigger confetti
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      })
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  return (
    <AnimatePresence>
      {showModal && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            className="bg-white rounded-2xl p-6 w-full max-w-sm text-center"
          >
            <div className="mb-4">
              <div className="w-20 h-20 bg-[#84DCCF] rounded-full flex items-center justify-center mx-auto">
                <Award size={40} className="text-white" />
              </div>
            </div>

            <h2 className="text-2xl font-bold mb-2">Congratulations!</h2>
            <p className="mb-4">You've completed this lesson and earned:</p>

            <div className="text-4xl font-bold text-[#EF626C] mb-6">{points} FinPoints</div>

            <div className="space-y-3">
              <Link href="/" className="block w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
                Back to Home
              </Link>
              <Link href="/learn" className="block w-full py-3 bg-gray-100 rounded-2xl font-medium">
                More Lessons
              </Link>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
