"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { CheckCircle, XCircle } from "lucide-react"
import type { QuizQuestion as QuizQuestionType } from "@/lib/types"
import { useUserStore } from "@/lib/stores/userStore"

interface QuizQuestionProps {
  question: QuizQuestionType
  questionIndex: number
}

export default function QuizQuestion({ question, questionIndex }: QuizQuestionProps) {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null)
  const { addFinPoints } = useUserStore()

  const handleAnswerSelect = (index: number) => {
    if (selectedAnswer !== null) return

    setSelectedAnswer(index)
    const correct = index === question.correctIndex
    setIsCorrect(correct)

    if (correct) {
      addFinPoints(10)
    }
  }

  return (
    <div className="bg-white p-4 rounded-2xl shadow">
      <h3 className="font-bold mb-3">Question {questionIndex + 1}</h3>
      <p className="mb-4">{question.question}</p>

      <div className="space-y-3">
        {question.options.map((option, index) => (
          <button
            key={index}
            onClick={() => handleAnswerSelect(index)}
            disabled={selectedAnswer !== null}
            className={`w-full p-3 rounded-xl text-left flex justify-between items-center ${
              selectedAnswer === null
                ? "bg-gray-100 hover:bg-gray-200"
                : selectedAnswer === index
                  ? index === question.correctIndex
                    ? "bg-green-100 border-2 border-green-500"
                    : "bg-red-100 border-2 border-red-500"
                  : index === question.correctIndex
                    ? "bg-green-100 border-2 border-green-500"
                    : "bg-gray-100"
            }`}
          >
            <span>{option}</span>
            {selectedAnswer !== null &&
              (index === question.correctIndex ? (
                <CheckCircle className="text-green-500" size={20} />
              ) : selectedAnswer === index ? (
                <XCircle className="text-red-500" size={20} />
              ) : null)}
          </button>
        ))}
      </div>

      {isCorrect !== null && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          className={`mt-4 p-3 rounded-xl ${isCorrect ? "bg-green-100" : "bg-red-100"}`}
        >
          <p className="font-medium">{isCorrect ? "Correct!" : "Incorrect!"}</p>
          <p className="text-sm mt-1">{question.explanation}</p>
        </motion.div>
      )}
    </div>
  )
}
