"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { Play, Award } from "lucide-react"
import type { Lesson } from "@/lib/types"

interface LessonCardProps {
  lesson: Lesson
}

export default function LessonCard({ lesson }: LessonCardProps) {
  return (
    <motion.div
      className="bg-white rounded-2xl shadow overflow-hidden"
      whileHover={{ y: -5 }}
      transition={{ type: "spring", stiffness: 300 }}
    >
      <div className="aspect-video bg-gray-200 relative">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="p-3 bg-white/80 rounded-full">
            <Play size={24} className="text-[#EF626C]" />
          </div>
        </div>
      </div>
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-bold">{lesson.title}</h3>
          <div className="flex items-center gap-1 bg-[#84DCCF] px-2 py-0.5 rounded-full text-xs">
            <Award size={12} />
            <span>{lesson.points} Points</span>
          </div>
        </div>
        <p className="text-sm text-gray-600 mb-3">{lesson.description}</p>
        <Link
          href={`/lesson/${lesson.id}`}
          className="block w-full py-2 bg-[#84DCCF] rounded-xl text-sm font-medium text-center"
        >
          Learn More
        </Link>
      </div>
    </motion.div>
  )
}
