"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { Coins } from "lucide-react"
import type { Mission } from "@/lib/types"

interface MissionCardProps {
  mission: Mission
}

export default function MissionCard({ mission }: MissionCardProps) {
  // Map mission IDs to their respective routes
  const getMissionRoute = (id: string) => {
    const routes: Record<string, string> = {
      "1": "/missions/save-for-bike",
      "2": "/missions/budget-for-school",
      "3": "/missions/smart-shopping",
      "6": "/games/memory-game", // Add route for the new Memory Game
    }

    return routes[id] || "/missions"
  }

  return (
    <motion.div
      className="bg-white p-4 rounded-2xl shadow"
      whileHover={{ y: -5 }}
      transition={{ type: "spring", stiffness: 300 }}
    >
      <div className="flex gap-3">
        <div className="p-3 rounded-xl" style={{ backgroundColor: mission.color }}>
          <mission.icon size={24} className="text-white" />
        </div>
        <div className="flex-1">
          <h3 className="font-bold">{mission.title}</h3>
          <p className="text-sm text-gray-600 mb-2">{mission.description}</p>
          <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
            <div className="bg-[#84DCCF] h-2 rounded-full" style={{ width: `${mission.progress}%` }}></div>
          </div>
          <div className="flex justify-between text-xs">
            <span>Progress: {mission.progress}%</span>
            <div className="flex items-center gap-1">
              <Coins size={12} />
              <span>{mission.reward} TeenCoins</span>
            </div>
          </div>
        </div>
      </div>
      <Link
        href={getMissionRoute(mission.id)}
        className="block w-full mt-3 py-2 bg-[#84DCCF] rounded-xl text-sm font-medium text-center"
      >
        {mission.progress > 0 ? "Continue Mission" : "Start Mission"}
      </Link>
    </motion.div>
  )
}
