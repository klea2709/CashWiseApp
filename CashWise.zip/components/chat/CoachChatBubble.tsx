"use client"

import { motion } from "framer-motion"

interface CoachChatBubbleProps {
  message: string
  isUser: boolean
  isTyping?: boolean
}

export default function CoachChatBubble({ message, isUser, isTyping = false }: CoachChatBubbleProps) {
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`max-w-[80%] p-3 rounded-2xl ${
          isUser ? "bg-[#84DCCF] text-[#020122]" : "bg-gray-100 text-[#020122]"
        }`}
      >
        {isTyping ? (
          <div className="flex space-x-1">
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1, delay: 0 }}
              className="w-2 h-2 bg-gray-400 rounded-full"
            />
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1, delay: 0.2 }}
              className="w-2 h-2 bg-gray-400 rounded-full"
            />
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1, delay: 0.4 }}
              className="w-2 h-2 bg-gray-400 rounded-full"
            />
          </div>
        ) : (
          <p className="text-sm">{message}</p>
        )}
      </motion.div>
    </div>
  )
}
