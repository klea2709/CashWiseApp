"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { Send } from "lucide-react"
import CoachChatBubble from "@/components/chat/CoachChatBubble"
import { getChatResponse } from "@/lib/api"

export default function ChatPage() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: "Hi there! I'm your FinMate coach. How can I help you with your financial journey today?",
      isUser: false,
    },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = async () => {
    if (!input.trim()) return

    const userMessage = { id: Date.now(), text: input, isUser: true }
    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    try {
      const response = await getChatResponse(input)
      setIsTyping(false)
      setMessages((prev) => [...prev, { id: Date.now(), text: response, isUser: false }])
    } catch (error) {
      setIsTyping(false)
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now(),
          text: "Sorry, I'm having trouble connecting right now. Please try again later.",
          isUser: false,
        },
      ])
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col h-screen"
    >
      <div className="p-4 border-b">
        <h1 className="text-2xl font-bold">ChatBuddy 🤖</h1>
        <p className="text-sm text-gray-600">Your personal finance coach</p>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <CoachChatBubble key={message.id} message={message.text} isUser={message.isUser} />
        ))}

        {isTyping && <CoachChatBubble message="..." isUser={false} isTyping={true} />}

        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t bg-white">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask me about saving, budgeting, or investing..."
            className="flex-1 p-3 rounded-2xl border focus:outline-none focus:ring-2 focus:ring-[#84DCCF]"
          />
          <button onClick={handleSend} className="p-3 bg-[#84DCCF] rounded-full">
            <Send size={20} />
          </button>
        </div>

        <div className="flex gap-2 mt-3 overflow-x-auto no-scrollbar">
          <button className="px-3 py-1 bg-gray-100 rounded-full text-xs whitespace-nowrap">How do I save money?</button>
          <button className="px-3 py-1 bg-gray-100 rounded-full text-xs whitespace-nowrap">
            What is compound interest?
          </button>
          <button className="px-3 py-1 bg-gray-100 rounded-full text-xs whitespace-nowrap">
            How to make a budget?
          </button>
        </div>
      </div>
    </motion.main>
  )
}
