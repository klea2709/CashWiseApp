"use client"

import React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CreditCard, ArrowLeft, Check } from "lucide-react"
import Link from "next/link"

export default function CustomizeCardPage() {
  const cardThemes = [
    { id: 1, name: "Ocean Blue", gradient: "from-blue-500 to-cyan-400" },
    { id: 2, name: "Sunset Orange", gradient: "from-orange-500 to-pink-500" },
    { id: 3, name: "Forest Green", gradient: "from-green-500 to-emerald-400" },
    { id: 4, name: "Royal Purple", gradient: "from-purple-600 to-indigo-500" },
    { id: 5, name: "Midnight Black", gradient: "from-gray-800 to-gray-900" },
  ]

  const [selectedTheme, setSelectedTheme] = React.useState(1)

  return (
    <main className="flex min-h-screen flex-col pb-20">
      <div className="container px-4 py-6 space-y-6">
        <div className="flex items-center">
          <Link href="/bank-card">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold ml-2">Customize Your Card</h1>
        </div>

        <div className="flex justify-center mb-8">
          <Card
            className={`bg-gradient-to-r ${cardThemes.find((t) => t.id === selectedTheme)?.gradient} text-white w-full max-w-sm`}
          >
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <p className="text-sm opacity-80">Balance</p>
                  <p className="text-2xl font-bold">$145.26</p>
                </div>
                <CreditCard className="h-8 w-8" />
              </div>
              <div className="flex justify-between text-sm">
                <p>•••• •••• •••• 4289</p>
                <p>05/26</p>
              </div>
              <p className="mt-2 text-sm">Alex Johnson</p>
            </CardContent>
          </Card>
        </div>

        <h2 className="text-xl font-bold">Choose a Theme</h2>

        <div className="grid grid-cols-2 gap-4">
          {cardThemes.map((theme) => (
            <Button
              key={theme.id}
              variant={selectedTheme === theme.id ? "default" : "outline"}
              className={`h-20 ${selectedTheme === theme.id ? "ring-2 ring-blue-500" : ""} bg-gradient-to-r ${theme.gradient} text-white justify-between`}
              onClick={() => setSelectedTheme(theme.id)}
            >
              {theme.name}
              {selectedTheme === theme.id && <Check className="h-5 w-5" />}
            </Button>
          ))}
        </div>

        <Link href="/bank-card">
          <Button className="w-full bg-blue-500 hover:bg-blue-600 text-white mt-8">Save Changes</Button>
        </Link>
      </div>
    </main>
  )
}
