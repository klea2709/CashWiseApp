import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CreditCard, ChevronRight, Wallet, ArrowUpRight } from "lucide-react"
import BottomNavigation from "@/components/navigation/BottomNavigation"
import Link from "next/link"

export default function BankCardPage() {
  const transactions = [
    { id: 1, merchant: "Bookstore", amount: -24.99, date: "2023-05-15" },
    { id: 2, merchant: "Allowance", amount: 50.0, date: "2023-05-10" },
    { id: 3, merchant: "Ice Cream Shop", amount: -5.75, date: "2023-05-08" },
    { id: 4, merchant: "Birthday Gift", amount: 25.0, date: "2023-05-01" },
  ]

  return (
    <main className="flex min-h-screen flex-col pb-20">
      <div className="container px-4 py-6 space-y-6">
        <h1 className="text-2xl font-bold">Your Card</h1>

        <div className="flex justify-center">
          <CreditCard className="h-32 w-32 text-blue-500" />
        </div>

        <Card className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-6">
              <div>
                <p className="text-sm opacity-80">Balance</p>
                <p className="text-2xl font-bold">$145.26</p>
              </div>
              <CreditCard className="h-8 w-8" />
            </div>
            <div className="flex justify-between text-sm">
              <p>•••• •••• •••• 4289</p>
              <p>05/26</p>
            </div>
            <p className="mt-2 text-sm">Alex Johnson</p>
          </CardContent>
        </Card>

        <Link href="/bank-card/customize">
          <Button className="w-full bg-blue-500 hover:bg-blue-600 text-white">Customize Card</Button>
        </Link>

        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold">Recent Transactions</h2>
          <Button variant="ghost" size="sm" className="text-blue-500">
            See all <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>

        <div className="space-y-3">
          {transactions.map((transaction) => (
            <Card key={transaction.id}>
              <CardContent className="p-4 flex justify-between items-center">
                <div className="flex items-center">
                  <div className="bg-gray-100 p-2 rounded-full mr-3">
                    {transaction.amount > 0 ? (
                      <Wallet className="h-5 w-5 text-green-500" />
                    ) : (
                      <ArrowUpRight className="h-5 w-5 text-red-500" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium">{transaction.merchant}</p>
                    <p className="text-xs text-gray-500">{transaction.date}</p>
                  </div>
                </div>
                <p className={`font-medium ${transaction.amount > 0 ? "text-green-500" : "text-red-500"}`}>
                  {transaction.amount > 0 ? "+" : ""}${Math.abs(transaction.amount).toFixed(2)}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
      <BottomNavigation />
    </main>
  )
}
