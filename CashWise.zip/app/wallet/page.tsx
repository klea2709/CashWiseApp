"use client"

import { motion } from "framer-motion"
import { useState, useEffect } from "react"
import { Coins, ArrowDownCircle, ArrowUpCircle, Gift } from "lucide-react"
import { getWalletData } from "@/lib/api"
import type { WalletData } from "@/lib/types"

export default function WalletPage() {
  const [walletData, setWalletData] = useState<WalletData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchWalletData = async () => {
      try {
        const data = await getWalletData()
        setWalletData(data)
      } catch (error) {
        console.error("Failed to fetch wallet data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchWalletData()
  }, [])

  if (loading) {
    return <div className="p-4">Loading wallet data...</div>
  }

  if (!walletData) {
    return <div className="p-4">Failed to load wallet data</div>
  }

  return (
    <motion.main initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">Wallet</h1>

      <div className="bg-gradient-to-r from-[#CBA135] to-[#EF626C] p-6 rounded-2xl text-white shadow-lg">
        <div className="flex items-center gap-3 mb-4">
          <Coins size={32} />
          <span className="text-lg font-medium">TeenCoins</span>
        </div>
        <div className="text-3xl font-bold mb-2">{walletData.balance}</div>
        <div className="text-sm opacity-80">Last updated: {walletData.lastUpdated}</div>
      </div>

      <div className="flex gap-4">
        <button className="flex-1 bg-white p-4 rounded-2xl shadow flex flex-col items-center gap-2">
          <div className="p-2 bg-[#84DCCF] rounded-full">
            <ArrowUpCircle size={24} />
          </div>
          <span className="text-sm font-medium">Earn</span>
        </button>

        <button className="flex-1 bg-white p-4 rounded-2xl shadow flex flex-col items-center gap-2">
          <div className="p-2 bg-[#EF626C] rounded-full">
            <Gift size={24} />
          </div>
          <span className="text-sm font-medium">Redeem</span>
        </button>
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">Transaction History</h2>
        <div className="space-y-3">
          {walletData.transactions.map((transaction) => (
            <div key={transaction.id} className="bg-white p-4 rounded-2xl shadow flex items-center gap-3">
              <div className={`p-2 rounded-full ${transaction.type === "earn" ? "bg-green-100" : "bg-red-100"}`}>
                {transaction.type === "earn" ? (
                  <ArrowUpCircle size={20} className="text-green-600" />
                ) : (
                  <ArrowDownCircle size={20} className="text-red-600" />
                )}
              </div>
              <div className="flex-1">
                <div className="font-medium">{transaction.title}</div>
                <div className="text-xs text-gray-500">{transaction.date}</div>
              </div>
              <div className={`font-bold ${transaction.type === "earn" ? "text-green-600" : "text-red-600"}`}>
                {transaction.type === "earn" ? "+" : "-"}
                {transaction.amount}
              </div>
            </div>
          ))}
        </div>
      </div>
    </motion.main>
  )
}
