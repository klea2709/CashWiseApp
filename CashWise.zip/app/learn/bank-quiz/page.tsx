"use client"

import React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Brain, CheckCircle, XCircle } from "lucide-react"
import Link from "next/link"

export default function BankQuizPage() {
  const [currentQuestion, setCurrentQuestion] = React.useState(0)
  const [score, setScore] = React.useState(0)
  const [showResults, setShowResults] = React.useState(false)
  const [selectedAnswer, setSelectedAnswer] = React.useState<number | null>(null)
  const [isCorrect, setIsCorrect] = React.useState<boolean | null>(null)

  const questions = [
    {
      question: "What is a debit card?",
      options: [
        "A card that lets you borrow money from the bank",
        "A card that takes money directly from your bank account",
        "A card that gives you cash back on purchases",
        "A card that stores cryptocurrency",
      ],
      correctAnswer: 1,
    },
    {
      question: "What is interest?",
      options: [
        "The fee you pay for using an ATM",
        "Money you earn or pay for borrowing or lending money",
        "The amount you deposit into your account",
        "A bank's customer service rating",
      ],
      correctAnswer: 1,
    },
    {
      question: "What is a savings account?",
      options: [
        "An account that pays you interest on your deposits",
        "An account that lets you write checks",
        "An account that requires a minimum balance of $1000",
        "An account that can only be accessed online",
      ],
      correctAnswer: 0,
    },
    {
      question: "What does ATM stand for?",
      options: [
        "Automatic Transfer Machine",
        "Automated Teller Machine",
        "Account Transaction Manager",
        "All-Time Money",
      ],
      correctAnswer: 1,
    },
    {
      question: "What is a credit score?",
      options: [
        "The amount of money you can borrow",
        "The interest rate on your savings account",
        "A number that represents your creditworthiness",
        "The number of credit cards you own",
      ],
      correctAnswer: 2,
    },
  ]

  const handleAnswerClick = (answerIndex: number) => {
    setSelectedAnswer(answerIndex)
    const correct = answerIndex === questions[currentQuestion].correctAnswer
    setIsCorrect(correct)

    if (correct) {
      setScore(score + 1)
    }

    // Wait 1.5 seconds before moving to next question
    setTimeout(() => {
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1)
        setSelectedAnswer(null)
        setIsCorrect(null)
      } else {
        setShowResults(true)
      }
    }, 1500)
  }

  const resetQuiz = () => {
    setCurrentQuestion(0)
    setScore(0)
    setShowResults(false)
    setSelectedAnswer(null)
    setIsCorrect(null)
  }

  return (
    <main className="flex min-h-screen flex-col pb-20">
      <div className="container px-4 py-6 space-y-6">
        <div className="flex items-center">
          <Link href="/learn">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold ml-2">Bank Quiz</h1>
        </div>

        {!showResults ? (
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <Brain className="h-6 w-6 text-blue-500 mr-2" />
                  <span className="font-medium">
                    Question {currentQuestion + 1} of {questions.length}
                  </span>
                </div>
                <span className="text-sm text-gray-500">Score: {score}</span>
              </div>

              <div className="h-2 w-full bg-gray-200 rounded-full mb-6">
                <div
                  className="h-2 bg-blue-500 rounded-full"
                  style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
                ></div>
              </div>

              <h2 className="text-xl font-medium mb-4">{questions[currentQuestion].question}</h2>

              <div className="space-y-3">
                {questions[currentQuestion].options.map((option, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className={`w-full justify-start text-left p-4 h-auto ${
                      selectedAnswer === index
                        ? selectedAnswer === questions[currentQuestion].correctAnswer
                          ? "bg-green-100 border-green-500"
                          : "bg-red-100 border-red-500"
                        : ""
                    }`}
                    onClick={() => selectedAnswer === null && handleAnswerClick(index)}
                    disabled={selectedAnswer !== null}
                  >
                    <div className="flex items-center w-full">
                      <span className="flex-grow">{option}</span>
                      {selectedAnswer === index &&
                        (selectedAnswer === questions[currentQuestion].correctAnswer ? (
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-500" />
                        ))}
                    </div>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="p-6 text-center">
              <div className="mb-6">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 mb-4">
                  <Brain className="h-8 w-8 text-blue-500" />
                </div>
                <h2 className="text-2xl font-bold">Quiz Complete!</h2>
                <p className="text-gray-500 mt-2">
                  You scored {score} out of {questions.length}
                </p>
              </div>

              <div className="w-full bg-gray-200 rounded-full h-4 mb-6">
                <div
                  className="h-4 rounded-full bg-blue-500"
                  style={{ width: `${(score / questions.length) * 100}%` }}
                ></div>
              </div>

              <div className="space-y-4">
                <p className="font-medium">
                  {score === questions.length
                    ? "Perfect score! You're a banking expert!"
                    : score >= questions.length / 2
                      ? "Good job! You know your banking basics."
                      : "Keep learning! You'll be a banking expert soon."}
                </p>

                <p className="text-sm text-gray-500">You've earned {score * 10} TeenPoints for completing this quiz!</p>

                <div className="pt-4">
                  <Button onClick={resetQuiz} className="mr-3 bg-blue-500 hover:bg-blue-600 text-white">
                    Try Again
                  </Button>
                  <Link href="/learn">
                    <Button variant="outline">Back to Learn</Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </main>
  )
}
