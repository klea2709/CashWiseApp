"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { BookOpen, MessageSquare, Newspaper, PiggyBank, BookText } from "lucide-react"
import BottomNavigation from "@/components/navigation/BottomNavigation"
import Link from "next/link"

export default function LearnPage() {
  const modules = [
    {
      id: 1,
      title: "Saving Basics",
      description: "Learn how to save money effectively",
      icon: PiggyBank,
      color: "bg-blue-100 text-blue-600",
      href: "/learn/saving-basics",
    },
    {
      id: 2,
      title: "Budget Chat",
      description: "Chat with our budget assistant",
      icon: MessageSquare,
      color: "bg-green-100 text-green-600",
      href: "/learn/budget-chat",
    },
    {
      id: 3,
      title: "Money Terms",
      description: "Essential financial vocabulary",
      icon: BookText,
      color: "bg-purple-100 text-purple-600",
      href: "/learn/money-terms",
    },
  ]

  const [activeTab, setActiveTab] = useState("modules")

  const newsItems = [
    {
      id: 1,
      title: "Why Teens Should Start Saving Early",
      snippet: "Starting to save as a teenager can lead to big rewards later in life...",
      timestamp: "2 hours ago",
      category: "Saving Tips",
    },
    {
      id: 2,
      title: "What's Happening with Student Loans?",
      snippet: "Recent changes to student loan policies might affect your future education plans...",
      timestamp: "Yesterday",
      category: "Education",
    },
    {
      id: 3,
      title: "Summer Jobs That Teach Money Skills",
      snippet: "These summer opportunities can help you earn money while learning valuable financial lessons...",
      timestamp: "2 days ago",
      category: "Income",
    },
    {
      id: 4,
      title: "Understanding Your First Paycheck",
      snippet: "Got your first job? Here's what all those deductions on your paycheck actually mean...",
      timestamp: "3 days ago",
      category: "Income",
    },
    {
      id: 5,
      title: "Digital Payment Apps: What Teens Should Know",
      snippet: "Popular payment apps have age restrictions and features you should understand...",
      timestamp: "5 days ago",
      category: "Technology",
    },
  ]

  return (
    <main className="flex min-h-screen flex-col pb-20">
      <div className="container px-4 py-6 space-y-6">
        <h1 className="text-2xl font-bold">Learn & Earn</h1>

        <div className="flex border-b">
          <button
            className={`flex-1 py-2 font-medium text-sm ${
              activeTab === "modules" ? "border-b-2 border-blue-500 text-blue-500" : "text-gray-500"
            }`}
            onClick={() => setActiveTab("modules")}
          >
            Lessons
          </button>
          <button
            className={`flex-1 py-2 font-medium text-sm ${
              activeTab === "news" ? "border-b-2 border-blue-500 text-blue-500" : "text-gray-500"
            }`}
            onClick={() => setActiveTab("news")}
          >
            Finance News
          </button>
        </div>

        {activeTab === "modules" ? (
          <div className="space-y-6">
            <h2 className="text-xl font-bold flex items-center">
              <BookOpen className="mr-2 h-5 w-5 text-blue-500" />
              Learning Modules
            </h2>

            <div className="grid grid-cols-1 gap-4">
              {modules.map((module) => (
                <Link key={module.id} href={module.href}>
                  <Card className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4 flex items-center">
                      <div className={`${module.color} p-3 rounded-full mr-4`}>
                        <module.icon className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-medium">{module.title}</h3>
                        <p className="text-sm text-gray-500">{module.description}</p>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <h2 className="text-xl font-bold flex items-center">
              <Newspaper className="mr-2 h-5 w-5 text-blue-500" />
              Finance News for Teens
            </h2>

            <div className="space-y-4 overflow-hidden">
              {newsItems.map((item) => (
                <Card key={item.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-xs font-medium px-2 py-1 bg-blue-100 text-blue-600 rounded-full">
                        {item.category}
                      </span>
                      <span className="text-xs text-gray-500">{item.timestamp}</span>
                    </div>
                    <h3 className="font-medium mb-1">{item.title}</h3>
                    <p className="text-sm text-gray-600">{item.snippet}</p>
                    <button className="text-sm text-blue-500 font-medium mt-2">Read more</button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
      <BottomNavigation />
    </main>
  )
}
