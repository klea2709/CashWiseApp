"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight, Home } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function SavingBasicsPage() {
  const [currentPage, setCurrentPage] = useState(0)

  const lessonPages = [
    {
      title: "Meet Alex",
      content: (
        <div className="space-y-4">
          <div className="bg-blue-50 rounded-xl p-4 relative">
            <img
              src="/placeholder.svg?height=150&width=150"
              alt="Teen character"
              className="w-24 h-24 object-cover rounded-full mx-auto mb-2"
            />
            <div className="absolute top-16 right-8 bg-white p-2 rounded-xl shadow-md">
              <p className="text-sm">Hi! I'm Alex. I'm saving for a new bike!</p>
            </div>
          </div>
          <p>
            Alex is a 15-year-old who wants to buy a mountain bike that costs $350. Let's follow Alex's journey to learn
            how saving works!
          </p>
        </div>
      ),
    },
    {
      title: "Why Save?",
      content: (
        <div className="space-y-4">
          <div className="bg-purple-50 rounded-xl p-4 flex items-center">
            <img
              src="/placeholder.svg?height=100&width=100"
              alt="Thinking teen"
              className="w-20 h-20 object-cover rounded-full mr-3"
            />
            <div className="bg-white p-2 rounded-xl shadow-md">
              <p className="text-sm">
                "I could just ask my parents for the bike, but I want to buy it myself. Why should I save?"
              </p>
            </div>
          </div>
          <div className="bg-gray-50 p-4 rounded-xl">
            <h3 className="font-medium mb-2">Saving helps you:</h3>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              <li>Buy things you really want</li>
              <li>Become more independent</li>
              <li>Learn patience and planning</li>
              <li>Feel proud of your accomplishments</li>
              <li>Prepare for unexpected expenses</li>
            </ul>
          </div>
        </div>
      ),
    },
    {
      title: "Setting a Goal",
      content: (
        <div className="space-y-4">
          <div className="bg-green-50 rounded-xl p-4 relative">
            <img
              src="/placeholder.svg?height=200&width=300"
              alt="Mountain bike"
              className="w-full h-32 object-cover rounded-lg"
            />
            <div className="absolute bottom-8 right-8 bg-white p-2 rounded-xl shadow-md">
              <p className="text-sm">Mountain Bike: $350</p>
            </div>
          </div>
          <div className="bg-blue-50 p-4 rounded-xl">
            <p className="text-sm mb-2">
              Alex earns $20 per week from chores and walking neighbors' dogs. How long will it take to save $350?
            </p>
            <div className="bg-white p-3 rounded-lg shadow-sm">
              <p className="text-sm font-medium">
                $350 ÷ $20 per week = <span className="text-blue-600">17.5 weeks</span>
              </p>
            </div>
          </div>
          <div className="bg-purple-50 rounded-xl p-3 flex items-center">
            <div className="bg-white p-2 rounded-xl shadow-md">
              <p className="text-sm">
                "That's more than 4 months! I need to find ways to save faster or earn more money."
              </p>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: "Creating a Plan",
      content: (
        <div className="space-y-4">
          <div className="bg-yellow-50 rounded-xl p-4">
            <h3 className="font-medium mb-2">Alex's Saving Plan:</h3>
            <div className="space-y-2">
              <div className="bg-white p-2 rounded-lg shadow-sm">
                <p className="text-sm">✅ Put aside $20 every week from chores</p>
              </div>
              <div className="bg-white p-2 rounded-lg shadow-sm">
                <p className="text-sm">✅ Cut back on snacks and save $5 more per week</p>
              </div>
              <div className="bg-white p-2 rounded-lg shadow-sm">
                <p className="text-sm">✅ Offer to mow lawns on weekends for extra $15</p>
              </div>
              <div className="bg-white p-2 rounded-lg shadow-sm">
                <p className="text-sm">✅ Total weekly savings: $40</p>
              </div>
              <div className="bg-white p-2 rounded-lg shadow-sm">
                <p className="text-sm">
                  New timeline: $350 ÷ $40 per week = <span className="text-green-600">8.75 weeks</span>
                </p>
              </div>
            </div>
          </div>
          <div className="bg-purple-50 rounded-xl p-3 flex items-center">
            <img
              src="/placeholder.svg?height=100&width=100"
              alt="Happy teen"
              className="w-16 h-16 object-cover rounded-full mr-3"
            />
            <div className="bg-white p-2 rounded-xl shadow-md">
              <p className="text-sm">"That's much better! Just over 2 months of saving."</p>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: "Tracking Progress",
      content: (
        <div className="space-y-4">
          <div className="bg-blue-50 rounded-xl p-4">
            <h3 className="font-medium mb-3">Alex's Savings Tracker</h3>
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div className="bg-blue-500 h-4 rounded-full w-3/4"></div>
            </div>
            <div className="flex justify-between mt-1 text-xs">
              <span>$0</span>
              <span className="font-medium">$260 saved so far</span>
              <span>$350</span>
            </div>
          </div>
          <div className="bg-green-50 p-4 rounded-xl">
            <h3 className="font-medium mb-2">Tracking Tips:</h3>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              <li>Update your savings tracker weekly</li>
              <li>Keep your money in a safe place or savings account</li>
              <li>Celebrate small milestones (like saving $100)</li>
              <li>Adjust your plan if needed</li>
            </ul>
          </div>
          <div className="bg-purple-50 rounded-xl p-3 flex items-center">
            <div className="bg-white p-2 rounded-xl shadow-md">
              <p className="text-sm">"I'm getting closer to my goal! Seeing my progress keeps me motivated."</p>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: "Success!",
      content: (
        <div className="space-y-4">
          <div className="bg-green-50 rounded-xl p-4 text-center">
            <img
              src="/placeholder.svg?height=200&width=200"
              alt="Teen with new bike"
              className="w-32 h-32 object-cover rounded-full mx-auto mb-3"
            />
            <h3 className="font-medium">Goal Achieved!</h3>
            <p className="text-sm">After 9 weeks of saving, Alex bought the mountain bike!</p>
          </div>
          <div className="bg-blue-50 p-4 rounded-xl">
            <h3 className="font-medium mb-2">What Alex Learned:</h3>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              <li>Setting a specific goal makes saving easier</li>
              <li>Creating a plan speeds up the process</li>
              <li>Tracking progress helps stay motivated</li>
              <li>Small sacrifices lead to big rewards</li>
              <li>The satisfaction of buying something with your own money is amazing!</li>
            </ul>
          </div>
          <div className="bg-purple-50 rounded-xl p-3 flex items-center">
            <img
              src="/placeholder.svg?height=100&width=100"
              alt="Happy teen with bike"
              className="w-16 h-16 object-cover rounded-full mr-3"
            />
            <div className="bg-white p-2 rounded-xl shadow-md">
              <p className="text-sm">"Now I'm going to start saving for a new helmet and some bike accessories!"</p>
            </div>
          </div>
        </div>
      ),
    },
  ]

  const nextPage = () => {
    if (currentPage < lessonPages.length - 1) {
      setCurrentPage(currentPage + 1)
    }
  }

  const prevPage = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1)
    }
  }

  return (
    <main className="flex min-h-screen flex-col">
      <div className="bg-white border-b p-4 flex items-center justify-between sticky top-0 z-10">
        <Link href="/learn" className="text-gray-600">
          <ChevronLeft className="h-6 w-6" />
        </Link>
        <h1 className="text-lg font-bold">Saving Basics</h1>
        <Link href="/learn" className="text-gray-600">
          <Home className="h-5 w-5" />
        </Link>
      </div>

      <div className="flex-1 container px-4 py-6">
        <div className="mb-6">
          <h2 className="text-xl font-bold mb-1">{lessonPages[currentPage].title}</h2>
          <div className="w-full bg-gray-200 rounded-full h-1.5">
            <div
              className="bg-blue-500 h-1.5 rounded-full transition-all duration-300"
              style={{ width: `${((currentPage + 1) / lessonPages.length) * 100}%` }}
            ></div>
          </div>
          <p className="text-xs text-right mt-1 text-gray-500">
            {currentPage + 1} of {lessonPages.length}
          </p>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="mb-8"
          >
            {lessonPages[currentPage].content}
          </motion.div>
        </AnimatePresence>

        <div className="flex justify-between mt-8">
          <Button
            variant="outline"
            onClick={prevPage}
            disabled={currentPage === 0}
            className={currentPage === 0 ? "invisible" : ""}
          >
            <ChevronLeft className="h-4 w-4 mr-1" /> Previous
          </Button>
          {currentPage < lessonPages.length - 1 ? (
            <Button onClick={nextPage}>
              Next <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          ) : (
            <Link href="/learn">
              <Button>Finish Lesson</Button>
            </Link>
          )}
        </div>
      </div>
    </main>
  )
}
