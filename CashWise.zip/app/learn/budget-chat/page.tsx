"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { ChevronLeft, Send, Home } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

type Message = {
  id: number
  text: string
  isBot: boolean
  options?: string[]
}

export default function BudgetChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hi there! I'm your Budget Buddy. I'll help you create a simple budget. Ready to get started?",
      isBot: true,
      options: ["Yes, let's do it!", "What's a budget?"],
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = (text: string) => {
    // Add user message
    const newUserMessage: Message = {
      id: Date.now(),
      text,
      isBot: false,
    }
    setMessages((prev) => [...prev, newUserMessage])
    setInputValue("")

    // Simulate bot typing
    setIsTyping(true)
    setTimeout(() => {
      setIsTyping(false)
      const botResponse = getBotResponse(text, messages)
      setMessages((prev) => [...prev, botResponse])
    }, 1000)
  }

  const getBotResponse = (userMessage: string, previousMessages: Message[]): Message => {
    const lowerCaseMessage = userMessage.toLowerCase()
    const lastBotMessage = [...previousMessages].reverse().find((msg) => msg.isBot)

    // Handle responses based on conversation flow
    if (lastBotMessage?.id === 1) {
      if (lowerCaseMessage.includes("yes") || lowerCaseMessage.includes("do it")) {
        return {
          id: Date.now(),
          text: "Great! First, let's figure out how much money you have coming in. What's your monthly income? This could be allowance, part-time job, etc.",
          isBot: true,
        }
      } else if (lowerCaseMessage.includes("what")) {
        return {
          id: Date.now(),
          text: "A budget is a plan for your money. It helps you track how much money you have coming in and going out. This way, you can make sure you're saving enough and not overspending. Ready to create one?",
          isBot: true,
          options: ["Yes, I'm ready", "Not right now"],
        }
      }
    }

    // Check for income amounts
    if (
      previousMessages.some((msg) => msg.isBot && msg.text.includes("monthly income")) &&
      (lowerCaseMessage.includes("$") || /\d+/.test(lowerCaseMessage))
    ) {
      return {
        id: Date.now(),
        text: "Thanks! Now let's think about your expenses. What are some things you spend money on regularly? For example: snacks, entertainment, clothes, etc.",
        isBot: true,
      }
    }

    // Check for expense categories
    if (
      previousMessages.some((msg) => msg.isBot && msg.text.includes("things you spend money on")) &&
      !lowerCaseMessage.includes("$")
    ) {
      return {
        id: Date.now(),
        text: "Good! Now let's set some spending limits for these categories. What percentage of your income do you want to save each month?",
        isBot: true,
        options: ["10%", "20%", "30%", "I'm not sure"],
      }
    }

    // Check for saving percentage
    if (
      previousMessages.some((msg) => msg.isBot && msg.text.includes("percentage of your income")) &&
      (lowerCaseMessage.includes("%") || lowerCaseMessage.includes("percent") || lowerCaseMessage.includes("not sure"))
    ) {
      return {
        id: Date.now(),
        text: "That's a good start! A common budgeting approach is the 50/30/20 rule: 50% for needs, 30% for wants, and 20% for savings. Would you like me to help you set up this kind of budget?",
        isBot: true,
        options: ["Yes, please", "Tell me more", "No thanks"],
      }
    }

    // Default responses for various keywords
    if (lowerCaseMessage.includes("save") || lowerCaseMessage.includes("saving")) {
      return {
        id: Date.now(),
        text: "Saving is super important! Experts recommend saving at least 10-20% of your income. What are you saving for?",
        isBot: true,
      }
    }

    if (lowerCaseMessage.includes("spend") || lowerCaseMessage.includes("spending")) {
      return {
        id: Date.now(),
        text: "Tracking your spending is key to a good budget. Have you tried using a spending tracker or app before?",
        isBot: true,
        options: ["Yes, I have", "No, never tried one", "What do you recommend?"],
      }
    }

    if (lowerCaseMessage.includes("goal") || lowerCaseMessage.includes("want to buy")) {
      return {
        id: Date.now(),
        text: "Having specific savings goals is motivating! How much do you need to save and by when?",
        isBot: true,
      }
    }

    // Default response
    return {
      id: Date.now(),
      text: "That's interesting! Let's keep building your budget. What other questions do you have about managing your money?",
      isBot: true,
      options: ["How much should I save?", "How to track expenses?", "What's the 50/30/20 rule?"],
    }
  }

  const handleOptionClick = (option: string) => {
    handleSendMessage(option)
  }

  return (
    <main className="flex flex-col h-screen">
      <div className="bg-white border-b p-4 flex items-center justify-between sticky top-0 z-10">
        <Link href="/learn" className="text-gray-600">
          <ChevronLeft className="h-6 w-6" />
        </Link>
        <h1 className="text-lg font-bold">Budget Chat</h1>
        <Link href="/learn" className="text-gray-600">
          <Home className="h-5 w-5" />
        </Link>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <motion.div
            key={message.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex ${message.isBot ? "justify-start" : "justify-end"}`}
          >
            <div
              className={`max-w-[80%] p-3 rounded-lg ${
                message.isBot ? "bg-blue-100 text-blue-900" : "bg-green-100 text-green-900"
              }`}
            >
              <p className="text-sm">{message.text}</p>
              {message.options && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {message.options.map((option) => (
                    <button
                      key={option}
                      onClick={() => handleOptionClick(option)}
                      className="bg-white text-xs py-1 px-2 rounded-full border border-blue-200 hover:bg-blue-50"
                    >
                      {option}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        ))}

        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-blue-100 text-blue-900 p-3 rounded-lg max-w-[80%]">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
                <div
                  className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"
                  style={{ animationDelay: "0.2s" }}
                ></div>
                <div
                  className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"
                  style={{ animationDelay: "0.4s" }}
                ></div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t bg-white">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === "Enter" && inputValue.trim()) {
                handleSendMessage(inputValue)
              }
            }}
            placeholder="Type your message..."
            className="flex-1 p-3 rounded-lg border focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <Button
            onClick={() => {
              if (inputValue.trim()) {
                handleSendMessage(inputValue)
              }
            }}
            className="p-3 rounded-full"
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </main>
  )
}
