"use client"

import { useState, useRef } from "react"
import { motion } from "framer-motion"
import { ChevronLeft, Home, RefreshCw, ChevronRight, ChevronDown } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

type Flashcard = {
  id: number
  term: string
  definition: string
  category: "basics" | "banking" | "investing" | "credit"
}

export default function MoneyTermsPage() {
  const [flipped, setFlipped] = useState<number | null>(null)
  const [currentCategory, setCurrentCategory] = useState<string>("all")
  const [currentIndex, setCurrentIndex] = useState(0)
  const cardRef = useRef<HTMLDivElement>(null)

  const flashcards: Flashcard[] = [
    {
      id: 1,
      term: "Budget",
      definition: "A plan for how you will spend your money, usually covering a specific time period like a month.",
      category: "basics",
    },
    {
      id: 2,
      term: "Income",
      definition: "Money that you receive, such as from an allowance, gifts, or a job.",
      category: "basics",
    },
    {
      id: 3,
      term: "Expense",
      definition: "Money that you spend on things you need or want.",
      category: "basics",
    },
    {
      id: 4,
      term: "Savings",
      definition: "Money that you set aside for future use instead of spending it now.",
      category: "basics",
    },
    {
      id: 5,
      term: "Debit Card",
      definition: "A card that takes money directly from your bank account when you make a purchase.",
      category: "banking",
    },
    {
      id: 6,
      term: "Credit Card",
      definition:
        "A card that lets you borrow money to make purchases. You must pay back what you spend, often with interest.",
      category: "credit",
    },
    {
      id: 7,
      term: "Interest",
      definition: "Money paid for the use of money. You earn interest when you save and pay interest when you borrow.",
      category: "banking",
    },
    {
      id: 8,
      term: "Loan",
      definition: "Money that you borrow and promise to pay back, usually with interest added.",
      category: "credit",
    },
    {
      id: 9,
      term: "Checking Account",
      definition: "A bank account used for everyday spending, like buying things with a debit card.",
      category: "banking",
    },
    {
      id: 10,
      term: "Savings Account",
      definition: "A bank account meant for saving money that you don't need right away. It usually earns interest.",
      category: "banking",
    },
    {
      id: 11,
      term: "Stock",
      definition:
        "A small ownership share in a company. The value can go up or down based on how well the company does.",
      category: "investing",
    },
    {
      id: 12,
      term: "Investment",
      definition: "Something you buy with the hope that it will increase in value over time.",
      category: "investing",
    },
  ]

  const filteredCards =
    currentCategory === "all" ? flashcards : flashcards.filter((card) => card.category === currentCategory)

  const handleFlip = (id: number) => {
    if (flipped === id) {
      setFlipped(null)
    } else {
      setFlipped(id)
    }
  }

  const nextCard = () => {
    setFlipped(null)
    if (currentIndex < filteredCards.length - 1) {
      setCurrentIndex(currentIndex + 1)
    } else {
      setCurrentIndex(0) // Loop back to the beginning
    }
  }

  const prevCard = () => {
    setFlipped(null)
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1)
    } else {
      setCurrentIndex(filteredCards.length - 1) // Loop to the end
    }
  }

  const shuffleCards = () => {
    setFlipped(null)
    setCurrentIndex(Math.floor(Math.random() * filteredCards.length))
  }

  return (
    <main className="flex min-h-screen flex-col">
      <div className="bg-white border-b p-4 flex items-center justify-between sticky top-0 z-10">
        <Link href="/learn" className="text-gray-600">
          <ChevronLeft className="h-6 w-6" />
        </Link>
        <h1 className="text-lg font-bold">Money Terms</h1>
        <Link href="/learn" className="text-gray-600">
          <Home className="h-5 w-5" />
        </Link>
      </div>

      <div className="container px-4 py-6 flex-1 flex flex-col">
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Flashcards</h2>
            <div className="relative">
              <select
                value={currentCategory}
                onChange={(e) => {
                  setCurrentCategory(e.target.value)
                  setCurrentIndex(0)
                  setFlipped(null)
                }}
                className="appearance-none bg-gray-100 py-1 px-3 pr-8 rounded-lg text-sm"
              >
                <option value="all">All Terms</option>
                <option value="basics">Basics</option>
                <option value="banking">Banking</option>
                <option value="credit">Credit</option>
                <option value="investing">Investing</option>
              </select>
              <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
            </div>
          </div>

          <p className="text-sm text-gray-500 mb-4">Tap the card to flip it and see the definition</p>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center mb-8">
          {filteredCards.length > 0 ? (
            <div className="w-full max-w-md perspective-1000">
              <motion.div
                  className="flip-card-inner w-full h-64 relative cursor-pointer"
                  onClick={() => handleFlip(filteredCards[currentIndex].id)}
                  animate={{ rotateY: flipped === filteredCards[currentIndex].id ? 180 : 0 }}
                  initial={false}
                  transition={{ duration: 0.6, type: "spring" }}
                  style={{ transformStyle: "preserve-3d" }}
                >
                  {/* Front of card */}
                  <div className="flip-card-front absolute w-full h-full backface-hidden rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 text-white p-6 flex flex-col items-center justify-center shadow-lg">
                    <h3 className="text-2xl font-bold text-center">{filteredCards[currentIndex].term}</h3>
                    <p className="mt-4 text-sm opacity-80 text-center">Tap to see definition</p>
                  </div>

                  {/* Back of card */}
                  <div className="flip-card-back absolute w-full h-full backface-hidden rounded-xl bg-white p-6 flex flex-col items-center justify-center shadow-lg rotate-y-180 border-2 border-purple-200">
                    <p className="text-center text-gray-800">{filteredCards[currentIndex].definition}</p>
                    <span className="mt-4 px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded-full">
                      {filteredCards[currentIndex].category.charAt(0).toUpperCase() +
                        filteredCards[currentIndex].category.slice(1)}
                    </span>
                  </div>
                </motion.div>
            </div>
          ) : (
            <p className="text-gray-500">No flashcards available for this category.</p>
          )}

          <div className="mt-8 flex items-center justify-center gap-4">
            <Button variant="outline" onClick={prevCard} className="rounded-full p-3">
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <span className="text-sm text-gray-500">
              {currentIndex + 1} / {filteredCards.length}
            </span>
            <Button variant="outline" onClick={nextCard} className="rounded-full p-3">
              <ChevronRight className="h-5 w-5" />
            </Button>
            <Button variant="outline" onClick={shuffleCards} className="rounded-full p-3 ml-2">
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <style jsx>{`
          .perspective-1000 {
            perspective: 1000px;
          }

          .flip-card-inner {
            transform-style: preserve-3d;
          }

          .backface-hidden {
            backface-visibility: hidden;
          }

          .flip-card-back {
            transform: rotateY(180deg);
          }
        `}</style>

      </div>
    </main>
  )
}
