"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useRouter } from "next/navigation"
import { saveAvatar } from "@/lib/api"

const skinTones = ["#FFDBAC", "#F1C27D", "#E0AC69", "#C68642", "#8D5524"]
const hairStyles = ["short", "medium", "long", "curly", "bald"]
const hairColors = ["#000000", "#A52A2A", "#FFD700", "#FF0000", "#808080"]
const outfits = ["casual", "formal", "sporty", "trendy", "nerdy"]

export default function AvatarPage() {
  const router = useRouter()
  const [avatar, setAvatar] = useState({
    skinTone: skinTones[0],
    hairStyle: hairStyles[0],
    hairColor: hairColors[0],
    outfit: outfits[0],
  })

  const handleSave = async () => {
    try {
      await saveAvatar(avatar)
      router.push("/")
    } catch (error) {
      console.error("Failed to save avatar:", error)
    }
  }

  return (
    <motion.main initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">Create Your Avatar</h1>
      <p className="text-gray-600">Customize your look to represent you in FinMate!</p>

      <div className="flex flex-col items-center py-6">
        <div className="w-40 h-40 bg-white rounded-full border-4 border-[#84DCCF] overflow-hidden flex items-center justify-center mb-4">
          <div className="w-32 h-32 rounded-full" style={{ backgroundColor: avatar.skinTone }}>
            {/* This is a placeholder for the avatar preview */}
            {/* In a real app, you would render the avatar based on selected options */}
          </div>
        </div>

        <div className="text-center">
          <h2 className="font-bold">Your Avatar</h2>
          <p className="text-sm text-gray-500">Looking good!</p>
        </div>
      </div>

      <div className="space-y-6">
        <div>
          <h3 className="font-bold mb-2">Skin Tone</h3>
          <div className="flex justify-between">
            {skinTones.map((tone, index) => (
              <button
                key={index}
                className={`w-12 h-12 rounded-full ${avatar.skinTone === tone ? "ring-4 ring-[#84DCCF]" : "ring-2 ring-gray-200"}`}
                style={{ backgroundColor: tone }}
                onClick={() => setAvatar({ ...avatar, skinTone: tone })}
              />
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-bold mb-2">Hair Style</h3>
          <div className="grid grid-cols-5 gap-2">
            {hairStyles.map((style, index) => (
              <button
                key={index}
                className={`p-2 rounded-2xl text-center text-xs ${avatar.hairStyle === style ? "bg-[#84DCCF]" : "bg-gray-100"}`}
                onClick={() => setAvatar({ ...avatar, hairStyle: style })}
              >
                {style.charAt(0).toUpperCase() + style.slice(1)}
              </button>
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-bold mb-2">Hair Color</h3>
          <div className="flex justify-between">
            {hairColors.map((color, index) => (
              <button
                key={index}
                className={`w-12 h-12 rounded-full ${avatar.hairColor === color ? "ring-4 ring-[#84DCCF]" : "ring-2 ring-gray-200"}`}
                style={{ backgroundColor: color }}
                onClick={() => setAvatar({ ...avatar, hairColor: color })}
              />
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-bold mb-2">Outfit</h3>
          <div className="grid grid-cols-3 gap-2">
            {outfits.map((outfit, index) => (
              <button
                key={index}
                className={`p-3 rounded-2xl text-center ${avatar.outfit === outfit ? "bg-[#84DCCF]" : "bg-gray-100"}`}
                onClick={() => setAvatar({ ...avatar, outfit: outfit })}
              >
                {outfit.charAt(0).toUpperCase() + outfit.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="pt-4">
        <button
          onClick={handleSave}
          className="w-full py-3 bg-[#84DCCF] rounded-2xl font-medium shadow-md hover:bg-opacity-90 transition-all"
        >
          Save Avatar
        </button>
      </div>
    </motion.main>
  )
}
