"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, CreditCard, Building, Coins, PiggyBank, Users, CheckCircle, XCircle } from "lucide-react"
import confetti from "canvas-confetti"

export default function BankAdventurePage() {
  const [gameState, setGameState] = useState<"intro" | "playing" | "results">("intro")
  const [currentScene, setCurrentScene] = useState(0)
  const [score, setScore] = useState(0)
  const [showQuestion, setShowQuestion] = useState(false)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showFeedback, setShowFeedback] = useState(false)

  // Game scenes
  const scenes = [
    {
      title: "Welcome to the Bank",
      description:
        "Today you're visiting the bank to learn how it works. The bank manager is ready to show you around!",
      image: "/placeholder.svg?height=200&width=300&text=Bank+Entrance",
      icon: Building,
    },
    {
      title: "The Vault",
      description:
        "This is where the bank keeps money safe. The vault has thick walls and special locks to protect everyone's savings.",
      image: "/placeholder.svg?height=200&width=300&text=Bank+Vault",
      icon: Coins,
    },
    {
      title: "Opening an Account",
      description:
        "To use a bank, you need to open an account. This is like having your own special spot in the bank to keep your money.",
      image: "/placeholder.svg?height=200&width=300&text=Bank+Account",
      icon: Users,
    },
    {
      title: "Saving Money",
      description:
        "When you put money in a savings account, the bank pays you extra money called interest. The longer you save, the more you earn!",
      image: "/placeholder.svg?height=200&width=300&text=Savings",
      icon: PiggyBank,
    },
    {
      title: "Using a Bank Card",
      description:
        "A bank card lets you access your money without carrying cash. You can use it in stores or at ATMs to get cash when you need it.",
      image: "/placeholder.svg?height=200&width=300&text=Bank+Card",
      icon: CreditCard,
    },
  ]

  // Questions for each scene
  const questions = [
    {
      question: "Why do people use banks?",
      options: ["To watch TV", "To keep their money safe", "To buy ice cream", "To play games"],
      correctIndex: 1,
      explanation:
        "Banks provide a safe place to store money instead of keeping it at home where it could be lost or stolen.",
    },
    {
      question: "What is a bank vault used for?",
      options: [
        "For bank employees to take naps",
        "To store office supplies",
        "To safely store money and valuable items",
        "To hold birthday parties",
      ],
      correctIndex: 2,
      explanation:
        "Bank vaults have special security features to protect money and valuable items that people store at the bank.",
    },
    {
      question: "What do you need to do first to use a bank?",
      options: ["Buy a car", "Open a bank account", "Learn to swim", "Become a bank manager"],
      correctIndex: 1,
      explanation:
        "Opening a bank account is the first step to using banking services. It's like registering so the bank knows who you are.",
    },
    {
      question: "What is interest?",
      options: [
        "When you're interested in something",
        "Extra money the bank pays you for saving with them",
        "A type of ice cream",
        "The bank manager's name",
      ],
      correctIndex: 1,
      explanation: "Interest is extra money the bank pays you as a reward for keeping your money in the bank.",
    },
    {
      question: "What can you do with a bank card?",
      options: ["Use it as a bookmark", "Play card games", "Access your money to make purchases", "Open doors"],
      correctIndex: 2,
      explanation:
        "Bank cards let you access your money to make purchases in stores or online, or to get cash from ATMs.",
    },
  ]

  const startGame = () => {
    setGameState("playing")
    setCurrentScene(0)
    setScore(0)
    setShowQuestion(false)
    setCurrentQuestion(0)
    setSelectedAnswer(null)
    setShowFeedback(false)
  }

  const nextScene = () => {
    if (currentScene < scenes.length - 1) {
      setCurrentScene(currentScene + 1)
      setShowQuestion(false)
      setSelectedAnswer(null)
      setShowFeedback(false)
    } else {
      // Game completed
      setGameState("results")

      // Trigger confetti for good scores
      if (score >= 3) {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        })
      }
    }
  }

  const showSceneQuestion = () => {
    setShowQuestion(true)
    setCurrentQuestion(currentScene)
  }

  const selectAnswer = (index: number) => {
    setSelectedAnswer(index)
    setShowFeedback(true)

    if (index === questions[currentQuestion].correctIndex) {
      setScore(score + 1)
    }
  }

  return (
    <div className="p-4 pb-20 min-h-screen bg-[#EEE5E9]">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/bank-card" className="p-2 rounded-full bg-white shadow">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold">Bank Adventure</h1>
      </div>

      {gameState === "intro" && (
        <div className="bg-white p-6 rounded-2xl shadow-md">
          <div className="flex justify-center mb-4">
            <div className="w-20 h-20 bg-[#84DCCF] rounded-full flex items-center justify-center">
              <Building size={40} className="text-white" />
            </div>
          </div>

          <h2 className="text-xl font-bold mb-3 text-center">Welcome to Bank Adventure!</h2>
          <p className="mb-4 text-center">
            Join us on an exciting journey to learn all about banks and how they help people manage their money!
          </p>

          <div className="bg-[#84DCCF]/10 p-4 rounded-xl mb-4">
            <h3 className="font-bold mb-2">What you'll learn:</h3>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">
                <CheckCircle size={16} className="text-[#84DCCF]" />
                <span>How banks keep your money safe</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle size={16} className="text-[#84DCCF]" />
                <span>What bank accounts are</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle size={16} className="text-[#84DCCF]" />
                <span>How saving money works</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle size={16} className="text-[#84DCCF]" />
                <span>How to use bank cards</span>
              </li>
            </ul>
          </div>

          <button onClick={startGame} className="w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
            Start Adventure
          </button>
        </div>
      )}

      {gameState === "playing" && (
        <div className="space-y-6">
          {!showQuestion ? (
            <div className="bg-white p-4 rounded-2xl shadow-md">
              <div className="flex justify-between items-center mb-4">
                <h2 className="font-bold text-lg flex items-center gap-2">
                  \{scenes[currentScene].icon && <scenes[currentScene].icon className="text-[#84DCCF]" />}
                  {scenes[currentScene].title}
                </h2>
                <div className="text-sm bg-[#84DCCF] px-2 py-1 rounded-full text-white">
                  {currentScene + 1}/{scenes.length}
                </div>
              </div>

              <div className="mb-4">
                <Image
                  src={scenes[currentScene].image || "/placeholder.svg"}
                  alt={scenes[currentScene].title}
                  width={300}
                  height={200}
                  className="w-full h-48 object-cover rounded-xl"
                />
              </div>

              <p className="text-gray-600 mb-6">{scenes[currentScene].description}</p>

              <div className="flex gap-3">
                <button onClick={showSceneQuestion} className="flex-1 py-3 bg-[#84DCCF] rounded-xl font-medium">
                  Take Quiz
                </button>
                <button onClick={nextScene} className="flex-1 py-3 bg-gray-100 rounded-xl font-medium">
                  {currentScene < scenes.length - 1 ? "Skip" : "Finish"}
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white p-4 rounded-2xl shadow-md">
              <div className="flex justify-between items-center mb-4">
                <h2 className="font-bold text-lg">Quiz Question</h2>
                <div className="text-sm bg-[#EF626C] px-2 py-1 rounded-full text-white">
                  Question {currentQuestion + 1}
                </div>
              </div>

              <p className="font-medium mb-4">{questions[currentQuestion].question}</p>

              <div className="space-y-3 mb-6">
                {questions[currentQuestion].options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => selectAnswer(index)}
                    disabled={showFeedback}
                    className={`w-full p-3 rounded-xl text-left ${
                      selectedAnswer === index
                        ? index === questions[currentQuestion].correctIndex
                          ? "bg-green-100 border-2 border-green-500"
                          : "bg-red-100 border-2 border-red-500"
                        : "bg-gray-100 hover:bg-gray-200"
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span>{option}</span>
                      {showFeedback &&
                        (index === questions[currentQuestion].correctIndex ? (
                          <CheckCircle className="text-green-500" size={20} />
                        ) : selectedAnswer === index ? (
                          <XCircle className="text-red-500" size={20} />
                        ) : null)}
                    </div>
                  </button>
                ))}
              </div>

              {showFeedback && (
                <div
                  className={`p-3 rounded-xl mb-4 ${
                    selectedAnswer === questions[currentQuestion].correctIndex ? "bg-green-100" : "bg-red-100"
                  }`}
                >
                  <p className="font-medium">
                    {selectedAnswer === questions[currentQuestion].correctIndex ? "Correct!" : "Incorrect!"}
                  </p>
                  <p className="text-sm">{questions[currentQuestion].explanation}</p>
                </div>
              )}

              {showFeedback && (
                <button onClick={nextScene} className="w-full py-3 bg-[#84DCCF] rounded-xl font-medium">
                  {currentScene < scenes.length - 1 ? "Next Scene" : "Finish"}
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {gameState === "results" && (
        <div className="bg-white p-6 rounded-2xl shadow-md text-center">
          <div className="mb-4">
            <div className="w-20 h-20 bg-[#84DCCF] rounded-full flex items-center justify-center mx-auto">
              <Building size={40} className="text-white" />
            </div>
          </div>

          <h2 className="text-2xl font-bold mb-2">Adventure Complete!</h2>
          <p className="mb-4">You've completed the Bank Adventure and learned all about how banks work!</p>

          <div className="text-4xl font-bold text-[#EF626C] mb-6">
            {score}/{questions.length}
          </div>

          <div className="bg-[#84DCCF]/10 p-4 rounded-xl mb-6 text-left">
            <h3 className="font-bold mb-2">What You Learned:</h3>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">
                <CheckCircle size={16} className="text-[#84DCCF]" />
                <span>Banks keep money safe in special vaults</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle size={16} className="text-[#84DCCF]" />
                <span>You need to open an account to use a bank</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle size={16} className="text-[#84DCCF]" />
                <span>Banks pay interest when you save money with them</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle size={16} className="text-[#84DCCF]" />
                <span>Bank cards help you access your money safely</span>
              </li>
            </ul>
          </div>

          <div className="space-y-3">
            <Link href="/bank-card" className="block w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
              Back to Bank Card
            </Link>
            <button onClick={startGame} className="block w-full py-3 bg-gray-100 rounded-2xl font-medium">
              Play Again
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
