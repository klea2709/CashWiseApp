"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowLeft, DollarSign, Calendar, Percent, HelpCircle } from "lucide-react"
import { useLoanCalculator } from "@/lib/hooks/useLoanCalculator"

export default function LoanLabPage() {
  const {
    loanAmount,
    setLoanAmount,
    interestRate,
    setInterestRate,
    loanTerm,
    setLoanTerm,
    monthlyPayment,
    totalInterest,
    totalCost,
    amortizationSchedule,
    calculateLoan,
    resetLoan,
  } = useLoanCalculator()

  const [showSchedule, setShowSchedule] = useState(false)

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="p-4 space-y-6 pb-20"
    >
      <div className="flex items-center gap-2">
        <Link href="/" className="p-2 rounded-full bg-gray-100">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold">Loan Lab</h1>
      </div>

      <div className="bg-white p-4 rounded-2xl shadow-md">
        <h2 className="font-bold mb-4">Loan Calculator</h2>

        <div className="space-y-4">
          <div>
            <label className="flex items-center gap-2 text-sm font-medium mb-1">
              <DollarSign size={16} />
              Loan Amount
            </label>
            <div className="flex items-center">
              <span className="bg-gray-100 p-3 rounded-l-2xl">$</span>
              <input
                type="number"
                value={loanAmount}
                onChange={(e) => setLoanAmount(Number(e.target.value))}
                min="100"
                max="10000"
                className="flex-1 p-3 border-y border-r rounded-r-2xl focus:outline-none focus:ring-2 focus:ring-[#84DCCF]"
              />
            </div>
            <input
              type="range"
              min="100"
              max="10000"
              step="100"
              value={loanAmount}
              onChange={(e) => setLoanAmount(Number(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer mt-2"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>$100</span>
              <span>$10,000</span>
            </div>
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium mb-1">
              <Percent size={16} />
              Interest Rate (%)
            </label>
            <input
              type="number"
              value={interestRate}
              onChange={(e) => setInterestRate(Number(e.target.value))}
              min="1"
              max="20"
              step="0.1"
              className="w-full p-3 border rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#84DCCF]"
            />
            <input
              type="range"
              min="1"
              max="20"
              step="0.1"
              value={interestRate}
              onChange={(e) => setInterestRate(Number(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer mt-2"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>1%</span>
              <span>20%</span>
            </div>
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium mb-1">
              <Calendar size={16} />
              Loan Term (months)
            </label>
            <input
              type="number"
              value={loanTerm}
              onChange={(e) => setLoanTerm(Number(e.target.value))}
              min="3"
              max="60"
              className="w-full p-3 border rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#84DCCF]"
            />
            <input
              type="range"
              min="3"
              max="60"
              step="1"
              value={loanTerm}
              onChange={(e) => setLoanTerm(Number(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer mt-2"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>3 months</span>
              <span>60 months</span>
            </div>
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button onClick={resetLoan} className="flex-1 py-3 bg-gray-100 rounded-2xl font-medium">
            Reset
          </button>
          <button onClick={calculateLoan} className="flex-1 py-3 bg-[#84DCCF] rounded-2xl font-medium">
            Calculate
          </button>
        </div>
      </div>

      {monthlyPayment > 0 && (
        <div className="bg-white p-4 rounded-2xl shadow-md">
          <h2 className="font-bold mb-4">Loan Summary</h2>

          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-xl">
              <span className="text-gray-600">Monthly Payment:</span>
              <span className="font-bold">${monthlyPayment.toFixed(2)}</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-xl">
              <span className="text-gray-600">Total Interest:</span>
              <span className="font-bold text-[#EF626C]">${totalInterest.toFixed(2)}</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-xl">
              <span className="text-gray-600">Total Cost:</span>
              <span className="font-bold">${totalCost.toFixed(2)}</span>
            </div>
          </div>

          <button
            onClick={() => setShowSchedule(!showSchedule)}
            className="w-full mt-4 py-3 bg-gray-100 rounded-2xl font-medium flex items-center justify-center gap-2"
          >
            {showSchedule ? "Hide" : "Show"} Repayment Schedule
            <HelpCircle size={16} />
          </button>

          {showSchedule && (
            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="p-2 text-left">Month</th>
                    <th className="p-2 text-right">Payment</th>
                    <th className="p-2 text-right">Principal</th>
                    <th className="p-2 text-right">Interest</th>
                    <th className="p-2 text-right">Balance</th>
                  </tr>
                </thead>
                <tbody>
                  {amortizationSchedule.map((payment) => (
                    <tr key={payment.month} className="border-b">
                      <td className="p-2">{payment.month}</td>
                      <td className="p-2 text-right">${payment.payment.toFixed(2)}</td>
                      <td className="p-2 text-right">${payment.principal.toFixed(2)}</td>
                      <td className="p-2 text-right">${payment.interest.toFixed(2)}</td>
                      <td className="p-2 text-right">${payment.balance.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </motion.main>
  )
}
