"use client"
import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowLeft, TrendingUp, TrendingDown, AlertTriangle, HelpCircle } from "lucide-react"
import { useCryptoCaution } from "@/lib/hooks/useCryptoCaution"

export default function CryptoCautionPage() {
  const {
    balance,
    cryptos,
    portfolio,
    marketHistory,
    buyAmount,
    setBuyAmount,
    sellAmount,
    setSellAmount,
    selectedCrypto,
    setSelectedCrypto,
    buyCrypto,
    sellCrypto,
    nextDay,
    showQuiz,
    quizQuestion,
    quizOptions,
    checkAnswer,
    quizResult,
    continueAfterQuiz,
    gameState,
    startGame,
    endGame,
  } = useCryptoCaution()

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="p-4 space-y-6 pb-20"
    >
      <div className="flex items-center gap-2">
        <Link href="/" className="p-2 rounded-full bg-gray-100">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold">Crypto Caution</h1>
      </div>

      {gameState === "intro" && (
        <div className="bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-xl font-bold mb-3">Welcome to Crypto Caution!</h2>
          <p className="mb-4">
            Learn about cryptocurrency risks and rewards in this simulation. Remember, this is for educational purposes
            only!
          </p>
          <div className="flex items-center gap-2 p-3 bg-yellow-50 rounded-xl mb-4">
            <AlertTriangle className="text-yellow-500" />
            <p className="text-sm">Cryptocurrencies are highly volatile and risky investments in real life.</p>
          </div>
          <button onClick={startGame} className="w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
            Start Simulation
          </button>
        </div>
      )}

      {gameState === "playing" && !showQuiz && (
        <>
          <div className="bg-white p-4 rounded-2xl shadow-md">
            <div className="flex justify-between items-center mb-2">
              <h2 className="font-bold">Your Balance</h2>
              <button className="p-1 rounded-full bg-gray-100">
                <HelpCircle size={16} />
              </button>
            </div>
            <div className="text-2xl font-bold mb-2">${balance.toFixed(2)}</div>

            <h3 className="font-medium mt-4 mb-2">Your Portfolio</h3>
            <div className="space-y-2">
              {Object.keys(portfolio).length > 0 ? (
                Object.entries(portfolio).map(([symbol, amount]) => (
                  <div key={symbol} className="flex justify-between items-center p-2 bg-gray-50 rounded-xl">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                        {symbol.charAt(0)}
                      </div>
                      <div>
                        <div className="font-medium">{cryptos.find((c) => c.symbol === symbol)?.name}</div>
                        <div className="text-xs text-gray-500">
                          {amount} {symbol}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">
                        ${(amount * cryptos.find((c) => c.symbol === symbol)?.price || 0).toFixed(2)}
                      </div>
                      <div className="text-xs flex items-center gap-1">
                        {cryptos.find((c) => c.symbol === symbol)?.change >= 0 ? (
                          <>
                            <TrendingUp size={12} className="text-green-500" />
                            <span className="text-green-500">{cryptos.find((c) => c.symbol === symbol)?.change}%</span>
                          </>
                        ) : (
                          <>
                            <TrendingDown size={12} className="text-red-500" />
                            <span className="text-red-500">{cryptos.find((c) => c.symbol === symbol)?.change}%</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-2 text-gray-500">No crypto assets yet</div>
              )}
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl shadow-md">
            <h2 className="font-bold mb-3">Crypto Market</h2>

            <div className="space-y-3">
              {cryptos.map((crypto) => (
                <div
                  key={crypto.symbol}
                  className={`p-3 rounded-xl border-2 ${
                    selectedCrypto === crypto.symbol ? "border-[#84DCCF] bg-[#84DCCF]/10" : "border-transparent"
                  }`}
                  onClick={() => setSelectedCrypto(crypto.symbol)}
                >
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                        {crypto.symbol.charAt(0)}
                      </div>
                      <div>
                        <div className="font-medium">{crypto.name}</div>
                        <div className="text-xs text-gray-500">{crypto.symbol}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">${crypto.price.toFixed(2)}</div>
                      <div className="text-xs flex items-center gap-1 justify-end">
                        {crypto.change >= 0 ? (
                          <>
                            <TrendingUp size={12} className="text-green-500" />
                            <span className="text-green-500">{crypto.change}%</span>
                          </>
                        ) : (
                          <>
                            <TrendingDown size={12} className="text-red-500" />
                            <span className="text-red-500">{crypto.change}%</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {selectedCrypto && (
            <div className="bg-white p-4 rounded-2xl shadow-md">
              <h2 className="font-bold mb-3">Trade {selectedCrypto}</h2>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Buy {selectedCrypto}</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={buyAmount}
                      onChange={(e) => setBuyAmount(Number(e.target.value))}
                      min="0"
                      step="0.01"
                      className="flex-1 p-3 border rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#84DCCF]"
                      placeholder="Amount to buy"
                    />
                    <button
                      onClick={buyCrypto}
                      disabled={
                        !buyAmount ||
                        buyAmount <= 0 ||
                        buyAmount * (cryptos.find((c) => c.symbol === selectedCrypto)?.price || 0) > balance
                      }
                      className={`px-4 py-3 rounded-2xl font-medium ${
                        buyAmount &&
                        buyAmount > 0 &&
                        buyAmount * (cryptos.find((c) => c.symbol === selectedCrypto)?.price || 0) <= balance
                          ? "bg-[#84DCCF]"
                          : "bg-gray-300"
                      }`}
                    >
                      Buy
                    </button>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Cost: ${(buyAmount * (cryptos.find((c) => c.symbol === selectedCrypto)?.price || 0)).toFixed(2)}
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium mb-1 block">Sell {selectedCrypto}</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={sellAmount}
                      onChange={(e) => setSellAmount(Number(e.target.value))}
                      min="0"
                      max={portfolio[selectedCrypto] || 0}
                      step="0.01"
                      className="flex-1 p-3 border rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#84DCCF]"
                      placeholder="Amount to sell"
                    />
                    <button
                      onClick={sellCrypto}
                      disabled={!sellAmount || sellAmount <= 0 || sellAmount > (portfolio[selectedCrypto] || 0)}
                      className={`px-4 py-3 rounded-2xl font-medium ${
                        sellAmount && sellAmount > 0 && sellAmount <= (portfolio[selectedCrypto] || 0)
                          ? "bg-gray-100"
                          : "bg-gray-300"
                      }`}
                    >
                      Sell
                    </button>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Value: ${(sellAmount * (cryptos.find((c) => c.symbol === selectedCrypto)?.price || 0)).toFixed(2)}
                  </div>
                </div>
              </div>
            </div>
          )}

          <button onClick={nextDay} className="w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
            Next Day
          </button>
        </>
      )}

      {gameState === "playing" && showQuiz && (
        <div className="bg-white p-6 rounded-2xl shadow-md">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="text-yellow-500" size={24} />
            <h2 className="text-xl font-bold">Crypto Safety Quiz</h2>
          </div>

          <p className="mb-4">{quizQuestion}</p>

          <div className="space-y-3 mb-6">
            {quizOptions.map((option, index) => (
              <button
                key={index}
                onClick={() => checkAnswer(index)}
                disabled={quizResult !== null}
                className={`w-full p-3 text-left rounded-xl ${
                  quizResult !== null
                    ? index === quizResult.correctIndex
                      ? "bg-green-100 border-2 border-green-500"
                      : quizResult.selectedIndex === index
                        ? "bg-red-100 border-2 border-red-500"
                        : "bg-gray-100"
                    : "bg-gray-100 hover:bg-gray-200"
                }`}
              >
                {option}
              </button>
            ))}
          </div>

          {quizResult && (
            <div className={`p-3 rounded-xl mb-4 ${quizResult.correct ? "bg-green-100" : "bg-red-100"}`}>
              <p className="font-medium">{quizResult.correct ? "Correct!" : "Incorrect!"}</p>
              <p className="text-sm">{quizResult.explanation}</p>
            </div>
          )}

          {quizResult && (
            <button onClick={continueAfterQuiz} className="w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
              Continue
            </button>
          )}
        </div>
      )}

      {gameState === "results" && (
        <div className="bg-white p-6 rounded-2xl shadow-md text-center">
          <h2 className="text-xl font-bold mb-3">Simulation Results</h2>

          <div className="mb-6">
            <div className="text-4xl font-bold mb-2">${balance.toFixed(2)}</div>
            <p className="text-gray-600">
              {balance > 1500
                ? "Amazing! You made some smart trades!"
                : balance > 1000
                  ? "Good job! You ended with a profit."
                  : balance > 500
                    ? "You managed to preserve most of your capital."
                    : "Crypto can be very risky - that's why caution is important!"}
            </p>
          </div>

          <div className="space-y-3 mb-6">
            <div className="flex justify-between">
              <span>Starting balance:</span>
              <span className="font-bold">$1,000.00</span>
            </div>
            <div className="flex justify-between">
              <span>Final balance:</span>
              <span className="font-bold">${balance.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Profit/Loss:</span>
              <span className={`font-bold ${balance >= 1000 ? "text-green-600" : "text-red-600"}`}>
                ${(balance - 1000).toFixed(2)}
              </span>
            </div>
          </div>

          <div className="p-4 bg-yellow-50 rounded-xl mb-6 text-left">
            <h3 className="font-bold flex items-center gap-2">
              <AlertTriangle className="text-yellow-500" />
              Important Lessons
            </h3>
            <ul className="list-disc pl-5 mt-2 text-sm space-y-1">
              <li>Cryptocurrency markets are highly volatile</li>
              <li>Never invest money you can't afford to lose</li>
              <li>Be cautious of scams and fraudulent schemes</li>
              <li>Research thoroughly before investing real money</li>
              <li>Diversification can help manage risk</li>
            </ul>
          </div>

          <div className="flex gap-3">
            <button onClick={startGame} className="flex-1 py-3 bg-gray-100 rounded-2xl font-medium">
              Play Again
            </button>
            <Link href="/" className="flex-1 py-3 bg-[#84DCCF] rounded-2xl font-medium text-center">
              Finish
            </Link>
          </div>
        </div>
      )}
    </motion.main>
  )
}
