"use client"
import { motion } from "framer-motion"
import Link from "next/link"
import { DollarSign, ArrowLeft, Info } from "lucide-react"
import { useBudgetGame } from "@/lib/hooks/useBudgetGame"

export default function BudgetBattlePage() {
  const {
    budget,
    categories,
    allocations,
    setAllocation,
    remainingBudget,
    checkBudget,
    resetBudget,
    score,
    gameState,
  } = useBudgetGame()

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="p-4 space-y-6 pb-20"
    >
      <div className="flex items-center gap-2">
        <Link href="/" className="p-2 rounded-full bg-gray-100">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold">Budget Battle</h1>
      </div>

      {gameState === "intro" && (
        <div className="bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-xl font-bold mb-3">Welcome to Budget Battle!</h2>
          <p className="mb-4">
            You have ${budget} weekly allowance. Allocate your money wisely across different categories to win!
          </p>
          <button onClick={() => resetBudget("playing")} className="w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
            Start Game
          </button>
        </div>
      )}

      {gameState === "playing" && (
        <>
          <div className="bg-white p-4 rounded-2xl shadow-md">
            <div className="flex justify-between items-center mb-2">
              <h2 className="font-bold">Your Weekly Allowance</h2>
              <span className="text-xl font-bold text-[#CBA135]">${budget}</span>
            </div>
            <div className="flex justify-between items-center">
              <h2 className="font-bold">Remaining</h2>
              <span className={`text-xl font-bold ${remainingBudget < 0 ? "text-red-500" : "text-green-500"}`}>
                ${remainingBudget}
              </span>
            </div>
          </div>

          <div className="space-y-4">
            {categories.map((category) => (
              <div key={category.id} className="bg-white p-4 rounded-2xl shadow-md">
                <div className="flex justify-between items-center mb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-full" style={{ backgroundColor: category.color }}>
                      <DollarSign size={20} className="text-white" />
                    </div>
                    <h3 className="font-bold">{category.name}</h3>
                  </div>
                  <button className="p-1 rounded-full bg-gray-100">
                    <Info size={16} />
                  </button>
                </div>

                <div className="mb-3">
                  <p className="text-sm text-gray-600 mb-1">{category.description}</p>
                  <div className="flex justify-between text-sm">
                    <span>Recommended: ${category.recommended}</span>
                    <span>Your allocation: ${allocations[category.id] || 0}</span>
                  </div>
                </div>

                <input
                  type="range"
                  min="0"
                  max={budget}
                  value={allocations[category.id] || 0}
                  onChange={(e) => setAllocation(category.id, Number.parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />

                <div className="flex justify-between mt-2">
                  <button
                    onClick={() => setAllocation(category.id, Math.max(0, (allocations[category.id] || 0) - 5))}
                    className="px-3 py-1 bg-gray-100 rounded-full text-sm"
                  >
                    -$5
                  </button>
                  <button
                    onClick={() => setAllocation(category.id, Math.min(budget, (allocations[category.id] || 0) + 5))}
                    className="px-3 py-1 bg-gray-100 rounded-full text-sm"
                  >
                    +$5
                  </button>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={checkBudget}
            disabled={remainingBudget !== 0}
            className={`w-full py-3 rounded-2xl font-medium ${remainingBudget === 0 ? "bg-[#84DCCF]" : "bg-gray-300"}`}
          >
            Check My Budget
          </button>
        </>
      )}

      {gameState === "results" && (
        <div className="bg-white p-6 rounded-2xl shadow-md text-center">
          <h2 className="text-xl font-bold mb-3">Budget Results</h2>

          <div className="mb-6">
            <div className="text-4xl font-bold mb-2">{score} / 100</div>
            <p className="text-gray-600">
              {score >= 80
                ? "Great job! You're a budgeting pro!"
                : score >= 60
                  ? "Good effort! You're getting better at budgeting."
                  : "Keep practicing! Budgeting takes time to master."}
            </p>
          </div>

          <div className="space-y-3 mb-6">
            {categories.map((category) => (
              <div key={category.id} className="flex justify-between">
                <span>{category.name}</span>
                <div className="flex items-center gap-2">
                  <span className="text-gray-600">Recommended: ${category.recommended}</span>
                  <span
                    className={
                      allocations[category.id] === category.recommended ? "text-green-500 font-bold" : "text-red-500"
                    }
                  >
                    Your: ${allocations[category.id] || 0}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="flex gap-3">
            <button onClick={() => resetBudget("playing")} className="flex-1 py-3 bg-gray-100 rounded-2xl font-medium">
              Try Again
            </button>
            <Link href="/" className="flex-1 py-3 bg-[#84DCCF] rounded-2xl font-medium text-center">
              Finish
            </Link>
          </div>
        </div>
      )}
    </motion.main>
  )
}
