"use client"
import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowLeft, Clock, CheckCircle, XCircle } from "lucide-react"
import { useSpendSmartQuiz } from "@/lib/hooks/useSpendSmartQuiz"

export default function SpendSmartQuizPage() {
  const {
    questions,
    currentQuestionIndex,
    selectedAnswer,
    timeLeft,
    score,
    streak,
    gameState,
    selectAnswer,
    nextQuestion,
    startQuiz,
    restartQuiz,
  } = useSpendSmartQuiz()

  const currentQuestion = questions[currentQuestionIndex]

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="p-4 space-y-6 pb-20"
    >
      <div className="flex items-center gap-2">
        <Link href="/" className="p-2 rounded-full bg-gray-100">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold">Spend Smart Quiz</h1>
      </div>

      {gameState === "intro" && (
        <div className="bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-xl font-bold mb-3">Welcome to Spend Smart Quiz!</h2>
          <p className="mb-4">Test your knowledge about smart spending habits. Answer quickly to earn more points!</p>
          <button onClick={startQuiz} className="w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
            Start Quiz
          </button>
        </div>
      )}

      {gameState === "playing" && (
        <>
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-full shadow">
              <Clock size={18} />
              <span className="font-bold">{timeLeft}s</span>
            </div>

            <div className="flex items-center gap-2">
              <div className="bg-white px-3 py-2 rounded-full shadow">
                <span className="font-bold">Score: {score}</span>
              </div>
              <div className="bg-white px-3 py-2 rounded-full shadow">
                <span className="font-bold">🔥 {streak}</span>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-md">
            <div className="mb-4">
              <span className="text-sm text-gray-500">
                Question {currentQuestionIndex + 1} of {questions.length}
              </span>
              <h2 className="text-xl font-bold">{currentQuestion.question}</h2>
            </div>

            <div className="space-y-3">
              {currentQuestion.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => selectAnswer(index)}
                  disabled={selectedAnswer !== null}
                  className={`w-full p-4 rounded-2xl text-left ${
                    selectedAnswer === null
                      ? "bg-gray-100 hover:bg-gray-200"
                      : selectedAnswer === index
                        ? index === currentQuestion.correctIndex
                          ? "bg-green-100 border-2 border-green-500"
                          : "bg-red-100 border-2 border-red-500"
                        : index === currentQuestion.correctIndex
                          ? "bg-green-100 border-2 border-green-500"
                          : "bg-gray-100"
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span>{option}</span>
                    {selectedAnswer !== null &&
                      (index === currentQuestion.correctIndex ? (
                        <CheckCircle className="text-green-500" size={20} />
                      ) : selectedAnswer === index ? (
                        <XCircle className="text-red-500" size={20} />
                      ) : null)}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {selectedAnswer !== null && (
            <button onClick={nextQuestion} className="w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
              {currentQuestionIndex < questions.length - 1 ? "Next Question" : "See Results"}
            </button>
          )}
        </>
      )}

      {gameState === "results" && (
        <div className="bg-white p-6 rounded-2xl shadow-md text-center">
          <h2 className="text-xl font-bold mb-3">Quiz Results</h2>

          <div className="mb-6">
            <div className="text-4xl font-bold mb-2">{score} points</div>
            <p className="text-gray-600">
              {score >= 800
                ? "Amazing! You're a spending genius!"
                : score >= 500
                  ? "Great job! You know how to spend smart."
                  : score >= 300
                    ? "Good effort! Keep learning about smart spending."
                    : "Keep practicing! You'll get better at spending decisions."}
            </p>
          </div>

          <div className="mb-6">
            <div className="flex justify-between mb-2">
              <span>Longest streak:</span>
              <span className="font-bold">🔥 {streak}</span>
            </div>
            <div className="flex justify-between">
              <span>Correct answers:</span>
              <span className="font-bold">
                {score / 100} / {questions.length}
              </span>
            </div>
          </div>

          <div className="flex gap-3">
            <button onClick={restartQuiz} className="flex-1 py-3 bg-gray-100 rounded-2xl font-medium">
              Play Again
            </button>
            <Link href="/" className="flex-1 py-3 bg-[#84DCCF] rounded-2xl font-medium text-center">
              Finish
            </Link>
          </div>
        </div>
      )}
    </motion.main>
  )
}
