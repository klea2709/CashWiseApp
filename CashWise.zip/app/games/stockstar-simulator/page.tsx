"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowLeft, TrendingUp, TrendingDown, BarChart2, Newspaper } from "lucide-react"
import { useStockSimulator } from "@/lib/hooks/useStockSimulator"

export default function StockStarSimulatorPage() {
  const {
    cash,
    stocks,
    portfolio,
    stockHistory,
    newsItems,
    selectedStock,
    setSelectedStock,
    buyAmount,
    setBuyAmount,
    sellAmount,
    setSellAmount,
    buyStock,
    sellStock,
    nextDay,
    portfolioValue,
    gameState,
    startGame,
    endGame,
  } = useStockSimulator()

  const [showNews, setShowNews] = useState(false)

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="p-4 space-y-6 pb-20"
    >
      <div className="flex items-center gap-2">
        <Link href="/" className="p-2 rounded-full bg-gray-100">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold">StockStar Simulator</h1>
      </div>

      {gameState === "intro" && (
        <div className="bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-xl font-bold mb-3">Welcome to StockStar Simulator!</h2>
          <p className="mb-4">
            Learn how the stock market works in this educational simulation. Buy low, sell high, and build your
            portfolio!
          </p>
          <button onClick={startGame} className="w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
            Start Simulation
          </button>
        </div>
      )}

      {gameState === "playing" && (
        <>
          <div className="bg-white p-4 rounded-2xl shadow-md">
            <div className="flex justify-between items-center mb-2">
              <h2 className="font-bold">Your Portfolio</h2>
              <div className="flex gap-2">
                <button
                  className={`p-2 rounded-full ${showNews ? "bg-gray-100" : "bg-[#84DCCF]"}`}
                  onClick={() => setShowNews(false)}
                >
                  <BarChart2 size={18} />
                </button>
                <button
                  className={`p-2 rounded-full ${showNews ? "bg-[#84DCCF]" : "bg-gray-100"}`}
                  onClick={() => setShowNews(true)}
                >
                  <Newspaper size={18} />
                </button>
              </div>
            </div>

            <div className="flex justify-between items-center mb-4">
              <div>
                <div className="text-sm text-gray-500">Total Value</div>
                <div className="text-2xl font-bold">${(cash + portfolioValue).toFixed(2)}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500">Cash</div>
                <div className="text-xl font-bold">${cash.toFixed(2)}</div>
              </div>
            </div>

            {!showNews && (
              <div className="space-y-2">
                <h3 className="font-medium text-sm">Your Holdings</h3>
                {Object.keys(portfolio).length > 0 ? (
                  Object.entries(portfolio).map(([symbol, shares]) => {
                    const stock = stocks.find((s) => s.symbol === symbol)
                    if (!stock || shares <= 0) return null

                    return (
                      <div key={symbol} className="flex justify-between items-center p-2 bg-gray-50 rounded-xl">
                        <div>
                          <div className="font-medium">{stock.name}</div>
                          <div className="text-xs text-gray-500">{shares} shares</div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium">${(shares * stock.price).toFixed(2)}</div>
                          <div className="text-xs flex items-center gap-1 justify-end">
                            {stock.change >= 0 ? (
                              <>
                                <TrendingUp size={12} className="text-green-500" />
                                <span className="text-green-500">{stock.change}%</span>
                              </>
                            ) : (
                              <>
                                <TrendingDown size={12} className="text-red-500" />
                                <span className="text-red-500">{stock.change}%</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    )
                  })
                ) : (
                  <div className="text-center py-2 text-gray-500">No stocks in portfolio</div>
                )}
              </div>
            )}

            {showNews && (
              <div className="space-y-3">
                <h3 className="font-medium text-sm">Market News</h3>
                {newsItems.map((news, index) => (
                  <div key={index} className="p-3 bg-gray-50 rounded-xl">
                    <div className="font-medium">{news.headline}</div>
                    <div className="text-xs text-gray-500 mt-1">{news.date}</div>
                    <div className="text-sm mt-1">{news.content}</div>
                    {news.affectedStock && (
                      <div className="text-xs mt-2 flex items-center gap-1">
                        <span>Affects:</span>
                        <span className="font-medium">{news.affectedStock}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-white p-4 rounded-2xl shadow-md">
            <h2 className="font-bold mb-3">Stock Market</h2>

            <div className="space-y-3">
              {stocks.map((stock) => (
                <div
                  key={stock.symbol}
                  className={`p-3 rounded-xl border-2 ${
                    selectedStock === stock.symbol ? "border-[#84DCCF] bg-[#84DCCF]/10" : "border-transparent"
                  }`}
                  onClick={() => setSelectedStock(stock.symbol)}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-medium">{stock.name}</div>
                      <div className="text-xs text-gray-500">{stock.symbol}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">${stock.price.toFixed(2)}</div>
                      <div className="text-xs flex items-center gap-1 justify-end">
                        {stock.change >= 0 ? (
                          <>
                            <TrendingUp size={12} className="text-green-500" />
                            <span className="text-green-500">{stock.change}%</span>
                          </>
                        ) : (
                          <>
                            <TrendingDown size={12} className="text-red-500" />
                            <span className="text-red-500">{stock.change}%</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {selectedStock && (
            <div className="bg-white p-4 rounded-2xl shadow-md">
              <h2 className="font-bold mb-3">Trade {selectedStock}</h2>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Buy {selectedStock}</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={buyAmount}
                      onChange={(e) => setBuyAmount(Number(e.target.value))}
                      min="0"
                      step="1"
                      className="flex-1 p-3 border rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#84DCCF]"
                      placeholder="Shares to buy"
                    />
                    <button
                      onClick={buyStock}
                      disabled={
                        !buyAmount ||
                        buyAmount <= 0 ||
                        buyAmount * (stocks.find((s) => s.symbol === selectedStock)?.price || 0) > cash
                      }
                      className={`px-4 py-3 rounded-2xl font-medium ${
                        buyAmount &&
                        buyAmount > 0 &&
                        buyAmount * (stocks.find((s) => s.symbol === selectedStock)?.price || 0) <= cash
                          ? "bg-[#84DCCF]"
                          : "bg-gray-300"
                      }`}
                    >
                      Buy
                    </button>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Cost: ${(buyAmount * (stocks.find((s) => s.symbol === selectedStock)?.price || 0)).toFixed(2)}
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium mb-1 block">Sell {selectedStock}</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={sellAmount}
                      onChange={(e) => setSellAmount(Number(e.target.value))}
                      min="0"
                      max={portfolio[selectedStock] || 0}
                      step="1"
                      className="flex-1 p-3 border rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#84DCCF]"
                      placeholder="Shares to sell"
                    />
                    <button
                      onClick={sellStock}
                      disabled={!sellAmount || sellAmount <= 0 || sellAmount > (portfolio[selectedStock] || 0)}
                      className={`px-4 py-3 rounded-2xl font-medium ${
                        sellAmount && sellAmount > 0 && sellAmount <= (portfolio[selectedStock] || 0)
                          ? "bg-gray-100"
                          : "bg-gray-300"
                      }`}
                    >
                      Sell
                    </button>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Value: ${(sellAmount * (stocks.find((s) => s.symbol === selectedStock)?.price || 0)).toFixed(2)}
                  </div>
                </div>
              </div>
            </div>
          )}

          <button onClick={nextDay} className="w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
            Next Day
          </button>
        </>
      )}

      {gameState === "results" && (
        <div className="bg-white p-6 rounded-2xl shadow-md text-center">
          <h2 className="text-xl font-bold mb-3">Simulation Results</h2>

          <div className="mb-6">
            <div className="text-4xl font-bold mb-2">${(cash + portfolioValue).toFixed(2)}</div>
            <p className="text-gray-600">
              {cash + portfolioValue > 1500
                ? "Amazing! You're a stock market genius!"
                : cash + portfolioValue > 1200
                  ? "Great job! You made some smart investments."
                  : cash + portfolioValue > 1000
                    ? "Good effort! You made a profit."
                    : "Investing takes practice. Keep learning!"}
            </p>
          </div>

          <div className="space-y-3 mb-6">
            <div className="flex justify-between">
              <span>Starting value:</span>
              <span className="font-bold">$1,000.00</span>
            </div>
            <div className="flex justify-between">
              <span>Final value:</span>
              <span className="font-bold">${(cash + portfolioValue).toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Profit/Loss:</span>
              <span className={`font-bold ${cash + portfolioValue >= 1000 ? "text-green-600" : "text-red-600"}`}>
                ${(cash + portfolioValue - 1000).toFixed(2)}
              </span>
            </div>
          </div>

          <div className="p-4 bg-blue-50 rounded-xl mb-6 text-left">
            <h3 className="font-bold">Key Investing Lessons</h3>
            <ul className="list-disc pl-5 mt-2 text-sm space-y-1">
              <li>Diversification helps reduce risk</li>
              <li>Market news can impact stock prices</li>
              <li>Long-term investing often beats short-term trading</li>
              <li>Research companies before investing</li>
              <li>Never invest money you can't afford to lose</li>
            </ul>
          </div>

          <div className="flex gap-3">
            <button onClick={startGame} className="flex-1 py-3 bg-gray-100 rounded-2xl font-medium">
              Play Again
            </button>
            <Link href="/" className="flex-1 py-3 bg-[#84DCCF] rounded-2xl font-medium text-center">
              Finish
            </Link>
          </div>
        </div>
      )}
    </motion.main>
  )
}
