"use client"
import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowLeft, TrendingUp } from "lucide-react"
import { useInterestIsland } from "@/lib/hooks/useInterestIsland"

export default function InterestIslandPage() {
  const {
    day,
    balance,
    interestRate,
    setInterestRate,
    depositAmount,
    setDepositAmount,
    withdrawAmount,
    setWithdrawAmount,
    treeHeight,
    interestEarned,
    totalInterestEarned,
    deposit,
    withdraw,
    nextDay,
    resetGame,
    gameState,
  } = useInterestIsland()

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="p-4 space-y-6 pb-20"
    >
      <div className="flex items-center gap-2">
        <Link href="/" className="p-2 rounded-full bg-gray-100">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold">Interest Island</h1>
      </div>

      {gameState === "intro" && (
        <div className="bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-xl font-bold mb-3">Welcome to Interest Island!</h2>
          <p className="mb-4">Watch your money grow like trees with the power of compound interest!</p>
          <button onClick={() => resetGame("playing")} className="w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
            Start Game
          </button>
        </div>
      )}

      {gameState === "playing" && (
        <>
          <div className="bg-white p-4 rounded-2xl shadow-md">
            <div className="flex justify-between items-center mb-2">
              <h2 className="font-bold">Your Savings</h2>
              <span className="text-sm bg-[#84DCCF] px-2 py-1 rounded-full">Day {day}</span>
            </div>

            <div className="flex justify-between items-center mb-4">
              <div className="text-2xl font-bold">${balance.toFixed(2)}</div>
              <div className="flex items-center gap-1 text-green-600">
                <TrendingUp size={16} />
                <span className="text-sm">+${interestEarned.toFixed(2)} today</span>
              </div>
            </div>

            <div className="flex justify-between text-sm">
              <span>Interest Rate: {interestRate}%</span>
              <span>Total Interest: ${totalInterestEarned.toFixed(2)}</span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl shadow-md">
            <h2 className="font-bold mb-3">Your Interest Tree</h2>

            <div className="flex justify-center py-4">
              <div className="relative flex flex-col items-center">
                <div
                  className="w-8 bg-brown-500 rounded-md"
                  style={{
                    height: `${Math.max(20, treeHeight)}px`,
                    backgroundColor: "#8B4513",
                  }}
                ></div>
                <div
                  className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-40 h-40 rounded-full bg-green-500 opacity-80"
                  style={{
                    width: `${Math.max(40, treeHeight * 2)}px`,
                    height: `${Math.max(40, treeHeight * 2)}px`,
                    bottom: `${Math.max(20, treeHeight) - 10}px`,
                    backgroundColor: "#84DCCF",
                  }}
                ></div>
              </div>
            </div>

            <div className="text-center text-sm mt-2">
              <p>Your tree grows as your money grows!</p>
              <p className="text-gray-500">Tree height: {treeHeight.toFixed(0)}px</p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl shadow-md">
            <h2 className="font-bold mb-3">Account Actions</h2>

            <div className="space-y-4">
              <div>
                <label className="flex items-center gap-2 text-sm font-medium mb-1">Choose Interest Rate</label>
                <div className="flex gap-2">
                  <button
                    onClick={() => setInterestRate(1)}
                    className={`flex-1 py-2 rounded-xl text-center ${interestRate === 1 ? "bg-[#84DCCF]" : "bg-gray-100"}`}
                  >
                    1%
                  </button>
                  <button
                    onClick={() => setInterestRate(3)}
                    className={`flex-1 py-2 rounded-xl text-center ${interestRate === 3 ? "bg-[#84DCCF]" : "bg-gray-100"}`}
                  >
                    3%
                  </button>
                  <button
                    onClick={() => setInterestRate(5)}
                    className={`flex-1 py-2 rounded-xl text-center ${interestRate === 5 ? "bg-[#84DCCF]" : "bg-gray-100"}`}
                  >
                    5%
                  </button>
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  Higher rates mean faster growth, but may have requirements in real life.
                </div>
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium mb-1">Deposit Amount</label>
                <div className="flex items-center">
                  <span className="bg-gray-100 p-3 rounded-l-2xl">$</span>
                  <input
                    type="number"
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(Number(e.target.value))}
                    min="0"
                    step="10"
                    className="flex-1 p-3 border-y border-r rounded-r-2xl focus:outline-none focus:ring-2 focus:ring-[#84DCCF]"
                  />
                </div>
                <button
                  onClick={deposit}
                  disabled={depositAmount <= 0}
                  className={`w-full mt-2 py-2 rounded-xl font-medium ${
                    depositAmount > 0 ? "bg-[#84DCCF]" : "bg-gray-300"
                  }`}
                >
                  Deposit
                </button>
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium mb-1">Withdraw Amount</label>
                <div className="flex items-center">
                  <span className="bg-gray-100 p-3 rounded-l-2xl">$</span>
                  <input
                    type="number"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(Number(e.target.value))}
                    min="0"
                    max={balance}
                    step="10"
                    className="flex-1 p-3 border-y border-r rounded-r-2xl focus:outline-none focus:ring-2 focus:ring-[#84DCCF]"
                  />
                </div>
                <button
                  onClick={withdraw}
                  disabled={withdrawAmount <= 0 || withdrawAmount > balance}
                  className={`w-full mt-2 py-2 rounded-xl font-medium ${
                    withdrawAmount > 0 && withdrawAmount <= balance ? "bg-gray-100" : "bg-gray-300"
                  }`}
                >
                  Withdraw
                </button>
              </div>
            </div>
          </div>

          <button onClick={nextDay} className="w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
            Next Day
          </button>
        </>
      )}

      {gameState === "results" && (
        <div className="bg-white p-6 rounded-2xl shadow-md text-center">
          <h2 className="text-xl font-bold mb-3">Savings Results</h2>

          <div className="mb-6">
            <div className="text-4xl font-bold mb-2">${balance.toFixed(2)}</div>
            <p className="text-gray-600">
              {balance > 1000
                ? "Amazing! You're a savings master!"
                : balance > 500
                  ? "Great job! Your money grew nicely."
                  : balance > 100
                    ? "Good start! Keep saving to see more growth."
                    : "Every savings journey starts with small steps!"}
            </p>
          </div>

          <div className="space-y-3 mb-6">
            <div className="flex justify-between">
              <span>Days of saving:</span>
              <span className="font-bold">{day}</span>
            </div>
            <div className="flex justify-between">
              <span>Total interest earned:</span>
              <span className="font-bold text-green-600">${totalInterestEarned.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Final interest rate:</span>
              <span className="font-bold">{interestRate}%</span>
            </div>
          </div>

          <div className="flex gap-3">
            <button onClick={() => resetGame("playing")} className="flex-1 py-3 bg-gray-100 rounded-2xl font-medium">
              Play Again
            </button>
            <Link href="/" className="flex-1 py-3 bg-[#84DCCF] rounded-2xl font-medium text-center">
              Finish
            </Link>
          </div>
        </div>
      )}
    </motion.main>
  )
}
