"use client"
import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowLeft, TrendingUp, DollarSign } from "lucide-react"
import { useFinanceTycoon } from "@/lib/hooks/useFinanceTycoon"

export default function FinanceTycoonPage() {
  const {
    businessName,
    setBusinessName,
    day,
    cash,
    income,
    expenses,
    inventory,
    price,
    setPrice,
    marketing,
    setMarketing,
    dailySales,
    dailyExpenses,
    dailyProfit,
    salesHistory,
    startBusiness,
    nextDay,
    buyInventory,
    gameState,
  } = useFinanceTycoon()

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="p-4 space-y-6 pb-20"
    >
      <div className="flex items-center gap-2">
        <Link href="/" className="p-2 rounded-full bg-gray-100">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold">Finance Tycoon Jr.</h1>
      </div>

      {gameState === "setup" && (
        <div className="bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-xl font-bold mb-3">Start Your Business!</h2>
          <p className="mb-4">Create your own lemonade stand and learn about income, expenses, and profit!</p>

          <div className="mb-4">
            <label className="block text-sm font-medium mb-1">Business Name</label>
            <input
              type="text"
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              placeholder="My Awesome Lemonade"
              className="w-full p-3 border rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#84DCCF]"
            />
          </div>

          <button
            onClick={startBusiness}
            disabled={!businessName.trim()}
            className={`w-full py-3 rounded-2xl font-medium ${businessName.trim() ? "bg-[#84DCCF]" : "bg-gray-300"}`}
          >
            Start Business
          </button>
        </div>
      )}

      {gameState === "playing" && (
        <>
          <div className="bg-white p-4 rounded-2xl shadow-md">
            <div className="flex justify-between items-center mb-2">
              <h2 className="font-bold">{businessName}</h2>
              <span className="text-sm bg-[#84DCCF] px-2 py-1 rounded-full">Day {day}</span>
            </div>

            <div className="grid grid-cols-3 gap-2 mb-2">
              <div className="bg-gray-50 p-2 rounded-xl text-center">
                <div className="text-xs text-gray-500">Cash</div>
                <div className="font-bold">${cash.toFixed(2)}</div>
              </div>
              <div className="bg-gray-50 p-2 rounded-xl text-center">
                <div className="text-xs text-gray-500">Income</div>
                <div className="font-bold text-green-600">${income.toFixed(2)}</div>
              </div>
              <div className="bg-gray-50 p-2 rounded-xl text-center">
                <div className="text-xs text-gray-500">Expenses</div>
                <div className="font-bold text-red-600">${expenses.toFixed(2)}</div>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <div className="flex items-center gap-1">
                <TrendingUp size={16} className="text-green-600" />
                <span className="text-sm">Profit: ${(income - expenses).toFixed(2)}</span>
              </div>
              <div className="flex items-center gap-1">
                <DollarSign size={16} />
                <span className="text-sm">Inventory: {inventory} cups</span>
              </div>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl shadow-md">
            <h2 className="font-bold mb-3">Business Decisions</h2>

            <div className="space-y-4">
              <div>
                <label className="flex items-center gap-2 text-sm font-medium mb-1">Price per Cup</label>
                <div className="flex items-center">
                  <span className="bg-gray-100 p-3 rounded-l-2xl">$</span>
                  <input
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(Number(e.target.value))}
                    min="0.5"
                    max="10"
                    step="0.25"
                    className="flex-1 p-3 border-y border-r rounded-r-2xl focus:outline-none focus:ring-2 focus:ring-[#84DCCF]"
                  />
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  Higher prices may reduce sales but increase profit per cup.
                </div>
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium mb-1">Marketing Budget</label>
                <div className="flex items-center">
                  <span className="bg-gray-100 p-3 rounded-l-2xl">$</span>
                  <input
                    type="number"
                    value={marketing}
                    onChange={(e) => setMarketing(Number(e.target.value))}
                    min="0"
                    max="50"
                    step="5"
                    className="flex-1 p-3 border-y border-r rounded-r-2xl focus:outline-none focus:ring-2 focus:ring-[#84DCCF]"
                  />
                </div>
                <div className="text-xs text-gray-500 mt-1">Spending on marketing can increase your sales.</div>
              </div>

              <button
                onClick={buyInventory}
                disabled={cash < 10}
                className={`w-full py-3 rounded-2xl font-medium ${cash >= 10 ? "bg-[#84DCCF]" : "bg-gray-300"}`}
              >
                Buy Inventory ($10 for 20 cups)
              </button>
            </div>
          </div>

          {day > 1 && (
            <div className="bg-white p-4 rounded-2xl shadow-md">
              <h2 className="font-bold mb-3">Yesterday's Results</h2>

              <div className="space-y-2">
                <div className="flex justify-between items-center p-2 bg-gray-50 rounded-xl">
                  <span className="text-gray-600">Sales:</span>
                  <span className="font-bold">{dailySales} cups</span>
                </div>

                <div className="flex justify-between items-center p-2 bg-gray-50 rounded-xl">
                  <span className="text-gray-600">Revenue:</span>
                  <span className="font-bold text-green-600">${(dailySales * price).toFixed(2)}</span>
                </div>

                <div className="flex justify-between items-center p-2 bg-gray-50 rounded-xl">
                  <span className="text-gray-600">Expenses:</span>
                  <span className="font-bold text-red-600">${dailyExpenses.toFixed(2)}</span>
                </div>

                <div className="flex justify-between items-center p-2 bg-gray-50 rounded-xl">
                  <span className="text-gray-600">Profit:</span>
                  <span className={`font-bold ${dailyProfit >= 0 ? "text-green-600" : "text-red-600"}`}>
                    ${dailyProfit.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          )}

          <button
            onClick={nextDay}
            disabled={inventory <= 0}
            className={`w-full py-3 rounded-2xl font-medium ${inventory > 0 ? "bg-[#84DCCF]" : "bg-gray-300"}`}
          >
            {inventory > 0 ? "Next Day" : "Buy Inventory First"}
          </button>
        </>
      )}

      {gameState === "gameover" && (
        <div className="bg-white p-6 rounded-2xl shadow-md text-center">
          <h2 className="text-xl font-bold mb-3">Business Summary</h2>

          <div className="mb-6">
            <div className="text-4xl font-bold mb-2">${cash.toFixed(2)}</div>
            <p className="text-gray-600">
              {cash > 100
                ? "Amazing! You're a business genius!"
                : cash > 50
                  ? "Great job! Your business is profitable."
                  : cash > 0
                    ? "You managed to stay in business!"
                    : "Your business went bankrupt. Try again!"}
            </p>
          </div>

          <div className="space-y-3 mb-6">
            <div className="flex justify-between">
              <span>Days in business:</span>
              <span className="font-bold">{day}</span>
            </div>
            <div className="flex justify-between">
              <span>Total income:</span>
              <span className="font-bold text-green-600">${income.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Total expenses:</span>
              <span className="font-bold text-red-600">${expenses.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Total profit:</span>
              <span className={`font-bold ${income - expenses >= 0 ? "text-green-600" : "text-red-600"}`}>
                ${(income - expenses).toFixed(2)}
              </span>
            </div>
          </div>

          <div className="flex gap-3">
            <button
              onClick={() => window.location.reload()}
              className="flex-1 py-3 bg-gray-100 rounded-2xl font-medium"
            >
              New Game
            </button>
            <Link href="/" className="flex-1 py-3 bg-[#84DCCF] rounded-2xl font-medium text-center">
              Finish
            </Link>
          </div>
        </div>
      )}
    </motion.main>
  )
}
