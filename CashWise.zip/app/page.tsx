"use client"

import { motion } from "framer-motion"
import GreetingRow from "@/components/home/GreetingRow"
import BalanceAndSavingsCard from "@/components/home/BalanceAndSavingsCard"
import FeaturedMission from "@/components/home/FeaturedMission"
import MiniGameCarousel from "@/components/home/MiniGameCarousel"
import TipOfTheDay from "@/components/home/TipOfTheDay"
import QuickLearnSection from "@/components/home/QuickLearnSection"

export default function Home() {
  return (
    <motion.main initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-4 space-y-6">
      <GreetingRow />
      <BalanceAndSavingsCard />
      <FeaturedMission />
      <QuickLearnSection />
      <MiniGameCarousel />
      <TipOfTheDay />
    </motion.main>
  )
}
