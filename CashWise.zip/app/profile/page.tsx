"use client"

import { motion } from "framer-motion"
import { useState, useEffect } from "react"
import Image from "next/image"
import { Settings, Award, LogOut } from "lucide-react"
import { getUserProfile } from "@/lib/api"
import type { UserProfile } from "@/lib/types"

export default function ProfilePage() {
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const data = await getUserProfile()
        setProfile(data)
      } catch (error) {
        console.error("Failed to fetch profile:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchProfile()
  }, [])

  if (loading) {
    return <div className="p-4">Loading profile...</div>
  }

  if (!profile) {
    return <div className="p-4">Failed to load profile</div>
  }

  return (
    <motion.main initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-4 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Profile</h1>
        <button className="p-2 rounded-full bg-gray-100">
          <Settings size={20} />
        </button>
      </div>

      <div className="flex flex-col items-center gap-3 py-4">
        <div className="relative">
          <Image
            src={profile.avatar || "/placeholder.svg?height=100&width=100"}
            alt="Avatar"
            width={100}
            height={100}
            className="rounded-full border-4 border-[#84DCCF]"
          />
        </div>
        <h2 className="text-xl font-bold">{profile.name}</h2>
        <div className="bg-[#84DCCF] px-3 py-1 rounded-full text-sm">
          Level {profile.level}: {profile.levelTitle}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white p-3 rounded-2xl shadow text-center">
          <div className="text-2xl font-bold text-[#EF626C]">{profile.stats.finPoints}</div>
          <div className="text-xs">TeenPoints</div>
        </div>
        <div className="bg-white p-3 rounded-2xl shadow text-center">
          <div className="text-2xl font-bold text-[#CBA135]">{profile.stats.missions}</div>
          <div className="text-xs">Missions</div>
        </div>
        <div className="bg-white p-3 rounded-2xl shadow text-center">
          <div className="text-2xl font-bold text-[#84DCCF]">{profile.stats.streak}</div>
          <div className="text-xs">Day Streak</div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-2xl shadow">
        <h3 className="font-bold mb-3">My Badges</h3>
        <div className="grid grid-cols-4 gap-3">
          {profile.badges.map((badge) => (
            <div key={badge.id} className="flex flex-col items-center">
              <div className={`p-2 rounded-full ${badge.unlocked ? "bg-[#CBA135]" : "bg-gray-200"}`}>
                <Award size={24} className={badge.unlocked ? "text-white" : "text-gray-400"} />
              </div>
              <span className="text-xs mt-1 text-center">{badge.name}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white p-4 rounded-2xl shadow">
        <h3 className="font-bold mb-3">My Goals</h3>
        {profile.goals.map((goal) => (
          <div key={goal.id} className="mb-3">
            <div className="flex justify-between mb-1">
              <span className="text-sm">{goal.title}</span>
              <span className="text-sm font-bold">{goal.progress}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-[#84DCCF] h-2 rounded-full" style={{ width: `${goal.progress}%` }}></div>
            </div>
          </div>
        ))}
        <button className="w-full mt-2 py-2 bg-gray-100 rounded-2xl text-sm font-medium">Set New Goal</button>
      </div>

      <button className="flex items-center gap-2 text-[#EF626C] font-medium">
        <LogOut size={18} />
        <span>Log Out</span>
      </button>
    </motion.main>
  )
}
