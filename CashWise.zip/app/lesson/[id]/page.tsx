"use client"

import { motion } from "framer-motion"
import { useState, useEffect } from "react"
import { useParams, notFound } from "next/navigation"
import { getLessonById } from "@/lib/api"
import QuizQuestion from "@/components/learn/QuizQuestion"
import FinPointsEarned from "@/components/learn/FinPointsEarned"
import type { Lesson } from "@/lib/types"

export default function LessonPage() {
  const params = useParams()
  const id = params.id as string
  const [lesson, setLesson] = useState<Lesson | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchLesson = async () => {
      try {
        const data = await getLessonById(id)
        if (!data) {
          notFound()
        }
        setLesson(data)
      } catch (error) {
        console.error("Failed to fetch lesson:", error)
        notFound()
      } finally {
        setLoading(false)
      }
    }

    fetchLesson()
  }, [id])

  if (loading) {
    return <div className="p-4">Loading lesson...</div>
  }

  if (!lesson) {
    return notFound()
  }

  return (
    <motion.main initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">{lesson.title}</h1>

      <div className="aspect-video bg-gray-200 rounded-2xl overflow-hidden">
        <div className="w-full h-full flex items-center justify-center">
          <span className="text-gray-500">Video Placeholder</span>
        </div>
      </div>

      <div className="prose max-w-none">
        <p>{lesson.content}</p>
      </div>

      <div className="space-y-6 mt-8">
        <h2 className="text-xl font-bold">Quiz Time!</h2>
        {lesson.quiz.map((question, index) => (
          <QuizQuestion key={index} question={question} questionIndex={index} />
        ))}
      </div>

      <FinPointsEarned points={lesson.points} />
    </motion.main>
  )
}
