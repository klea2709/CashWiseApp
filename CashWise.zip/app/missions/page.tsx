"use client"

import { motion } from "framer-motion"
import { useState, useEffect } from "react"
import MissionCard from "@/components/missions/MissionCard"
import { getMissions } from "@/lib/api"
import type { Mission } from "@/lib/types"
import { Brain } from "lucide-react"

export default function MissionsPage() {
  const [missions, setMissions] = useState<Mission[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState("all")

  useEffect(() => {
    const fetchMissions = async () => {
      try {
        // Get missions from API
        let data = await getMissions()

        // Filter out removed missions and check if memory game already exists
        const memoryGameExists = data.some((mission) => mission.id === "6" || mission.title === "Financial Memory Game")

        // Only add the memory game if it doesn't already exist
        if (!memoryGameExists) {
          const memoryGameMission = {
            id: "6",
            title: "Financial Memory Game",
            description: "Match financial terms with their definitions",
            icon: Brain,
            color: "#9381FF",
            progress: 0,
            reward: 150, // Keep the higher reward value
            category: "learning",
            tasks: [
              { id: "1", title: "Complete the game with 3 stars", completed: false },
              { id: "2", title: "Match all terms in under 20 moves", completed: false },
              { id: "3", title: "Complete the game in under 2 minutes", completed: false },
            ],
          }
          data = [...data, memoryGameMission]
        }

        // Filter out removed missions
        data = data.filter((mission) => mission.id !== "4" && mission.id !== "5")

        setMissions(data)
      } catch (error) {
        console.error("Failed to fetch missions:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchMissions()
  }, [])

  const filteredMissions = filter === "all" ? missions : missions.filter((mission) => mission.category === filter)

  if (loading) {
    return <div className="p-4">Loading missions...</div>
  }

  return (
    <motion.main initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">Missions</h1>

      <div className="flex overflow-x-auto py-2 gap-2 no-scrollbar">
        <button
          onClick={() => setFilter("all")}
          className={`px-4 py-2 rounded-2xl text-sm whitespace-nowrap ${
            filter === "all" ? "bg-[#84DCCF]" : "bg-white"
          }`}
        >
          All Missions
        </button>
        <button
          onClick={() => setFilter("saving")}
          className={`px-4 py-2 rounded-2xl text-sm whitespace-nowrap ${
            filter === "saving" ? "bg-[#84DCCF]" : "bg-white"
          }`}
        >
          Saving
        </button>
        <button
          onClick={() => setFilter("budgeting")}
          className={`px-4 py-2 rounded-2xl text-sm whitespace-nowrap ${
            filter === "budgeting" ? "bg-[#84DCCF]" : "bg-white"
          }`}
        >
          Budgeting
        </button>
        <button
          onClick={() => setFilter("learning")}
          className={`px-4 py-2 rounded-2xl text-sm whitespace-nowrap ${
            filter === "learning" ? "bg-[#84DCCF]" : "bg-white"
          }`}
        >
          Learning
        </button>
      </div>

      <div className="space-y-4">
        {filteredMissions.map((mission) => (
          <MissionCard key={mission.id} mission={mission} />
        ))}
      </div>
    </motion.main>
  )
}
