"use client"

import type React from "react"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Bike, Plus, Coins, CheckCircle } from "lucide-react"
import confetti from "canvas-confetti"

export default function SaveForBikePage() {
  const [savings, setSavings] = useState(0)
  const [goal] = useState(200)
  const [weeklyAllowance, setWeeklyAllowance] = useState(10)
  const [showCoinAnimation, setShowCoinAnimation] = useState(false)
  const [animationPosition, setAnimationPosition] = useState({ x: 0, y: 0 })
  const [completedChores, setCompletedChores] = useState<string[]>([])
  const [showCompletionModal, setShowCompletionModal] = useState(false)

  const chores = [
    { id: "dishes", name: "Do the dishes", reward: 5 },
    { id: "trash", name: "Take out trash", reward: 3 },
    { id: "vacuum", name: "Vacuum living room", reward: 4 },
    { id: "bed", name: "Make your bed", reward: 2 },
    { id: "lawn", name: "Mow the lawn", reward: 8 },
    { id: "dog", name: "Walk the dog", reward: 5 },
    { id: "homework", name: "Finish homework", reward: 6 },
    { id: "clean", name: "Clean your room", reward: 4 },
  ]

  const addWeeklyAllowance = () => {
    setSavings((prev) => {
      const newSavings = prev + weeklyAllowance
      if (newSavings >= goal && !showCompletionModal) {
        setTimeout(() => {
          setShowCompletionModal(true)
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 },
          })
        }, 1000)
      }
      return newSavings
    })
    triggerCoinAnimation({ x: window.innerWidth / 2, y: window.innerHeight / 2 })
  }

  const completeChore = (id: string, reward: number, event: React.MouseEvent) => {
    if (completedChores.includes(id)) return

    setCompletedChores((prev) => [...prev, id])
    setSavings((prev) => {
      const newSavings = prev + reward
      if (newSavings >= goal && !showCompletionModal) {
        setTimeout(() => {
          setShowCompletionModal(true)
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 },
          })
        }, 1000)
      }
      return newSavings
    })

    // Get position for animation
    const rect = (event.target as HTMLElement).getBoundingClientRect()
    triggerCoinAnimation({ x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 })
  }

  const triggerCoinAnimation = (position: { x: number; y: number }) => {
    setAnimationPosition(position)
    setShowCoinAnimation(true)
    setTimeout(() => setShowCoinAnimation(false), 1000)
  }

  const progressPercentage = Math.min(100, (savings / goal) * 100)
  const bikeCompletionStage = Math.floor((progressPercentage / 100) * 4) // 0-4 stages

  return (
    <div className="p-4 pb-20 min-h-screen bg-[#EEE5E9]">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/missions" className="p-2 rounded-full bg-white shadow">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold">Save for Your Dream Bike</h1>
      </div>

      <div className="bg-white p-4 rounded-2xl shadow-md mb-6">
        <div className="flex justify-between items-center mb-2">
          <h2 className="font-bold text-lg flex items-center gap-2">
            <Bike className="text-[#84DCCF]" />
            Savings Goal
          </h2>
          <div className="text-xl font-bold text-[#EF626C]">${goal}</div>
        </div>

        <div className="mb-2">
          <div className="flex justify-between text-sm mb-1">
            <span>Progress: ${savings}</span>
            <span>{progressPercentage.toFixed(0)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-4">
            <div
              className="bg-[#84DCCF] h-4 rounded-full transition-all duration-500"
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
        </div>

        <div className="flex justify-center my-6">
          <div className="relative w-48 h-48">
            {/* Bike illustration that gradually completes */}
            <div className="absolute inset-0 flex items-center justify-center">
              {bikeCompletionStage === 0 && (
                <div className="text-center text-gray-400">
                  <Bike size={80} />
                  <p className="mt-2">Start saving to build your bike!</p>
                </div>
              )}
              {bikeCompletionStage >= 1 && (
                <Image
                  src={`/placeholder.svg?height=150&width=150&text=Bike+${bikeCompletionStage}/4`}
                  alt={`Bike completion stage ${bikeCompletionStage}`}
                  width={150}
                  height={150}
                  className="rounded-xl"
                />
              )}
            </div>
          </div>
        </div>

        <div className="mb-4">
          <label className="block text-sm font-medium mb-1">Weekly Allowance</label>
          <div className="flex gap-2">
            <input
              type="number"
              value={weeklyAllowance}
              onChange={(e) => setWeeklyAllowance(Number(e.target.value))}
              className="flex-1 p-3 border rounded-xl"
              min="1"
              max="50"
            />
            <button
              onClick={addWeeklyAllowance}
              className="bg-[#84DCCF] text-white px-4 py-2 rounded-xl font-medium flex items-center gap-1"
            >
              <Plus size={18} /> Add
            </button>
          </div>
        </div>
      </div>

      <h2 className="font-bold text-lg mb-3">Complete Chores to Earn More</h2>
      <div className="grid grid-cols-2 gap-3 mb-6">
        {chores.map((chore) => (
          <button
            key={chore.id}
            onClick={(e) => completeChore(chore.id, chore.reward, e)}
            disabled={completedChores.includes(chore.id)}
            className={`p-3 rounded-xl text-left relative ${
              completedChores.includes(chore.id) ? "bg-gray-100" : "bg-white shadow-md"
            }`}
          >
            <div className="font-medium">{chore.name}</div>
            <div className="text-[#EF626C] font-bold flex items-center gap-1 mt-1">
              <Plus size={14} /> ${chore.reward}
            </div>
            {completedChores.includes(chore.id) && (
              <div className="absolute top-2 right-2">
                <CheckCircle className="text-green-500" size={18} />
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Coin animation */}
      <AnimatePresence>
        {showCoinAnimation && (
          <motion.div
            initial={{
              opacity: 1,
              scale: 1,
              x: animationPosition.x,
              y: animationPosition.y,
            }}
            animate={{
              opacity: 0,
              scale: 0.5,
              y: 100,
              x: window.innerWidth / 2,
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1 }}
            className="fixed z-50 pointer-events-none"
          >
            <Coins size={30} className="text-[#CBA135]" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Completion modal */}
      <AnimatePresence>
        {showCompletionModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="bg-white rounded-2xl p-6 w-full max-w-sm text-center"
            >
              <div className="mb-4">
                <div className="w-20 h-20 bg-[#84DCCF] rounded-full flex items-center justify-center mx-auto">
                  <Bike size={40} className="text-white" />
                </div>
              </div>

              <h2 className="text-2xl font-bold mb-2">Congratulations!</h2>
              <p className="mb-4">You've saved enough for your dream bike!</p>

              <div className="text-4xl font-bold text-[#EF626C] mb-6">${savings}</div>

              <div className="space-y-3">
                <Link href="/missions" className="block w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
                  Back to Missions
                </Link>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
