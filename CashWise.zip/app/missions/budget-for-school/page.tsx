"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, DollarSign, ShoppingBag, CheckCircle, AlertTriangle } from "lucide-react"
import confetti from "canvas-confetti"

export default function BudgetForSchoolPage() {
  const [budget, setBudget] = useState(50)
  const [cart, setCart] = useState<string[]>([])
  const [showCompletionModal, setShowCompletionModal] = useState(false)
  const [showOverBudgetAlert, setShowOverBudgetAlert] = useState(false)

  const supplies = [
    { id: "backpack", name: "Backpack", price: 25, essential: true },
    { id: "notebook", name: "Notebook", price: 5, essential: true },
    { id: "pencils", name: "Pencil Set", price: 3, essential: true },
    { id: "calculator", name: "Calculator", price: 15, essential: true },
    { id: "lunchbox", name: "Lunch Box", price: 12, essential: false },
    { id: "waterBottle", name: "Water Bottle", price: 8, essential: false },
    { id: "markers", name: "Markers", price: 6, essential: false },
    { id: "binder", name: "Binder", price: 7, essential: true },
    { id: "scissors", name: "Scissors", price: 4, essential: true },
    { id: "ruler", name: "Ruler Set", price: 3, essential: true },
    { id: "glue", name: "Glue Sticks", price: 2, essential: true },
    { id: "highlighters", name: "Highlighters", price: 5, essential: false },
  ]

  const remainingBudget =
    budget -
    cart.reduce((total, itemId) => {
      const item = supplies.find((s) => s.id === itemId)
      return total + (item?.price || 0)
    }, 0)

  const essentialItems = supplies.filter((item) => item.essential).map((item) => item.id)
  const allEssentialsInCart = essentialItems.every((itemId) => cart.includes(itemId))

  const toggleItem = (itemId: string) => {
    if (cart.includes(itemId)) {
      // Remove from cart
      setCart(cart.filter((id) => id !== itemId))
      return
    }

    // Check if adding would exceed budget
    const itemPrice = supplies.find((s) => s.id === itemId)?.price || 0
    if (remainingBudget - itemPrice < 0) {
      setShowOverBudgetAlert(true)
      setTimeout(() => setShowOverBudgetAlert(false), 2000)
      return
    }

    // Add to cart
    setCart([...cart, itemId])

    // Check if all essentials are now in cart
    const updatedCart = [...cart, itemId]
    const allEssentialsNowInCart = essentialItems.every((id) => updatedCart.includes(id))

    if (allEssentialsNowInCart && remainingBudget - itemPrice >= 0) {
      setTimeout(() => {
        setShowCompletionModal(true)
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        })
      }, 500)
    }
  }

  return (
    <div className="p-4 pb-20 min-h-screen bg-[#EEE5E9]">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/missions" className="p-2 rounded-full bg-white shadow">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold">Budget for School Supplies</h1>
      </div>

      <div className="bg-white p-4 rounded-2xl shadow-md mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-bold text-lg flex items-center gap-2">
            <DollarSign className="text-[#84DCCF]" />
            Remaining Budget
          </h2>
          <div className={`text-xl font-bold ${remainingBudget >= 0 ? "text-[#84DCCF]" : "text-[#EF626C]"}`}>
            ${remainingBudget.toFixed(2)}
          </div>
        </div>

        <div className="w-full bg-gray-200 rounded-full h-4 mb-2">
          <div
            className={`h-4 rounded-full transition-all duration-500 ${remainingBudget >= 0 ? "bg-[#84DCCF]" : "bg-[#EF626C]"}`}
            style={{ width: `${Math.max(0, (remainingBudget / budget) * 100)}%` }}
          ></div>
        </div>

        <div className="flex justify-between text-sm">
          <span>Starting Budget: ${budget.toFixed(2)}</span>
          <span>Items: {cart.length}</span>
        </div>
      </div>

      <div className="bg-white p-4 rounded-2xl shadow-md mb-6">
        <h2 className="font-bold text-lg mb-3 flex items-center gap-2">
          <ShoppingBag className="text-[#EF626C]" />
          School Supplies
        </h2>
        <p className="text-sm text-gray-600 mb-4">
          Tap items to add them to your cart. Make sure to get all essential items (marked with *) within your budget!
        </p>

        <div className="grid grid-cols-2 gap-3">
          {supplies.map((item) => (
            <button
              key={item.id}
              onClick={() => toggleItem(item.id)}
              className={`p-3 rounded-xl text-left relative ${
                cart.includes(item.id) ? "bg-[#84DCCF]/20 border-2 border-[#84DCCF]" : "bg-white border border-gray-200"
              }`}
            >
              <div className="h-20 bg-gray-100 rounded-lg mb-2 flex items-center justify-center">
                <Image
                  src={`/placeholder.svg?height=60&width=60&text=${item.name}`}
                  alt={item.name}
                  width={60}
                  height={60}
                />
              </div>
              <div className="font-medium">
                {item.name} {item.essential && <span className="text-[#EF626C]">*</span>}
              </div>
              <div className="text-[#84DCCF] font-bold">${item.price.toFixed(2)}</div>

              {cart.includes(item.id) && (
                <div className="absolute top-2 right-2 bg-white rounded-full p-1">
                  <CheckCircle className="text-[#84DCCF]" size={18} />
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Over budget alert */}
      <AnimatePresence>
        {showOverBudgetAlert && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-20 left-0 right-0 mx-auto w-4/5 bg-[#EF626C] text-white p-3 rounded-xl shadow-lg flex items-center gap-2 max-w-sm"
          >
            <AlertTriangle size={20} />
            <span>That would exceed your budget!</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Completion modal */}
      <AnimatePresence>
        {showCompletionModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="bg-white rounded-2xl p-6 w-full max-w-sm text-center"
            >
              <div className="mb-4">
                <div className="w-20 h-20 bg-[#84DCCF] rounded-full flex items-center justify-center mx-auto">
                  <ShoppingBag size={40} className="text-white" />
                </div>
              </div>

              <h2 className="text-2xl font-bold mb-2">Great Job!</h2>
              <p className="mb-4">You've purchased all essential school supplies within your budget!</p>

              <div className="mb-4">
                <div className="text-lg font-bold">
                  Remaining Budget: <span className="text-[#84DCCF]">${remainingBudget.toFixed(2)}</span>
                </div>
                <div className="text-sm text-gray-600">Items purchased: {cart.length}</div>
              </div>

              <div className="space-y-3">
                <Link href="/missions" className="block w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
                  Back to Missions
                </Link>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
