"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Code, Palette, Music, TrendingUp, Clock, Users, Star } from "lucide-react"

export default function GameDeveloperPage() {
  const [budget, setBudget] = useState(1000)
  const [allocations, setAllocations] = useState({
    art: 250,
    music: 150,
    code: 400,
    marketing: 200,
  })
  const [developmentProgress, setDevelopmentProgress] = useState(0)
  const [daysLeft, setDaysLeft] = useState(30)
  const [gameReleased, setGameReleased] = useState(false)
  const [fanReactions, setFanReactions] = useState<{ icon: string; text: string }[]>([])
  const [gameSuccess, setGameSuccess] = useState(0) // 0-100 scale
  const [showCompletionModal, setShowCompletionModal] = useState(false)

  const totalAllocated = Object.values(allocations).reduce((sum, value) => sum + value, 0)
  const remainingBudget = budget - totalAllocated

  const updateAllocation = (category: keyof typeof allocations, value: number) => {
    // Calculate the difference from current allocation
    const difference = value - allocations[category]

    // Check if we have enough remaining budget
    if (remainingBudget - difference < 0) {
      return // Not enough budget
    }

    setAllocations({
      ...allocations,
      [category]: value,
    })
  }

  const advanceDay = () => {
    if (daysLeft <= 0 || gameReleased) return

    // Advance time
    setDaysLeft(daysLeft - 1)

    // Update progress based on allocations
    const progressIncrement = ((allocations.art * 0.2 + allocations.music * 0.15 + allocations.code * 0.4) / budget) * 3
    const newProgress = Math.min(100, developmentProgress + progressIncrement)
    setDevelopmentProgress(newProgress)

    // Check if development is complete or time is up
    if (daysLeft === 1 || newProgress >= 100) {
      releaseGame()
    }
  }

  const releaseGame = () => {
    setGameReleased(true)

    // Calculate game success based on allocations and progress
    const artFactor = (allocations.art / budget) * 25
    const musicFactor = (allocations.music / budget) * 15
    const codeFactor = (allocations.code / budget) * 35
    const marketingFactor = (allocations.marketing / budget) * 25
    const progressFactor = developmentProgress

    const calculatedSuccess = Math.min(
      100,
      (artFactor + musicFactor + codeFactor + marketingFactor + progressFactor) / 2,
    )
    setGameSuccess(Math.round(calculatedSuccess))

    // Generate fan reactions based on success
    generateFanReactions(calculatedSuccess)

    // Show completion modal after a delay
    setTimeout(() => {
      setShowCompletionModal(true)
    }, 2000)
  }

  const generateFanReactions = (success: number) => {
    const reactions = []

    if (success >= 80) {
      reactions.push(
        { icon: "🤩", text: "This game is amazing! Best $10 I've spent!" },
        { icon: "⭐", text: "Five stars! The graphics and gameplay are perfect!" },
        { icon: "👍", text: "Great job on this game! Can't wait for DLC!" },
      )
    } else if (success >= 60) {
      reactions.push(
        { icon: "😊", text: "Pretty good game! I enjoyed playing it." },
        { icon: "👍", text: "Nice work, though the music could be better." },
        { icon: "🎮", text: "Fun gameplay, but found some bugs." },
      )
    } else if (success >= 40) {
      reactions.push(
        { icon: "😐", text: "It's okay I guess. Nothing special." },
        { icon: "🐛", text: "Too many bugs! Please fix them." },
        { icon: "🤔", text: "The graphics are good but gameplay is boring." },
      )
    } else {
      reactions.push(
        { icon: "😡", text: "Waste of money! Don't buy this game!" },
        { icon: "👎", text: "Terrible performance and full of bugs." },
        { icon: "💤", text: "Boring and unfinished. Clearly rushed." },
      )
    }

    setFanReactions(reactions)
  }

  return (
    <div className="p-4 pb-20 min-h-screen bg-[#EEE5E9]">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/missions" className="p-2 rounded-full bg-white shadow">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold">Game Developer Tycoon</h1>
      </div>

      <div className="bg-white p-4 rounded-2xl shadow-md mb-6">
        <div className="flex justify-between items-center mb-2">
          <h2 className="font-bold text-lg">Studio Budget</h2>
          <div className="text-xl font-bold text-[#EF626C]">${budget}</div>
        </div>

        <div className="flex justify-between text-sm mb-2">
          <span>Allocated: ${totalAllocated}</span>
          <span>Remaining: ${remainingBudget}</span>
        </div>

        <div className="w-full bg-gray-200 rounded-full h-4 mb-4">
          <div
            className="bg-[#84DCCF] h-4 rounded-full transition-all duration-500"
            style={{ width: `${(totalAllocated / budget) * 100}%` }}
          ></div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="bg-[#84DCCF]/10 p-3 rounded-xl flex items-center gap-2">
            <Clock className="text-[#84DCCF]" size={20} />
            <div>
              <div className="text-sm">Days Left</div>
              <div className="font-bold">{daysLeft}</div>
            </div>
          </div>
          <div className="bg-[#EF626C]/10 p-3 rounded-xl flex items-center gap-2">
            <TrendingUp className="text-[#EF626C]" size={20} />
            <div>
              <div className="text-sm">Progress</div>
              <div className="font-bold">{Math.round(developmentProgress)}%</div>
            </div>
          </div>
        </div>

        <div className="w-full bg-gray-200 rounded-full h-4 mb-2">
          <div
            className="bg-[#EF626C] h-4 rounded-full transition-all duration-500"
            style={{ width: `${developmentProgress}%` }}
          ></div>
        </div>

        {!gameReleased && (
          <button
            onClick={advanceDay}
            disabled={daysLeft <= 0}
            className="w-full py-3 bg-[#84DCCF] rounded-xl font-medium mt-2"
          >
            {daysLeft > 0 ? "Work on Game (Next Day)" : "Time's Up!"}
          </button>
        )}
      </div>

      {!gameReleased && (
        <div className="bg-white p-4 rounded-2xl shadow-md mb-6">
          <h2 className="font-bold text-lg mb-4">Budget Allocation</h2>

          <div className="space-y-6">
            <div>
              <div className="flex justify-between mb-1">
                <label className="flex items-center gap-1 text-sm font-medium">
                  <Palette className="text-[#EF626C]" size={16} />
                  Art
                </label>
                <span className="text-sm font-bold">${allocations.art}</span>
              </div>
              <input
                type="range"
                min="50"
                max="500"
                step="10"
                value={allocations.art}
                onChange={(e) => updateAllocation("art", Number.parseInt(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
              <div className="text-xs text-gray-500 mt-1">Graphics, character design, environments</div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <label className="flex items-center gap-1 text-sm font-medium">
                  <Music className="text-[#CBA135]" size={16} />
                  Music
                </label>
                <span className="text-sm font-bold">${allocations.music}</span>
              </div>
              <input
                type="range"
                min="50"
                max="300"
                step="10"
                value={allocations.music}
                onChange={(e) => updateAllocation("music", Number.parseInt(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
              <div className="text-xs text-gray-500 mt-1">Soundtrack, sound effects, voice acting</div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <label className="flex items-center gap-1 text-sm font-medium">
                  <Code className="text-[#84DCCF]" size={16} />
                  Code
                </label>
                <span className="text-sm font-bold">${allocations.code}</span>
              </div>
              <input
                type="range"
                min="100"
                max="600"
                step="10"
                value={allocations.code}
                onChange={(e) => updateAllocation("code", Number.parseInt(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
              <div className="text-xs text-gray-500 mt-1">Programming, game mechanics, bug fixing</div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <label className="flex items-center gap-1 text-sm font-medium">
                  <Users className="text-purple-500" size={16} />
                  Marketing
                </label>
                <span className="text-sm font-bold">${allocations.marketing}</span>
              </div>
              <input
                type="range"
                min="50"
                max="400"
                step="10"
                value={allocations.marketing}
                onChange={(e) => updateAllocation("marketing", Number.parseInt(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
              <div className="text-xs text-gray-500 mt-1">Advertising, social media, influencers</div>
            </div>
          </div>
        </div>
      )}

      {gameReleased && !showCompletionModal && (
        <div className="bg-white p-4 rounded-2xl shadow-md mb-6 animate-pulse">
          <h2 className="font-bold text-lg mb-2 text-center">Game Released!</h2>
          <p className="text-center mb-4">Collecting player feedback...</p>

          <div className="flex justify-center">
            <div className="w-12 h-12 border-4 border-[#84DCCF] border-t-transparent rounded-full animate-spin"></div>
          </div>
        </div>
      )}

      {/* Completion modal */}
      <AnimatePresence>
        {showCompletionModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="bg-white rounded-2xl p-6 w-full max-w-sm"
            >
              <h2 className="text-2xl font-bold mb-2 text-center">Game Launch Results</h2>

              <div className="flex justify-center mb-4">
                <div className="w-24 h-24 bg-gray-100 rounded-xl flex items-center justify-center">
                  <Image
                    src="/placeholder.svg?height=80&width=80&text=Your+Game"
                    alt="Your Game"
                    width={80}
                    height={80}
                  />
                </div>
              </div>

              <div className="mb-4">
                <div className="flex justify-between mb-1">
                  <span className="text-sm">Player Rating:</span>
                  <div className="flex items-center">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className={i < Math.round(gameSuccess / 20) ? "text-[#CBA135] fill-[#CBA135]" : "text-gray-300"}
                      />
                    ))}
                  </div>
                </div>

                <div className="w-full bg-gray-200 rounded-full h-4 mb-1">
                  <div
                    className={`h-4 rounded-full transition-all duration-500 ${
                      gameSuccess >= 80
                        ? "bg-green-500"
                        : gameSuccess >= 60
                          ? "bg-[#84DCCF]"
                          : gameSuccess >= 40
                            ? "bg-[#CBA135]"
                            : "bg-[#EF626C]"
                    }`}
                    style={{ width: `${gameSuccess}%` }}
                  ></div>
                </div>

                <div className="text-center font-bold mb-4">
                  {gameSuccess >= 80
                    ? "Huge Success!"
                    : gameSuccess >= 60
                      ? "Moderate Success"
                      : gameSuccess >= 40
                        ? "Mixed Reviews"
                        : "Commercial Failure"}
                </div>
              </div>

              <div className="bg-gray-50 p-3 rounded-xl mb-4">
                <h3 className="font-bold mb-2">Player Reviews:</h3>
                <div className="space-y-2">
                  {fanReactions.map((reaction, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <div className="text-xl">{reaction.icon}</div>
                      <div className="text-sm">{reaction.text}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="text-sm text-gray-600 mb-4">
                <p>
                  {gameSuccess >= 80
                    ? "Your game was a hit! Great balance of resources led to an excellent product."
                    : gameSuccess >= 60
                      ? "Your game did well! With some adjustments to your budget allocation, it could have been even better."
                      : gameSuccess >= 40
                        ? "Your game had potential, but budget allocation issues held it back."
                        : "Poor resource allocation led to an unfinished product. Better planning next time!"}
                </p>
              </div>

              <Link href="/missions" className="block w-full py-3 bg-[#84DCCF] rounded-2xl font-medium text-center">
                Back to Missions
              </Link>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
