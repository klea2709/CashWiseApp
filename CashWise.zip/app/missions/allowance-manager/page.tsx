"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { ArrowLeft, Wallet, Plus, Minus, PiggyBank, Heart, ShoppingBag } from "lucide-react"
import confetti from "canvas-confetti"

export default function AllowanceManagerPage() {
  const [balance, setBalance] = useState(50)
  const [transactions, setTransactions] = useState<
    {
      id: string
      category: "spend" | "save" | "give"
      amount: number
      description: string
      date: string
    }[]
  >([])
  const [spendTotal, setSpendTotal] = useState(0)
  const [saveTotal, setSaveTotal] = useState(0)
  const [giveTotal, setGiveTotal] = useState(0)
  const [showAnimation, setShowAnimation] = useState<"save" | "give" | null>(null)
  const [savingGoal, setSavingGoal] = useState(100)
  const [showGoalReached, setShowGoalReached] = useState(false)

  // Predefined spending and earning options
  const spendOptions = [
    { id: "snacks", description: "Snacks", amount: 3, category: "spend" as const },
    { id: "movie", description: "Movie ticket", amount: 12, category: "spend" as const },
    { id: "game", description: "Mobile game", amount: 5, category: "spend" as const },
    { id: "toy", description: "Small toy", amount: 10, category: "spend" as const },
    { id: "book", description: "Book", amount: 8, category: "spend" as const },
  ]

  const saveOptions = [
    { id: "save-small", description: "Save a little", amount: 5, category: "save" as const },
    { id: "save-medium", description: "Save some", amount: 10, category: "save" as const },
    { id: "save-large", description: "Save a lot", amount: 20, category: "save" as const },
  ]

  const giveOptions = [
    { id: "give-small", description: "Donate a little", amount: 2, category: "give" as const },
    { id: "give-medium", description: "Donate some", amount: 5, category: "give" as const },
    { id: "give-large", description: "Donate a lot", amount: 10, category: "give" as const },
  ]

  const earnOptions = [
    { id: "allowance", description: "Weekly Allowance", amount: 20, category: "save" as const },
    { id: "chores", description: "Extra Chores", amount: 10, category: "save" as const },
    { id: "gift", description: "Birthday Gift", amount: 50, category: "save" as const },
  ]

  // Add a transaction
  const addTransaction = (
    description: string,
    amount: number,
    category: "spend" | "save" | "give",
    isSpending: boolean,
  ) => {
    // Check if we have enough balance for spending
    if (isSpending && amount > balance) {
      alert("You don't have enough money for this!")
      return
    }

    const newAmount = isSpending ? -amount : amount

    // Update balance
    setBalance((prev) => prev + newAmount)

    // Add transaction
    const newTransaction = {
      id: Date.now().toString(),
      category,
      amount: Math.abs(newAmount),
      description,
      date: new Date().toLocaleDateString(),
    }

    setTransactions((prev) => [newTransaction, ...prev])

    // Update category totals
    if (category === "spend") {
      setSpendTotal((prev) => prev + (isSpending ? amount : 0))
    } else if (category === "save") {
      const newSaveTotal = saveTotal + (isSpending ? 0 : amount)
      setSaveTotal(newSaveTotal)

      // Show animation for saving
      if (!isSpending) {
        setShowAnimation("save")
        setTimeout(() => setShowAnimation(null), 2000)

        // Check if goal reached
        if (newSaveTotal >= savingGoal && !showGoalReached) {
          setTimeout(() => {
            setShowGoalReached(true)
            confetti({
              particleCount: 100,
              spread: 70,
              origin: { y: 0.6 },
            })
          }, 500)
        }
      }
    } else if (category === "give") {
      setGiveTotal((prev) => prev + (isSpending ? 0 : amount))

      // Show animation for giving
      if (!isSpending) {
        setShowAnimation("give")
        setTimeout(() => setShowAnimation(null), 2000)
      }
    }
  }

  return (
    <div className="p-4 pb-20 min-h-screen bg-[#EEE5E9]">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/missions" className="p-2 rounded-full bg-white shadow">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold">Allowance Manager</h1>
      </div>

      <div className="bg-white p-4 rounded-2xl shadow-md mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-bold text-lg flex items-center gap-2">
            <Wallet className="text-[#84DCCF]" />
            Your Balance
          </h2>
          <div className="text-2xl font-bold text-[#EF626C]">${balance.toFixed(2)}</div>
        </div>

        <div className="grid grid-cols-3 gap-3 mb-2">
          <div className="bg-[#EF626C]/10 p-3 rounded-xl text-center">
            <ShoppingBag size={20} className="text-[#EF626C] mx-auto mb-1" />
            <div className="text-xs">Spend</div>
            <div className="font-bold">${spendTotal.toFixed(2)}</div>
          </div>
          <div className="bg-[#84DCCF]/10 p-3 rounded-xl text-center">
            <PiggyBank size={20} className="text-[#84DCCF] mx-auto mb-1" />
            <div className="text-xs">Save</div>
            <div className="font-bold">${saveTotal.toFixed(2)}</div>
          </div>
          <div className="bg-[#CBA135]/10 p-3 rounded-xl text-center">
            <Heart size={20} className="text-[#CBA135] mx-auto mb-1" />
            <div className="text-xs">Give</div>
            <div className="font-bold">${giveTotal.toFixed(2)}</div>
          </div>
        </div>

        <div className="mt-4">
          <div className="flex justify-between mb-1">
            <span className="text-sm font-medium">Saving Goal: ${savingGoal}</span>
            <span className="text-sm font-medium">{Math.min(100, (saveTotal / savingGoal) * 100).toFixed(0)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className="bg-[#84DCCF] h-3 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, (saveTotal / savingGoal) * 100)}%` }}
            ></div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-white p-4 rounded-2xl shadow-md">
          <h2 className="font-bold text-lg mb-3 flex items-center gap-2">
            <Minus className="text-[#EF626C]" size={18} />
            Spend Money
          </h2>
          <div className="space-y-2">
            {spendOptions.map((option) => (
              <button
                key={option.id}
                onClick={() => addTransaction(option.description, option.amount, option.category, true)}
                className="w-full p-2 bg-[#EF626C]/10 rounded-xl text-left flex justify-between items-center"
              >
                <span>{option.description}</span>
                <span className="font-bold text-[#EF626C]">-${option.amount}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl shadow-md">
          <h2 className="font-bold text-lg mb-3 flex items-center gap-2">
            <Plus className="text-[#84DCCF]" size={18} />
            Earn Money
          </h2>
          <div className="space-y-2">
            {earnOptions.map((option) => (
              <button
                key={option.id}
                onClick={() => addTransaction(option.description, option.amount, option.category, false)}
                className="w-full p-2 bg-[#84DCCF]/10 rounded-xl text-left flex justify-between items-center"
              >
                <span>{option.description}</span>
                <span className="font-bold text-[#84DCCF]">+${option.amount}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-white p-4 rounded-2xl shadow-md">
          <h2 className="font-bold text-lg mb-3 flex items-center gap-2">
            <PiggyBank className="text-[#84DCCF]" size={18} />
            Save Money
          </h2>
          <div className="space-y-2">
            {saveOptions.map((option) => (
              <button
                key={option.id}
                onClick={() => addTransaction(option.description, option.amount, option.category, false)}
                className="w-full p-2 bg-[#84DCCF]/10 rounded-xl text-left flex justify-between items-center"
              >
                <span>{option.description}</span>
                <span className="font-bold text-[#84DCCF]">+${option.amount}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl shadow-md">
          <h2 className="font-bold text-lg mb-3 flex items-center gap-2">
            <Heart className="text-[#CBA135]" size={18} />
            Give Money
          </h2>
          <div className="space-y-2">
            {giveOptions.map((option) => (
              <button
                key={option.id}
                onClick={() => addTransaction(option.description, option.amount, option.category, false)}
                className="w-full p-2 bg-[#CBA135]/10 rounded-xl text-left flex justify-between items-center"
              >
                <span>{option.description}</span>
                <span className="font-bold text-[#CBA135]">+${option.amount}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-2xl shadow-md mb-6">
        <h2 className="font-bold text-lg mb-3">Recent Transactions</h2>
        {transactions.length === 0 ? (
          <p className="text-center text-gray-500 py-4">No transactions yet</p>
        ) : (
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {transactions.map((transaction) => (
              <div
                key={transaction.id}
                className={`p-3 rounded-xl flex justify-between items-center ${
                  transaction.category === "spend"
                    ? "bg-[#EF626C]/10"
                    : transaction.category === "save"
                      ? "bg-[#84DCCF]/10"
                      : "bg-[#CBA135]/10"
                }`}
              >
                <div>
                  <div className="font-medium">{transaction.description}</div>
                  <div className="text-xs text-gray-500">{transaction.date}</div>
                </div>
                <div
                  className={`font-bold ${
                    transaction.category === "spend"
                      ? "text-[#EF626C]"
                      : transaction.category === "save"
                        ? "text-[#84DCCF]"
                        : "text-[#CBA135]"
                  }`}
                >
                  {transaction.category === "spend" ? "-" : "+"}${transaction.amount.toFixed(2)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Animations */}
      <AnimatePresence>
        {showAnimation === "save" && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5, y: 100 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.5, y: 100 }}
            className="fixed bottom-24 left-1/2 transform -translate-x-1/2 bg-white p-4 rounded-full shadow-lg"
          >
            <PiggyBank size={40} className="text-[#84DCCF]" />
          </motion.div>
        )}

        {showAnimation === "give" && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5, y: 100 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.5, y: 100 }}
            className="fixed bottom-24 left-1/2 transform -translate-x-1/2 bg-white p-4 rounded-full shadow-lg"
          >
            <Heart size={40} className="text-[#CBA135]" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Goal reached modal */}
      <AnimatePresence>
        {showGoalReached && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="bg-white rounded-2xl p-6 w-full max-w-sm text-center"
            >
              <div className="mb-4">
                <div className="w-20 h-20 bg-[#84DCCF] rounded-full flex items-center justify-center mx-auto">
                  <PiggyBank size={40} className="text-white" />
                </div>
              </div>

              <h2 className="text-2xl font-bold mb-2">Saving Goal Reached!</h2>
              <p className="mb-4">Congratulations! You've reached your saving goal of ${savingGoal}!</p>

              <div className="text-4xl font-bold text-[#84DCCF] mb-6">${saveTotal.toFixed(2)}</div>

              <div className="space-y-3">
                <button
                  onClick={() => {
                    setShowGoalReached(false)
                    setSavingGoal(savingGoal * 2)
                  }}
                  className="block w-full py-3 bg-[#84DCCF] rounded-2xl font-medium"
                >
                  Set New Goal (${savingGoal * 2})
                </button>
                <Link href="/missions" className="block w-full py-3 bg-gray-100 rounded-2xl font-medium">
                  Back to Missions
                </Link>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
