"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, ShoppingCart, CheckCircle, XCircle, Lightbulb, ArrowRight } from "lucide-react"

export default function SmartShoppingPage() {
  const [currentRound, setCurrentRound] = useState(1)
  const [score, setScore] = useState(0)
  const [selectedProduct, setSelectedProduct] = useState<number | null>(null)
  const [showFeedback, setShowFeedback] = useState(false)
  const [showCompletionModal, setShowCompletionModal] = useState(false)
  const [tip, setTip] = useState("")

  const rounds = [
    {
      category: "Headphones",
      products: [
        {
          name: "Basic Headphones",
          price: 25.99,
          reviews: "3.2 ★ (42 reviews)",
          features: "Wired, 1-year warranty",
          bestValue: false,
        },
        {
          name: "Premium Headphones",
          price: 89.99,
          reviews: "4.7 ★ (156 reviews)",
          features: "Wireless, Noise-cancelling, 2-year warranty",
          bestValue: true,
        },
        {
          name: "Mid-range Headphones",
          price: 49.99,
          reviews: "4.1 ★ (87 reviews)",
          features: "Wireless, 1-year warranty",
          bestValue: false,
        },
      ],
      tip: "Higher price doesn't always mean better value. Look at features, reviews, and warranty to determine the best value for your needs.",
    },
    {
      category: "Backpacks",
      products: [
        {
          name: "Designer Backpack",
          price: 79.99,
          reviews: "3.8 ★ (64 reviews)",
          features: "Stylish design, limited warranty",
          bestValue: false,
        },
        {
          name: "Budget Backpack",
          price: 19.99,
          reviews: "3.5 ★ (112 reviews)",
          features: "Basic features, no warranty",
          bestValue: false,
        },
        {
          name: "Student Backpack",
          price: 39.99,
          reviews: "4.6 ★ (203 reviews)",
          features: "Durable, water-resistant, lifetime warranty",
          bestValue: true,
        },
      ],
      tip: "When buying a backpack, durability and warranty can save you money in the long run, even if the initial price is higher.",
    },
    {
      category: "Sneakers",
      products: [
        {
          name: "Brand Name Sneakers",
          price: 129.99,
          reviews: "4.2 ★ (178 reviews)",
          features: "Stylish, moderate durability",
          bestValue: false,
        },
        {
          name: "Budget Sneakers",
          price: 29.99,
          reviews: "2.8 ★ (45 reviews)",
          features: "Basic design, low durability",
          bestValue: false,
        },
        {
          name: "Athletic Sneakers",
          price: 79.99,
          reviews: "4.8 ★ (312 reviews)",
          features: "Comfortable, highly durable, 1-year warranty",
          bestValue: true,
        },
      ],
      tip: "For items you use daily like shoes, investing in quality can save money over time as they won't need to be replaced as often.",
    },
    {
      category: "Smartphones",
      products: [
        {
          name: "Latest Flagship Phone",
          price: 999.99,
          reviews: "4.5 ★ (1243 reviews)",
          features: "Top specs, 1-year warranty",
          bestValue: false,
        },
        {
          name: "Mid-range Smartphone",
          price: 399.99,
          reviews: "4.7 ★ (876 reviews)",
          features: "Great specs for the price, 2-year warranty",
          bestValue: true,
        },
        {
          name: "Budget Smartphone",
          price: 199.99,
          reviews: "3.9 ★ (542 reviews)",
          features: "Basic features, 1-year warranty",
          bestValue: false,
        },
      ],
      tip: "The latest technology isn't always necessary. Consider what features you actually need and how long you plan to keep the device.",
    },
    {
      category: "Laptops",
      products: [
        {
          name: "Gaming Laptop",
          price: 1299.99,
          reviews: "4.3 ★ (321 reviews)",
          features: "High performance, heavy, 1-year warranty",
          bestValue: false,
        },
        {
          name: "Ultrabook",
          price: 899.99,
          reviews: "4.6 ★ (567 reviews)",
          features: "Lightweight, good performance, 2-year warranty",
          bestValue: true,
        },
        {
          name: "Budget Laptop",
          price: 399.99,
          reviews: "3.7 ★ (234 reviews)",
          features: "Basic performance, 1-year warranty",
          bestValue: false,
        },
      ],
      tip: "When buying technology, balance your specific needs with price. The most expensive option often includes features you may never use.",
    },
  ]

  const currentRoundData = rounds[currentRound - 1]

  const selectProduct = (index: number) => {
    if (showFeedback) return

    setSelectedProduct(index)
    setShowFeedback(true)

    const isCorrect = currentRoundData.products[index].bestValue
    if (isCorrect) {
      setScore(score + 1)
    }

    setTip(currentRoundData.tip)
  }

  const nextRound = () => {
    setShowFeedback(false)
    setSelectedProduct(null)

    if (currentRound < rounds.length) {
      setCurrentRound(currentRound + 1)
    } else {
      setShowCompletionModal(true)
    }
  }

  return (
    <div className="p-4 pb-20 min-h-screen bg-[#EEE5E9]">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/missions" className="p-2 rounded-full bg-white shadow">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold">Smart Shopping Challenge</h1>
      </div>

      <div className="bg-white p-4 rounded-2xl shadow-md mb-6">
        <div className="flex justify-between items-center mb-2">
          <h2 className="font-bold text-lg flex items-center gap-2">
            <ShoppingCart className="text-[#84DCCF]" />
            Round {currentRound}/{rounds.length}
          </h2>
          <div className="text-xl font-bold text-[#EF626C]">Score: {score}</div>
        </div>

        <p className="text-sm text-gray-600 mb-2">
          Compare the options and tap the one you think offers the best value for money.
        </p>

        <div className="bg-[#84DCCF]/20 p-3 rounded-xl mb-4">
          <h3 className="font-bold text-center">Shopping for: {currentRoundData.category}</h3>
        </div>
      </div>

      <div className="space-y-4 mb-6">
        {currentRoundData.products.map((product, index) => (
          <button
            key={index}
            onClick={() => selectProduct(index)}
            disabled={showFeedback}
            className={`w-full bg-white p-4 rounded-2xl shadow-md text-left relative ${
              showFeedback && selectedProduct === index
                ? product.bestValue
                  ? "border-2 border-green-500"
                  : "border-2 border-red-500"
                : ""
            }`}
          >
            <div className="flex gap-3">
              <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center">
                <Image
                  src={`/placeholder.svg?height=60&width=60&text=${product.name}`}
                  alt={product.name}
                  width={60}
                  height={60}
                />
              </div>
              <div className="flex-1">
                <div className="font-medium">{product.name}</div>
                <div className="text-[#EF626C] font-bold">${product.price.toFixed(2)}</div>
                <div className="text-sm text-gray-600">{product.reviews}</div>
                <div className="text-sm">{product.features}</div>
              </div>
            </div>

            {showFeedback && (
              <div className="absolute top-2 right-2">
                {product.bestValue ? (
                  <CheckCircle className="text-green-500" size={24} />
                ) : selectedProduct === index ? (
                  <XCircle className="text-red-500" size={24} />
                ) : null}
              </div>
            )}
          </button>
        ))}
      </div>

      {showFeedback && (
        <div className="bg-white p-4 rounded-2xl shadow-md mb-6">
          <div className="flex items-start gap-2">
            <Lightbulb className="text-[#CBA135] mt-1 flex-shrink-0" size={20} />
            <div>
              <h3 className="font-bold text-[#CBA135]">Shopping Tip:</h3>
              <p className="text-sm">{tip}</p>
            </div>
          </div>

          <button
            onClick={nextRound}
            className="w-full mt-4 py-3 bg-[#84DCCF] rounded-xl font-medium flex items-center justify-center gap-1"
          >
            {currentRound < rounds.length ? "Next Round" : "See Results"}
            <ArrowRight size={16} />
          </button>
        </div>
      )}

      {/* Completion modal */}
      <AnimatePresence>
        {showCompletionModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="bg-white rounded-2xl p-6 w-full max-w-sm text-center"
            >
              <div className="mb-4">
                <div className="w-20 h-20 bg-[#84DCCF] rounded-full flex items-center justify-center mx-auto">
                  <ShoppingCart size={40} className="text-white" />
                </div>
              </div>

              <h2 className="text-2xl font-bold mb-2">Challenge Complete!</h2>
              <p className="mb-4">You've completed the Smart Shopping Challenge!</p>

              <div className="text-4xl font-bold text-[#EF626C] mb-6">
                {score}/{rounds.length}
              </div>

              <p className="text-sm text-gray-600 mb-6">
                {score === rounds.length
                  ? "Perfect score! You're a smart shopping expert!"
                  : score >= Math.floor(rounds.length * 0.7)
                    ? "Great job! You're becoming a savvy shopper!"
                    : "Keep practicing your comparison shopping skills!"}
              </p>

              <div className="space-y-3">
                <Link href="/missions" className="block w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
                  Back to Missions
                </Link>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
