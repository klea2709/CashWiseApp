"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { ArrowLeft, Brain, Star, Clock, RefreshCw } from "lucide-react"
import confetti from "canvas-confetti"

// Financial terms for the memory game
const financialTerms = [
  { id: "budget", term: "Budget", definition: "A plan for your money" },
  { id: "saving", term: "Saving", definition: "Setting money aside for later" },
  { id: "interest", term: "Interest", definition: "Money paid for using someone else's money" },
  { id: "credit", term: "Credit", definition: "Borrowed money that must be repaid" },
  { id: "debit", term: "Debit", definition: "Money taken directly from your account" },
  { id: "invest", term: "Invest", definition: "Using money to make more money" },
  { id: "loan", term: "Loan", definition: "Money borrowed that must be paid back" },
  { id: "income", term: "Income", definition: "Money you receive or earn" },
]

// Create pairs of cards (terms and definitions)
const createCards = () => {
  const cards = []
  financialTerms.forEach((item) => {
    cards.push({
      id: `${item.id}-term`,
      content: item.term,
      matchId: `${item.id}-def`,
      type: "term",
    })
    cards.push({
      id: `${item.id}-def`,
      content: item.definition,
      matchId: `${item.id}-term`,
      type: "definition",
    })
  })
  return shuffleCards(cards)
}

// Shuffle cards
const shuffleCards = (cards: any[]) => {
  return [...cards].sort(() => Math.random() - 0.5)
}

export default function MemoryGamePage() {
  const [cards, setCards] = useState<any[]>([])
  const [flippedCards, setFlippedCards] = useState<string[]>([])
  const [matchedPairs, setMatchedPairs] = useState<string[]>([])
  const [moves, setMoves] = useState(0)
  const [gameStarted, setGameStarted] = useState(false)
  const [gameCompleted, setGameCompleted] = useState(false)
  const [timer, setTimer] = useState(0)
  const [stars, setStars] = useState(3)

  // Initialize game
  useEffect(() => {
    setCards(createCards())
  }, [])

  // Start timer when game starts
  useEffect(() => {
    let interval: NodeJS.Timeout
    if (gameStarted && !gameCompleted) {
      interval = setInterval(() => {
        setTimer((prev) => prev + 1)
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [gameStarted, gameCompleted])

  // Check for game completion
  useEffect(() => {
    if (matchedPairs.length === financialTerms.length && gameStarted) {
      setGameCompleted(true)
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      })
    }
  }, [matchedPairs, gameStarted])

  // Update stars based on moves
  useEffect(() => {
    if (moves > 20) {
      setStars(2)
    }
    if (moves > 30) {
      setStars(1)
    }
  }, [moves])

  const handleCardClick = (cardId: string) => {
    // Start game on first card click
    if (!gameStarted) {
      setGameStarted(true)
    }

    // Ignore click if card is already flipped or matched
    if (flippedCards.includes(cardId) || matchedPairs.includes(cardId)) {
      return
    }

    // Flip card
    const newFlippedCards = [...flippedCards, cardId]
    setFlippedCards(newFlippedCards)

    // Check for match if two cards are flipped
    if (newFlippedCards.length === 2) {
      setMoves((prev) => prev + 1)

      const [firstCardId, secondCardId] = newFlippedCards
      const firstCard = cards.find((card) => card.id === firstCardId)
      const secondCard = cards.find((card) => card.id === secondCardId)

      if (firstCard.matchId === secondCardId) {
        // Match found
        setMatchedPairs((prev) => [...prev, firstCardId, secondCardId])
        setFlippedCards([])
      } else {
        // No match, flip cards back after delay
        setTimeout(() => {
          setFlippedCards([])
        }, 1000)
      }
    }
  }

  const resetGame = () => {
    setCards(createCards())
    setFlippedCards([])
    setMatchedPairs([])
    setMoves(0)
    setTimer(0)
    setStars(3)
    setGameStarted(false)
    setGameCompleted(false)
  }

  // Format time display
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`
  }

  return (
    <div className="p-4 pb-20 min-h-screen bg-[#EEE5E9]">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/missions" className="p-2 rounded-full bg-white shadow">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold">Financial Memory Game</h1>
      </div>

      <div className="bg-white p-4 rounded-2xl shadow-md mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-bold text-lg flex items-center gap-2">
            <Brain className="text-[#84DCCF]" />
            Match Terms & Definitions
          </h2>
          <button onClick={resetGame} className="p-2 bg-gray-100 rounded-full">
            <RefreshCw size={18} />
          </button>
        </div>

        <div className="flex justify-between mb-4">
          <div className="flex items-center gap-1">
            <Clock size={16} />
            <span>{formatTime(timer)}</span>
          </div>
          <div className="flex items-center gap-1">
            <span>Moves: {moves}</span>
          </div>
          <div className="flex">
            {[...Array(3)].map((_, i) => (
              <Star key={i} size={16} className={i < stars ? "text-[#CBA135] fill-[#CBA135]" : "text-gray-300"} />
            ))}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 mb-4">
          {cards.map((card) => (
            <motion.div
              key={card.id}
              className={`aspect-[3/2] rounded-xl cursor-pointer ${
                flippedCards.includes(card.id) || matchedPairs.includes(card.id)
                  ? card.type === "term"
                    ? "bg-[#84DCCF]"
                    : "bg-[#EF626C]"
                  : "bg-gray-200"
              }`}
              onClick={() => handleCardClick(card.id)}
              whileHover={{ scale: flippedCards.includes(card.id) || matchedPairs.includes(card.id) ? 1 : 1.05 }}
              animate={{
                rotateY: flippedCards.includes(card.id) || matchedPairs.includes(card.id) ? 180 : 0,
                opacity: matchedPairs.includes(card.id) ? 0.7 : 1,
              }}
              transition={{ duration: 0.3 }}
            >
              <div className="w-full h-full flex items-center justify-center p-2 text-center">
                {flippedCards.includes(card.id) || matchedPairs.includes(card.id) ? (
                  <div className="transform rotate-180 text-white font-medium text-sm">{card.content}</div>
                ) : (
                  <div className="text-gray-400 text-sm">?</div>
                )}
              </div>
            </motion.div>
          ))}
        </div>

        <p className="text-sm text-gray-600 text-center">Match financial terms with their definitions to win!</p>
      </div>

      {/* Game completion modal */}
      <AnimatePresence>
        {gameCompleted && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="bg-white rounded-2xl p-6 w-full max-w-sm text-center"
            >
              <div className="mb-4">
                <div className="w-20 h-20 bg-[#84DCCF] rounded-full flex items-center justify-center mx-auto">
                  <Brain size={40} className="text-white" />
                </div>
              </div>

              <h2 className="text-2xl font-bold mb-2">Congratulations!</h2>
              <p className="mb-4">You've completed the Financial Memory Game!</p>

              <div className="space-y-2 mb-6">
                <div className="flex justify-between">
                  <span>Time:</span>
                  <span className="font-bold">{formatTime(timer)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Moves:</span>
                  <span className="font-bold">{moves}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Rating:</span>
                  <div className="flex">
                    {[...Array(3)].map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className={i < stars ? "text-[#CBA135] fill-[#CBA135]" : "text-gray-300"}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <button onClick={resetGame} className="block w-full py-3 bg-[#84DCCF] rounded-2xl font-medium">
                  Play Again
                </button>
                <Link href="/missions" className="block w-full py-3 bg-gray-100 rounded-2xl font-medium">
                  Back to Missions
                </Link>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
