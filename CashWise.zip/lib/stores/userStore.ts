// Create a new file for the user store using Zustand
import { create } from "zustand"
import { persist } from "zustand/middleware"
import type { User } from "@/lib/types"

interface UserState {
  user: User
  addFinPoints: (points: number) => void
  addTeenCoins: (coins: number) => void
  incrementStreak: () => void
  resetStreak: () => void
  updateUser: (userData: Partial<User>) => void
}

export const useUserStore = create<UserState>()(
  persist(
    (set) => ({
      user: {
        id: "1",
        name: "Alex",
        email: "alex@example.com",
        avatar: "/placeholder.svg?height=40&width=40",
        level: 3,
        levelTitle: "Budget Rookie",
        streak: 4,
        teenCoins: 250,
        finPoints: 450,
      },
      addFinPoints: (points) =>
        set((state) => ({
          user: {
            ...state.user,
            finPoints: state.user.finPoints + points,
          },
        })),
      addTeenCoins: (coins) =>
        set((state) => ({
          user: {
            ...state.user,
            teenCoins: state.user.teenCoins + coins,
          },
        })),
      incrementStreak: () =>
        set((state) => ({
          user: {
            ...state.user,
            streak: state.user.streak + 1,
          },
        })),
      resetStreak: () =>
        set((state) => ({
          user: {
            ...state.user,
            streak: 0,
          },
        })),
      updateUser: (userData) =>
        set((state) => ({
          user: {
            ...state.user,
            ...userData,
          },
        })),
    }),
    {
      name: "finmate-user-storage",
    },
  ),
)
