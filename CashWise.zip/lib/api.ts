import type { Mission, Lesson, WalletData, UserProfile } from "./types"
import { mockMissions, mockLessons, mockWalletData, mockUserProfile } from "./mockData"

// Missions
export async function getMissions(): Promise<Mission[]> {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockMissions)
    }, 500)
  })
}

// Lessons
export async function getLessons(): Promise<Lesson[]> {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockLessons)
    }, 500)
  })
}

export async function getLessonById(id: string): Promise<Lesson | null> {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      const lesson = mockLessons.find((lesson) => lesson.id === id)
      resolve(lesson || null)
    }, 500)
  })
}

// Chat
export async function getChatResponse(message: string): Promise<string> {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      // Simple responses based on keywords
      if (message.toLowerCase().includes("save")) {
        resolve(
          "Saving money is a great habit! Try the 50/30/20 rule: 50% for needs, 30% for wants, and 20% for savings.",
        )
      } else if (message.toLowerCase().includes("invest")) {
        resolve(
          "Investing is about making your money work for you! As a teen, you can start learning with simulations or with parental guidance.",
        )
      } else if (message.toLowerCase().includes("budget")) {
        resolve(
          "Budgeting helps you plan where your money goes. Start by tracking your income and expenses, then set limits for different categories.",
        )
      } else {
        resolve(
          "That's a great question about finance! Would you like to learn more about saving, budgeting, or investing?",
        )
      }
    }, 1000)
  })
}

// Wallet
export async function getWalletData(): Promise<WalletData> {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockWalletData)
    }, 500)
  })
}

// User Profile
export async function getUserProfile(): Promise<UserProfile> {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockUserProfile)
    }, 500)
  })
}

// Avatar
export async function saveAvatar(avatar: any): Promise<void> {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log("Avatar saved:", avatar)
      resolve()
    }, 500)
  })
}
