import { Bike, Book, ShoppingBag, Brain } from "lucide-react"
import type { Mission, Lesson } from "./types"

// Mock Missions
export const mockMissions: Mission[] = [
  {
    id: "1",
    title: "Save for Your Dream Bike",
    description: "Learn how to set a savings goal and track your progress",
    icon: Bike,
    color: "#84DCCF",
    progress: 40,
    reward: 200,
    tasks: [
      { id: "1-1", title: "Set a specific savings goal", completed: true },
      { id: "1-2", title: "Create a timeline for saving", completed: true },
      { id: "1-3", title: "Track your weekly progress", completed: false },
      { id: "1-4", title: "Reach your goal", completed: false },
    ],
  },
  {
    id: "2",
    title: "Budget for School Supplies",
    description: "Create a budget for your back-to-school shopping",
    icon: Book,
    color: "#EF626C",
    progress: 70,
    reward: 150,
    tasks: [
      { id: "2-1", title: "List all needed supplies", completed: true },
      { id: "2-2", title: "Research prices", completed: true },
      { id: "2-3", title: "Create a budget", completed: true },
      { id: "2-4", title: "Shop within your budget", completed: false },
    ],
  },
  {
    id: "3",
    title: "Smart Shopping Challenge",
    description: "Learn to compare prices and find the best deals",
    icon: ShoppingBag,
    color: "#CBA135",
    progress: 20,
    reward: 100,
    tasks: [
      { id: "3-1", title: "Compare prices at 3 different stores", completed: true },
      { id: "3-2", title: "Find and use a coupon", completed: false },
      { id: "3-3", title: "Calculate the savings", completed: false },
      { id: "3-4", title: "Make a smart purchase", completed: false },
    ],
  },
  {
    id: "6",
    title: "Financial Memory Game",
    description: "Match financial terms with their definitions",
    icon: Brain,
    color: "#84DCCF",
    progress: 0,
    reward: 150,
    tasks: [
      { id: "6-1", title: "Learn financial terms", completed: false },
      { id: "6-2", title: "Complete the memory game", completed: false },
      { id: "6-3", title: "Earn all three stars", completed: false },
    ],
  },
]

// Mock Lessons
export const mockLessons: Lesson[] = [
  {
    id: "1",
    title: "Budgeting Basics",
    description: "Learn how to create and stick to a budget",
    content:
      "A budget is a plan for your money. It helps you track your income and expenses so you can make smart decisions about your money. In this lesson, we'll learn how to create a simple budget and stick to it.",
    points: 50,
    quiz: [
      {
        question: "What is the main purpose of a budget?",
        options: [
          "To restrict your spending",
          "To plan and track your money",
          "To make you save everything",
          "To impress your parents",
        ],
        correctIndex: 1,
        explanation:
          "A budget helps you plan where your money will go and track where it actually went. It's a tool for making informed decisions, not just restricting spending.",
      },
      {
        question: "What should you do first when creating a budget?",
        options: [
          "Set spending limits",
          "Open a bank account",
          "Track your income and expenses",
          "Ask for more allowance",
        ],
        correctIndex: 2,
        explanation:
          "Before you can create an effective budget, you need to know how much money you have coming in and where it's currently going.",
      },
      {
        question: "What is the 50/30/20 rule in budgeting?",
        options: [
          "50% savings, 30% needs, 20% wants",
          "50% needs, 30% wants, 20% savings",
          "50% wants, 30% savings, 20% needs",
          "50% to parents, 30% to friends, 20% to yourself",
        ],
        correctIndex: 1,
        explanation:
          "The 50/30/20 rule suggests allocating 50% of your income to needs, 30% to wants, and 20% to savings or debt repayment.",
      },
    ],
  },
  {
    id: "2",
    title: "Saving Strategies",
    description: "Discover effective ways to save money",
    content:
      "Saving money is an important financial habit. In this lesson, we'll explore different strategies to help you save money effectively, set savings goals, and track your progress.",
    points: 50,
    quiz: [
      {
        question: "Why is it important to have savings?",
        options: [
          "To impress friends",
          "To handle emergencies and reach goals",
          "To avoid using banks",
          "To make parents happy",
        ],
        correctIndex: 1,
        explanation:
          "Savings help you handle unexpected expenses (emergencies) and achieve your financial goals, like buying something special or paying for education.",
      },
      {
        question: 'What is the "pay yourself first" strategy?',
        options: [
          "Spending money on yourself before anything else",
          "Getting paid before doing work",
          "Saving a portion of income before spending on other things",
          "Paying your own bills instead of parents paying them",
        ],
        correctIndex: 2,
        explanation:
          '"Pay yourself first" means automatically setting aside money for savings as soon as you receive income, before you spend on other things.',
      },
      {
        question: "What makes a good savings goal?",
        options: [
          "It should be vague so you can change it easily",
          "It should be impossible to reach to keep you motivated",
          "It should be specific, measurable, and have a deadline",
          "It should only focus on very expensive items",
        ],
        correctIndex: 2,
        explanation:
          "Effective savings goals are specific (what you're saving for), measurable (how much you need), and time-bound (when you want to reach it).",
      },
    ],
  },
  {
    id: "3",
    title: "Understanding Credit Cards",
    description: "Learn the basics of credit cards and how to use them responsibly",
    content:
      "Credit cards can be powerful financial tools when used responsibly. In this lesson, we'll learn about how credit cards work, the benefits and risks, and how to use them wisely when you're old enough.",
    points: 50,
    quiz: [
      {
        question: "What happens when you use a credit card?",
        options: [
          "Money is immediately taken from your bank account",
          "You're borrowing money that you must pay back later",
          "The item is free if you use a credit card",
          "Your parents are automatically charged",
        ],
        correctIndex: 1,
        explanation:
          "When you use a credit card, you're borrowing money from the credit card company. You'll need to pay it back, usually monthly.",
      },
      {
        question: "What is credit card interest?",
        options: [
          "A reward you get for using your card",
          "The fee you pay for borrowing money if you don't pay in full",
          "The minimum payment required each month",
          "The maximum amount you can spend",
        ],
        correctIndex: 1,
        explanation:
          "Interest is the fee you pay for borrowing money. If you don't pay your credit card balance in full each month, you'll be charged interest on the remaining amount.",
      },
      {
        question: "What is a good habit when using credit cards?",
        options: [
          "Only making the minimum payment",
          "Spending up to your credit limit",
          "Paying your balance in full each month",
          "Having many credit cards",
        ],
        correctIndex: 2,
        explanation:
          "Paying your balance in full each month helps you avoid interest charges and build good credit habits.",
      },
    ],
  },
]

export const mockWalletData = {
  balance: 1250,
  lastUpdated: "2023-11-19",
  transactions: [
    {
      id: "1",
      title: "Allowance",
      amount: 50,
      date: "2023-11-18",
      type: "earn",
    },
    {
      id: "2",
      title: "Movie Ticket",
      amount: 15,
      date: "2023-11-17",
      type: "spend",
    },
    {
      id: "3",
      title: "Tutoring",
      amount: 75,
      date: "2023-11-16",
      type: "earn",
    },
    {
      id: "4",
      title: "Snacks",
      amount: 8,
      date: "2023-11-15",
      type: "spend",
    },
  ],
}

export const mockUserProfile = {
  name: "Alex Johnson",
  avatar: "/placeholder.svg?height=100&width=100",
  level: 3,
  levelTitle: "Budget Rookie",
  stats: {
    finPoints: 450,
    missions: 7,
    streak: 4,
  },
  badges: [
    { id: "1", name: "Savings Starter", unlocked: true },
    { id: "2", name: "Budget Beginner", unlocked: true },
    { id: "3", name: "Mission Master", unlocked: false },
    { id: "4", name: "Streak Superstar", unlocked: false },
    { id: "5", name: "Quiz Whiz", unlocked: false },
    { id: "6", name: "Investment Explorer", unlocked: false },
    { id: "7", name: "Goal Getter", unlocked: false },
    { id: "8", name: "Challenge Champion", unlocked: false },
  ],
  goals: [
    { id: "1", title: "Save $500", progress: 60 },
    { id: "2", title: "Complete 10 Missions", progress: 70 },
    { id: "3", title: "Maintain a 30-Day Streak", progress: 40 },
  ],
}
