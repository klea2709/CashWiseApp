"use client"

import { useState } from "react"

interface AmortizationPayment {
  month: number
  payment: number
  principal: number
  interest: number
  balance: number
}

export function useLoanCalculator() {
  const [loanAmount, setLoanAmount] = useState(1000)
  const [interestRate, setInterestRate] = useState(5)
  const [loanTerm, setLoanTerm] = useState(12)
  const [monthlyPayment, setMonthlyPayment] = useState(0)
  const [totalInterest, setTotalInterest] = useState(0)
  const [totalCost, setTotalCost] = useState(0)
  const [amortizationSchedule, setAmortizationSchedule] = useState<AmortizationPayment[]>([])

  const calculateLoan = () => {
    // Convert annual interest rate to monthly
    const monthlyRate = interestRate / 100 / 12

    // Calculate monthly payment using the formula: P * r * (1 + r)^n / ((1 + r)^n - 1)
    const payment =
      (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, loanTerm)) / (Math.pow(1 + monthlyRate, loanTerm) - 1)

    setMonthlyPayment(payment)

    // Calculate total cost and interest
    const totalPayment = payment * loanTerm
    setTotalCost(totalPayment)
    setTotalInterest(totalPayment - loanAmount)

    // Generate amortization schedule
    const schedule: AmortizationPayment[] = []
    let balance = loanAmount

    for (let month = 1; month <= loanTerm; month++) {
      const interestPayment = balance * monthlyRate
      const principalPayment = payment - interestPayment
      balance -= principalPayment

      schedule.push({
        month,
        payment,
        principal: principalPayment,
        interest: interestPayment,
        balance: Math.max(0, balance),
      })
    }

    setAmortizationSchedule(schedule)
  }

  const resetLoan = () => {
    setLoanAmount(1000)
    setInterestRate(5)
    setLoanTerm(12)
    setMonthlyPayment(0)
    setTotalInterest(0)
    setTotalCost(0)
    setAmortizationSchedule([])
  }

  return {
    loanAmount,
    setLoanAmount,
    interestRate,
    setInterestRate,
    loanTerm,
    setLoanTerm,
    monthlyPayment,
    totalInterest,
    totalCost,
    amortizationSchedule,
    calculateLoan,
    resetLoan,
  }
}
