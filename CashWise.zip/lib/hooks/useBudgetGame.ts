"use client"

import { useState } from "react"
import type { BudgetCategory } from "@/lib/types"

type GameState = "intro" | "playing" | "results"

export function useBudgetGame() {
  const [budget, setBudget] = useState(100)
  const [allocations, setAllocations] = useState<Record<string, number>>({})
  const [score, setScore] = useState(0)
  const [gameState, setGameState] = useState<GameState>("intro")

  const categories: BudgetCategory[] = [
    {
      id: "savings",
      name: "Savings",
      description: "Money set aside for future goals",
      recommended: 20,
      color: "#84DCCF",
    },
    {
      id: "food",
      name: "Food",
      description: "Snacks, lunch, and treats",
      recommended: 30,
      color: "#EF626C",
    },
    {
      id: "entertainment",
      name: "Entertainment",
      description: "Movies, games, and fun activities",
      recommended: 15,
      color: "#CBA135",
    },
    {
      id: "clothing",
      name: "Clothing",
      description: "New clothes and accessories",
      recommended: 20,
      color: "#84DCCF",
    },
    {
      id: "gifts",
      name: "Gifts",
      description: "Presents for friends and family",
      recommended: 15,
      color: "#EF626C",
    },
  ]

  const remainingBudget = budget - Object.values(allocations).reduce((sum, amount) => sum + amount, 0)

  const setAllocation = (categoryId: string, amount: number) => {
    setAllocations((prev) => ({
      ...prev,
      [categoryId]: amount,
    }))
  }

  const checkBudget = () => {
    // Calculate score based on how close allocations are to recommended values
    let totalScore = 0

    categories.forEach((category) => {
      const allocation = allocations[category.id] || 0
      const difference = Math.abs(allocation - category.recommended)
      const categoryScore = Math.max(0, 100 - (difference / category.recommended) * 100)
      totalScore += categoryScore
    })

    setScore(Math.round(totalScore / categories.length))
    setGameState("results")
  }

  const resetBudget = (newState: GameState = "intro") => {
    setAllocations({})
    setScore(0)
    setGameState(newState)
  }

  return {
    budget,
    categories,
    allocations,
    setAllocation,
    remainingBudget,
    checkBudget,
    resetBudget,
    score,
    gameState,
  }
}
