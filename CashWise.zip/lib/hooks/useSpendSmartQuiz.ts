"use client"

import { useState, useEffect, useRef } from "react"

type GameState = "intro" | "playing" | "results"

interface Question {
  question: string
  options: string[]
  correctIndex: number
  explanation: string
}

export function useSpendSmartQuiz() {
  const [questions] = useState<Question[]>([
    {
      question: "Which is the best way to save money on a purchase?",
      options: [
        "Buy it immediately when you see it",
        "Compare prices at different stores",
        "Always buy the most expensive option",
        "Borrow money to buy it",
      ],
      correctIndex: 1,
      explanation: "Comparing prices helps you find the best deal and save money.",
    },
    {
      question: "What is an impulse purchase?",
      options: [
        "A purchase you plan for weeks",
        "A purchase you make suddenly without planning",
        "A purchase your parents approve",
        "A purchase that's on sale",
      ],
      correctIndex: 1,
      explanation: "Impulse purchases are unplanned and often unnecessary, leading to wasted money.",
    },
    {
      question: "When is it worth paying more for an item?",
      options: [
        "When it's trendy",
        "When your friends have it",
        "When it's better quality and will last longer",
        "When it's the newest version",
      ],
      correctIndex: 2,
      explanation: "Sometimes paying more for quality items that last longer saves money in the long run.",
    },
    {
      question: "What should you consider before making a purchase?",
      options: [
        "If it's popular on social media",
        "If you need it and can afford it",
        "If it will impress others",
        "If it's the most expensive option",
      ],
      correctIndex: 1,
      explanation: "Always consider if you truly need an item and if it fits in your budget before buying.",
    },
    {
      question: "What is a 'need' versus a 'want'?",
      options: [
        "Needs are things you can live without, wants are essential",
        "Needs are essential items, wants are nice but not necessary",
        "They are the same thing",
        "Needs are expensive, wants are cheap",
      ],
      correctIndex: 1,
      explanation:
        "Needs are essential for living (food, shelter), while wants are things that improve life but aren't necessary.",
    },
  ])

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [timeLeft, setTimeLeft] = useState(15)
  const [score, setScore] = useState(0)
  const [streak, setStreak] = useState(0)
  const [gameState, setGameState] = useState<GameState>("intro")
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  const startQuiz = () => {
    setCurrentQuestionIndex(0)
    setSelectedAnswer(null)
    setTimeLeft(15)
    setScore(0)
    setStreak(0)
    setGameState("playing")
  }

  const restartQuiz = () => {
    startQuiz()
  }

  const selectAnswer = (index: number) => {
    if (selectedAnswer !== null) return

    setSelectedAnswer(index)
    if (timerRef.current) {
      clearInterval(timerRef.current)
    }

    const isCorrect = index === questions[currentQuestionIndex].correctIndex
    if (isCorrect) {
      // Award points based on time left
      const pointsEarned = 100 + timeLeft * 10
      setScore((prev) => prev + pointsEarned)
      setStreak((prev) => prev + 1)
    } else {
      setStreak(0)
    }
  }

  const nextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1)
      setSelectedAnswer(null)
      setTimeLeft(15)
    } else {
      setGameState("results")
    }
  }

  useEffect(() => {
    if (gameState !== "playing" || selectedAnswer !== null) return

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current as NodeJS.Timeout)
          selectAnswer(-1) // Force timeout
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [gameState, currentQuestionIndex, selectedAnswer])

  return {
    questions,
    currentQuestionIndex,
    selectedAnswer,
    timeLeft,
    score,
    streak,
    gameState,
    selectAnswer,
    nextQuestion,
    startQuiz,
    restartQuiz,
  }
}
