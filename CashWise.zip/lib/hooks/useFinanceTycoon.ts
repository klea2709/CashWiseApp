"use client"

import { useState } from "react"

type GameState = "setup" | "playing" | "gameover"

export function useFinanceTycoon() {
  const [businessName, setBusinessName] = useState("My Lemonade Stand")
  const [day, setDay] = useState(1)
  const [cash, setCash] = useState(50)
  const [income, setIncome] = useState(0)
  const [expenses, setExpenses] = useState(0)
  const [inventory, setInventory] = useState(20)
  const [price, setPrice] = useState(2)
  const [marketing, setMarketing] = useState(10)
  const [dailySales, setDailySales] = useState(0)
  const [dailyExpenses, setDailyExpenses] = useState(0)
  const [dailyProfit, setDailyProfit] = useState(0)
  const [salesHistory, setSalesHistory] = useState<number[]>([])
  const [gameState, setGameState] = useState<GameState>("setup")

  const startBusiness = () => {
    setGameState("playing")
  }

  const buyInventory = () => {
    if (cash >= 10) {
      setCash((prev) => prev - 10)
      setInventory((prev) => prev + 20)
      setExpenses((prev) => prev + 10)
    }
  }

  const nextDay = () => {
    // Calculate sales based on price, marketing, and some randomness
    const baseSales = Math.max(0, 20 - price * 5) // Lower price = more sales
    const marketingBoost = marketing / 10 // Marketing increases sales
    const weatherFactor = 0.7 + Math.random() * 0.6 // Random factor (weather, etc.)

    let sales = Math.round(baseSales * (1 + marketingBoost) * weatherFactor)
    sales = Math.min(sales, inventory) // Can't sell more than inventory

    const dailyRevenue = sales * price
    const dailyExpense = marketing
    const profit = dailyRevenue - dailyExpense

    // Update game state
    setCash((prev) => prev + profit)
    setInventory((prev) => prev - sales)
    setIncome((prev) => prev + dailyRevenue)
    setExpenses((prev) => prev + dailyExpense)
    setDailySales(sales)
    setDailyExpenses(dailyExpense)
    setDailyProfit(profit)
    setSalesHistory((prev) => [...prev, sales])
    setDay((prev) => prev + 1)

    // Check for game over condition
    if (day >= 7) {
      setGameState("gameover")
    }
  }

  return {
    businessName,
    setBusinessName,
    day,
    cash,
    income,
    expenses,
    inventory,
    price,
    setPrice,
    marketing,
    setMarketing,
    dailySales,
    dailyExpenses,
    dailyProfit,
    salesHistory,
    startBusiness,
    nextDay,
    buyInventory,
    gameState,
  }
}
