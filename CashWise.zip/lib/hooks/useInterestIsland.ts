"use client"

import { useState } from "react"

type GameState = "intro" | "playing" | "results"

export function useInterestIsland() {
  const [day, setDay] = useState(1)
  const [balance, setBalance] = useState(100)
  const [interestRate, setInterestRate] = useState(3)
  const [depositAmount, setDepositAmount] = useState(50)
  const [withdrawAmount, setWithdrawAmount] = useState(0)
  const [treeHeight, setTreeHeight] = useState(20)
  const [interestEarned, setInterestEarned] = useState(0)
  const [totalInterestEarned, setTotalInterestEarned] = useState(0)
  const [gameState, setGameState] = useState<GameState>("intro")

  const deposit = () => {
    if (depositAmount > 0) {
      setBalance((prev) => prev + depositAmount)
      setDepositAmount(0)
    }
  }

  const withdraw = () => {
    if (withdrawAmount > 0 && withdrawAmount <= balance) {
      setBalance((prev) => prev - withdrawAmount)
      setWithdrawAmount(0)
    }
  }

  const nextDay = () => {
    // Calculate daily interest
    const dailyInterest = balance * (interestRate / 100 / 365)

    // Update state
    setInterestEarned(dailyInterest)
    setTotalInterestEarned((prev) => prev + dailyInterest)
    setBalance((prev) => prev + dailyInterest)
    setDay((prev) => prev + 1)

    // Update tree height based on balance
    setTreeHeight(20 + balance / 5)

    // End game after 30 days
    if (day >= 30) {
      setGameState("results")
    }
  }

  const resetGame = (newState: GameState = "intro") => {
    setDay(1)
    setBalance(100)
    setInterestRate(3)
    setDepositAmount(50)
    setWithdrawAmount(0)
    setTreeHeight(20)
    setInterestEarned(0)
    setTotalInterestEarned(0)
    setGameState(newState)
  }

  return {
    day,
    balance,
    interestRate,
    setInterestRate,
    depositAmount,
    setDepositAmount,
    withdrawAmount,
    setWithdrawAmount,
    treeHeight,
    interestEarned,
    totalInterestEarned,
    deposit,
    withdraw,
    nextDay,
    resetGame,
    gameState,
  }
}
