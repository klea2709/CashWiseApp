"use client"

import { useState } from "react"
import type { CryptoAsset } from "@/lib/types"

type GameState = "intro" | "playing" | "results"

interface QuizResult {
  correct: boolean
  selectedIndex: number
  correctIndex: number
  explanation: string
}

export function useCryptoCaution() {
  const [balance, setBalance] = useState(1000)
  const [cryptos, setCryptos] = useState<CryptoAsset[]>([
    { symbol: "BTC", name: "Bitcoin", price: 50000, change: 2.5 },
    { symbol: "ETH", name: "Ethereum", price: 3000, change: -1.2 },
    { symbol: "SOL", name: "Solana", price: 100, change: 5.7 },
    { symbol: "DOGE", name: "Dogecoin", price: 0.25, change: -3.8 },
    { symbol: "ADA", name: "Cardano", price: 2.5, change: 1.3 },
  ])
  const [portfolio, setPortfolio] = useState<Record<string, number>>({})
  const [marketHistory, setMarketHistory] = useState<Record<string, number[]>>({})
  const [selectedCrypto, setSelectedCrypto] = useState<string>("BTC")
  const [buyAmount, setBuyAmount] = useState<number>(0)
  const [sellAmount, setSellAmount] = useState<number>(0)
  const [gameState, setGameState] = useState<GameState>("intro")

  // Quiz state
  const [showQuiz, setShowQuiz] = useState(false)
  const [quizQuestion, setQuizQuestion] = useState("")
  const [quizOptions, setQuizOptions] = useState<string[]>([])
  const [quizResult, setQuizResult] = useState<QuizResult | null>(null)

  const quizzes = [
    {
      question: "What is a common sign of a crypto scam?",
      options: [
        "Promises of guaranteed high returns",
        "Open-source code",
        "Gradual price movements",
        "Clear documentation",
      ],
      correctIndex: 0,
      explanation:
        "Promises of guaranteed high returns are a major red flag. No investment can guarantee returns, especially in the volatile crypto market.",
    },
    {
      question: "Why is cryptocurrency considered high risk?",
      options: [
        "Because it's digital",
        "Because of its extreme price volatility",
        "Because banks don't like it",
        "Because it's new technology",
      ],
      correctIndex: 1,
      explanation:
        "Cryptocurrencies are known for extreme price volatility, with values that can change dramatically in short periods, making them high-risk investments.",
    },
    {
      question: "What should you do before investing in a cryptocurrency?",
      options: [
        "Buy quickly before the price goes up",
        "Follow advice from social media influencers",
        "Research the project thoroughly",
        "Invest all your savings at once",
      ],
      correctIndex: 2,
      explanation:
        "Always research thoroughly before investing. Understand the project, team, technology, and purpose of the cryptocurrency.",
    },
  ]

  const startGame = () => {
    setBalance(1000)
    setPortfolio({})
    setMarketHistory({})
    setGameState("playing")
  }

  const endGame = () => {
    setGameState("results")
  }

  const buyCrypto = () => {
    if (!selectedCrypto || buyAmount <= 0) return

    const crypto = cryptos.find((c) => c.symbol === selectedCrypto)
    if (!crypto) return

    const cost = buyAmount * crypto.price
    if (cost > balance) return

    setBalance((prev) => prev - cost)
    setPortfolio((prev) => ({
      ...prev,
      [selectedCrypto]: (prev[selectedCrypto] || 0) + buyAmount,
    }))
    setBuyAmount(0)
  }

  const sellCrypto = () => {
    if (!selectedCrypto || sellAmount <= 0) return

    const crypto = cryptos.find((c) => c.symbol === selectedCrypto)
    if (!crypto) return

    const currentAmount = portfolio[selectedCrypto] || 0
    if (sellAmount > currentAmount) return

    const revenue = sellAmount * crypto.price
    setBalance((prev) => prev + revenue)
    setPortfolio((prev) => ({
      ...prev,
      [selectedCrypto]: prev[selectedCrypto] - sellAmount,
    }))
    setSellAmount(0)
  }

  const nextDay = () => {
    // Random chance to show a quiz
    if (Math.random() < 0.3 && !showQuiz) {
      const randomQuiz = quizzes[Math.floor(Math.random() * quizzes.length)]
      setQuizQuestion(randomQuiz.question)
      setQuizOptions(randomQuiz.options)
      setQuizResult(null)
      setShowQuiz(true)
      return
    }

    // Update crypto prices with some randomness
    setCryptos((prev) =>
      prev.map((crypto) => {
        // Random price change between -10% and +10%
        const changePercent = -10 + Math.random() * 20
        const newPrice = crypto.price * (1 + changePercent / 100)

        return {
          ...crypto,
          price: Math.max(0.01, newPrice), // Ensure price doesn't go below 0.01
          change: changePercent,
        }
      }),
    )

    // End game after 10 days
    if (Math.random() < 0.1) {
      endGame()
    }
  }

  const checkAnswer = (index: number) => {
    const quiz = quizzes.find((q) => q.question === quizQuestion)
    if (!quiz) return

    const correct = index === quiz.correctIndex
    setQuizResult({
      correct,
      selectedIndex: index,
      correctIndex: quiz.correctIndex,
      explanation: quiz.explanation,
    })

    // Reward for correct answer
    if (correct) {
      setBalance((prev) => prev + 50)
    }
  }

  const continueAfterQuiz = () => {
    setShowQuiz(false)
    nextDay()
  }

  return {
    balance,
    cryptos,
    portfolio,
    marketHistory,
    buyAmount,
    setBuyAmount,
    sellAmount,
    setSellAmount,
    selectedCrypto,
    setSelectedCrypto,
    buyCrypto,
    sellCrypto,
    nextDay,
    showQuiz,
    quizQuestion,
    quizOptions,
    checkAnswer,
    quizResult,
    continueAfterQuiz,
    gameState,
    startGame,
    endGame,
  }
}
