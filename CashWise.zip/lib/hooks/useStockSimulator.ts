"use client"

import { useState } from "react"
import type { StockAsset, NewsItem } from "@/lib/types"

type GameState = "intro" | "playing" | "results"

export function useStockSimulator() {
  const [cash, setCash] = useState(1000)
  const [stocks, setStocks] = useState<StockAsset[]>([
    { symbol: "AAPL", name: "Apple Inc.", price: 150, change: 1.2 },
    { symbol: "MSFT", name: "Microsoft Corp.", price: 300, change: -0.8 },
    { symbol: "AMZN", name: "Amazon.com Inc.", price: 3200, change: 2.5 },
    { symbol: "GOOGL", name: "Alphabet Inc.", price: 2800, change: -1.5 },
    { symbol: "TSLA", name: "Tesla Inc.", price: 700, change: 3.2 },
  ])
  const [portfolio, setPortfolio] = useState<Record<string, number>>({})
  const [stockHistory, setStockHistory] = useState<Record<string, number[]>>({})
  const [newsItems, setNewsItems] = useState<NewsItem[]>([
    {
      headline: "Tech Sector Shows Strong Growth",
      content: "Technology companies are reporting better than expected earnings this quarter.",
      date: "Today",
      affectedStock: "AAPL",
    },
    {
      headline: "E-commerce Giant Expands Operations",
      content: "The company announced plans to open new fulfillment centers across the country.",
      date: "Yesterday",
      affectedStock: "AMZN",
    },
  ])
  const [selectedStock, setSelectedStock] = useState<string>("AAPL")
  const [buyAmount, setBuyAmount] = useState<number>(0)
  const [sellAmount, setSellAmount] = useState<number>(0)
  const [gameState, setGameState] = useState<GameState>("intro")

  const portfolioValue = Object.entries(portfolio).reduce((total, [symbol, shares]) => {
    const stock = stocks.find((s) => s.symbol === symbol)
    return total + (stock ? stock.price * shares : 0)
  }, 0)

  const startGame = () => {
    setCash(1000)
    setPortfolio({})
    setStockHistory({})
    setGameState("playing")
  }

  const endGame = () => {
    setGameState("results")
  }

  const buyStock = () => {
    if (!selectedStock || buyAmount <= 0) return

    const stock = stocks.find((s) => s.symbol === selectedStock)
    if (!stock) return

    const cost = buyAmount * stock.price
    if (cost > cash) return

    setCash((prev) => prev - cost)
    setPortfolio((prev) => ({
      ...prev,
      [selectedStock]: (prev[selectedStock] || 0) + buyAmount,
    }))
    setBuyAmount(0)
  }

  const sellStock = () => {
    if (!selectedStock || sellAmount <= 0) return

    const stock = stocks.find((s) => s.symbol === selectedStock)
    if (!stock) return

    const currentShares = portfolio[selectedStock] || 0
    if (sellAmount > currentShares) return

    const revenue = sellAmount * stock.price
    setCash((prev) => prev + revenue)
    setPortfolio((prev) => ({
      ...prev,
      [selectedStock]: prev[selectedStock] - sellAmount,
    }))
    setSellAmount(0)
  }

  const nextDay = () => {
    // Update stock prices with some randomness
    setStocks((prev) =>
      prev.map((stock) => {
        // Random price change between -5% and +5%
        const changePercent = -5 + Math.random() * 10
        const newPrice = stock.price * (1 + changePercent / 100)

        // Record history
        setStockHistory((history) => ({
          ...history,
          [stock.symbol]: [...(history[stock.symbol] || []), stock.price],
        }))

        return {
          ...stock,
          price: Math.max(1, newPrice), // Ensure price doesn't go below 1
          change: changePercent,
        }
      }),
    )

    // Generate new news items
    if (Math.random() < 0.3) {
      const stockSymbols = stocks.map((s) => s.symbol)
      const affectedStock = stockSymbols[Math.floor(Math.random() * stockSymbols.length)]

      const newsTemplates = [
        {
          headline: `${stocks.find((s) => s.symbol === affectedStock)?.name} Reports Strong Earnings`,
          content: "The company exceeded analyst expectations for the quarter.",
          impact: 1, // positive
        },
        {
          headline: `${stocks.find((s) => s.symbol === affectedStock)?.name} Faces Regulatory Scrutiny`,
          content: "Regulators are examining the company's business practices.",
          impact: -1, // negative
        },
        {
          headline: `New Product Launch for ${stocks.find((s) => s.symbol === affectedStock)?.name}`,
          content: "The company announced an innovative new product line today.",
          impact: 1, // positive
        },
      ]

      const newsItem = newsTemplates[Math.floor(Math.random() * newsTemplates.length)]

      setNewsItems((prev) => [
        {
          headline: newsItem.headline,
          content: newsItem.content,
          date: "Today",
          affectedStock,
        },
        ...prev.slice(0, 4), // Keep only the 5 most recent news items
      ])

      // Adjust the affected stock's price based on the news
      setStocks((prev) =>
        prev.map((stock) => {
          if (stock.symbol === affectedStock) {
            const impactPercent = newsItem.impact * (2 + Math.random() * 3) // 2-5% impact
            return {
              ...stock,
              price: stock.price * (1 + impactPercent / 100),
              change: stock.change + impactPercent,
            }
          }
          return stock
        }),
      )
    }

    // End game after 10 days or if portfolio value reaches certain threshold
    if (Math.random() < 0.1 || cash + portfolioValue > 2000) {
      endGame()
    }
  }

  return {
    cash,
    stocks,
    portfolio,
    stockHistory,
    newsItems,
    selectedStock,
    setSelectedStock,
    buyAmount,
    setBuyAmount,
    sellAmount,
    setSellAmount,
    buyStock,
    sellStock,
    nextDay,
    portfolioValue,
    gameState,
    startGame,
    endGame,
  }
}
