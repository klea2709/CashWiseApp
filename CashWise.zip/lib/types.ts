import type { LucideIcon } from "lucide-react"

// User
export interface User {
  id: string
  name: string
  email: string
  avatar: string
  level: number
  levelTitle: string
  streak: number
  teenCoins: number
  finPoints: number
}

// Mission
export interface Mission {
  id: string
  title: string
  description: string
  icon: LucideIcon
  color: string
  progress: number
  reward: number
  tasks: MissionTask[]
  category?: string // Added category field for filtering
}

export interface MissionTask {
  id: string
  title: string
  completed: boolean
}

// Lesson
export interface Lesson {
  id: string
  title: string
  description: string
  content: string
  points: number
  quiz: QuizQuestion[]
}

export interface QuizQuestion {
  question: string
  options: string[]
  correctIndex: number
  explanation: string
}

// Wallet
export interface WalletData {
  balance: number
  lastUpdated: string
  transactions: Transaction[]
}

export interface Transaction {
  id: string
  title: string
  amount: number
  date: string
  type: "earn" | "spend"
}

// User Profile
export interface UserProfile {
  name: string
  avatar: string
  level: number
  levelTitle: string
  stats: {
    finPoints: number
    missions: number
    streak: number
  }
  badges: Badge[]
  goals: Goal[]
}

export interface Badge {
  id: string
  name: string
  unlocked: boolean
}

export interface Goal {
  id: string
  title: string
  progress: number
}

// Games
export interface BudgetCategory {
  id: string
  name: string
  description: string
  recommended: number
  color: string
}

export interface CryptoAsset {
  symbol: string
  name: string
  price: number
  change: number
}

export interface StockAsset {
  symbol: string
  name: string
  price: number
  change: number
}

export interface NewsItem {
  headline: string
  content: string
  date: string
  affectedStock?: string
}
